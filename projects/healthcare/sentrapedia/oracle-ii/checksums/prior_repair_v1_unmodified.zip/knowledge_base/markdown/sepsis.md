---
id: 180
title: "Sepsis"
slug: "sepsis"
icd_10: "A41"
clinical_qa_status: "SOURCE_GROUNDED_DIAGNOSTIC_SUBSET"
is_complete: false
verified_clinical_kb: false
---

# Sepsis

> **Clinical QA: SOURCE_GROUNDED_DIAGNOSTIC_SUBSET.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

**Sumber:** 078_PNPK_2017_Tata_Laksana_Sepsis.pdf (HK.01.07/MENKES/342/2017)
**Regulasi:** UNVERIFIED
**Populasi:** dewasa_atau_umum_cek_ruang_lingkup

## Definisi
Sepsis merupakan respons sistemik pejamu terhadap infeksi, saat patogen atau toksin dilepaskan ke dalam sirkulasi darah sehingga terjadi aktivasi proses inflamasi. (PDF p.10)

## Gejala
- Demam >38,3°C atau hipotermia inti <36°C tercantum pada kriteria 2001 sepsis

## Diagnosis (ringkasan berbasis fakta terkurasi)
- [PDF p.10; fact #78] Sepsis 2017: sindrom akibat infeksi dengan komplikasi SIRS, DIC, syok septik, gagal multi organ
- [PDF p.10; fact #80] Kultur darah sepsis dewasa tidak selalu positif; hasil dapat terlambat
- [PDF p.12; fact #81] Sepsis-3 pada PNPK 2017: disfungsi organ karena infeksi dengan peningkatan akut SOFA ≥2
- [PDF p.13; fact #83] Kultur sebaiknya diambil sebelum pemberian antibiotik jika memungkinkan tanpa menunda tata laksana
- [PDF p.11; fact #84] Tabel 3 sepsis 2017: infeksi diidentifikasi/dicurigai, dengan ≥2 variabel tanda pendukung
- [PDF p.11; fact #88] Kriteria 2001 sepsis: leukosit >12.000/µL atau <4.000/µL atau >10% bentuk imatur
- [PDF p.11; fact #89] Kriteria 2001 sepsis: hiperglikemia >140 mg/dL tanpa diabetes, CRP dan PCT meningkat
- [PDF p.12; fact #93] Kriteria 2001: kreatinin naik >0,5 mg/dL, INR >1,5, aPTT >60 detik, trombosit <100.000/µL
- [PDF p.12; fact #94] Kriteria 2001: bilirubin total >4 mg/dL; hiperlaktatemia >1 mmol/L (variasi laboratorium >2)
- [PDF p.13; fact #96] Tabel definisi sepsis berat historis: hipoperfusi jaringan atau disfungsi organ akibat infeksi
- [PDF p.13; fact #97] Definisi sepsis berat historis mencantumkan kreatinin >2 mg/dL dan trombosit <100.000/µL

## Terapi
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Rujukan
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Fakta dan Sitasi PDF

### 78 — diagnostic_criteria — PDF p.10
**Konsep:** Sepsis 2017: sindrom akibat infeksi dengan komplikasi SIRS, DIC, syok septik, gagal multi organ
**Kutipan sumber:** -10- BAB III HASIL Sepsis merupakan respons sistemik pejamu terhadap infeksi, saat patogen atau toksin dilepaskan ke dalam sirkulasi darah sehingga terjadi aktivasi proses inflamasi. Rangkaian patofisiologi sepsis didasari terjadinya inflamasi sistemik yang melibatkan berbagai mediator inflamasi. Terjadinya gangguan pada sistem koaglukosasi juga sangat berperan dalam timbulnya berbagai komplikasi yang disebabkan oleh sepsis. Komplikasi yang ditimbulkan oleh sepsis dapat berupa systemic inflammatory response syndrome (SIRS), disseminated intravascular coaglukosation (DIC), renjatan septik dan gagal multi organ. Dalam praktik klinis, sering terjadi kendala pada aspek diagnosis sepsis. Hasil kultur darah baru bisa didapatkan klinisi setelah beberapa hari perawatan, sedangkan terapi empirik
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 79 — population_context — PDF p.10
**Konsep:** Manifestasi sepsis bisa tidak tampak pada lansia, diabetes, penyakit ginjal kronis, atau imunokompromais
**Kutipan sumber:** melitus, penyakit ginjal kronik, imunokompromais, serta pasien usia lanjut seringkali manifestasi klinis sepsis tidak tampak, sehingga sepsis seringkali lolos terdiagnosis. Ketelitian dan pengalaman klinisi sangat diperlukan dalam rangka diagnosis dan terapi sepsis. A. Etiologi Penyebab terbesar sepsis adalah bakteri Gram negatif (60-70% kasus). Staphylococci, pneumococci, streptococci, dan bakteri Gram positif lain lebih jarang menimbulkan sepsis dengan angka kejadian antara 20-40% dari seluruh angka kejadian sepsis. Jamur oportunistik, virus, atau protozoa juga dilaporkan dapat
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 80 — supporting_investigation — PDF p.10
**Konsep:** Kultur darah sepsis dewasa tidak selalu positif; hasil dapat terlambat
**Kutipan sumber:** beberapa hari perawatan, sedangkan terapi empirik antimikroba perlu segera diberikan. Kultur hanya menunjukkan hasil positif pada 30-50% sampel. Pada pasien dengan penyakit penyerta seperti diabetes melitus, penyakit ginjal kronik, imunokompromais, serta pasien usia lanjut seringkali manifestasi klinis sepsis tidak tampak, sehingga sepsis seringkali lolos terdiagnosis. Ketelitian dan pengalaman klinisi sangat diperlukan dalam rangka diagnosis dan terapi sepsis. A. Etiologi Penyebab terbesar sepsis adalah bakteri Gram negatif (60-70% kasus). Staphylococci, pneumococci, streptococci,
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 81 — diagnostic_criteria — PDF p.12
**Konsep:** Sepsis-3 pada PNPK 2017: disfungsi organ karena infeksi dengan peningkatan akut SOFA ≥2
**Kutipan sumber:** Organ Failure Assessment (SOFA) digunakan sebagai cara penilaian disfungsi organ. Penambahan akut dua atau lebih nilai SOFA sebagai akibat infeksi digunakan sebagai dasar diagnosis sepsis. Kelompok ahli juga mengajukan kriteria baru yang dapat digunakan sebagai penapis pasien sepsis yang dikenal dengan istilah quick SOFA (qSOFA). Tiga kriteria qSOFA adalah laju napas lebih dari sama dengan 22 napas/menit, perubahan kesadaran, tekanan darah sistolik kurang dari sama dengan 100 mmHg.
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 82 — red_flags_severity — PDF p.12
**Konsep:** qSOFA untuk penapisan sepsis: laju napas ≥22/menit, perubahan kesadaran, TDS ≤100 mmHg
**Kutipan sumber:** digunakan sebagai penapis pasien sepsis yang dikenal dengan istilah quick SOFA (qSOFA). Tiga kriteria qSOFA adalah laju napas lebih dari sama dengan 22 napas/menit, perubahan kesadaran, tekanan darah sistolik kurang dari sama dengan 100 mmHg.
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 83 — supporting_investigation — PDF p.13
**Konsep:** Kultur sebaiknya diambil sebelum pemberian antibiotik jika memungkinkan tanpa menunda tata laksana
**Kutipan sumber:** dilakukan lebih awal, antara lain dengan perangkat seperti yang tercantum pada Lampiran 1. Pengambilan kultur harus dikerjakan secara rutin dan sebaiknya dilakukan sebelum pemberian antibiotik. 1. Terapi Antibiotik Rasional pada Sepsis Pemberian antibiotik merupakan salah satu terapi utama yang harus diberikan pada kasus infeksi bakteri. Antibiotik didefinisikan sebagai suatu substansi yang dihasilkan dari berbagai jenis mikroorganisme seperti jamur dan bakteri yang dapat menghambat pertumbuhan mikroorganisme lain. Era antibiotik modern dimulai dengan ditemukan sulfanilamid pada tahun 1937 dan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 84 — diagnostic_criteria — PDF p.11
**Konsep:** Tabel 3 sepsis 2017: infeksi diidentifikasi/dicurigai, dengan ≥2 variabel tanda pendukung
**Kutipan sumber:** Infeksi, diidentifikasi atau dicurigai, dan beberapa (2 atau lebih) hal berikut:
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

### 85 — signs_symptoms — PDF p.11
**Konsep:** Demam >38,3°C atau hipotermia inti <36°C tercantum pada kriteria 2001 sepsis
**Kutipan sumber:** Demam (> 38,3°C); Hipotermia (suhu inti tubuh < 36°C)
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

### 86 — physical_findings — PDF p.11
**Konsep:** Takipnea dalam kriteria sepsis 2001: >20 napas/menit atau PCO2 32 mmHg seperti tercetak
**Kutipan sumber:** Takipnea didefinisikan sebagai laju napas > 20x/menit atau PCO₂ 32 mmHg.
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

### 87 — physical_findings — PDF p.11
**Konsep:** Kriteria 2001 sepsis: takikardia >90/menit, perubahan mental, edema signifikan
**Kutipan sumber:** Laju jantung > 90/menit; Perubahan status mental; Edema signifikan atau keseimbangan cairan positif (> 20 mL/kg dalam 24 jam)
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

### 88 — laboratory — PDF p.11
**Konsep:** Kriteria 2001 sepsis: leukosit >12.000/µL atau <4.000/µL atau >10% bentuk imatur
**Kutipan sumber:** Leukositosis (hitung leukosit > 12.000/µL); Leukopenia (hitung leukosit < 4000/µL); Hitung leukosit normal dengan lebih dari 10% bentuk imatur
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

### 89 — laboratory — PDF p.11
**Konsep:** Kriteria 2001 sepsis: hiperglikemia >140 mg/dL tanpa diabetes, CRP dan PCT meningkat
**Kutipan sumber:** Hiperglikemia (glukosa plasma > 140 mg/dL atau 7,7 mmol/L) tanpa ada diabetes
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

### 90 — physical_findings — PDF p.11
**Konsep:** Kriteria 2001: hipotensi bila TDS <90 mmHg atau MAP <70 mmHg atau TDS turun >40 mmHg
**Kutipan sumber:** Hipotensi arterial (TDS < 90 mmHg, MAP < 70 mmHg, atau penurunan TDS > 40 mmHg pada orang dewasa)
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

### 91 — red_flags_severity — PDF p.11
**Konsep:** Kriteria 2001 disfungsi organ: PaO2/FiO2 <300 mmHg
**Kutipan sumber:** Hipoksemia arterial (PaO₂/FiO₂ < 300 mmHg)
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

### 92 — red_flags_severity — PDF p.12
**Konsep:** Kriteria 2001: oliguria akut <0,5 mL/kg/jam ≥2 jam meski resusitasi adekuat
**Kutipan sumber:** Oliguria akut (produksi urin < 0,5 mL/kg/jam selama paling tidak 2 jam meskipun mendapat resusitasi cairan adekuat)
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

### 93 — laboratory — PDF p.12
**Konsep:** Kriteria 2001: kreatinin naik >0,5 mg/dL, INR >1,5, aPTT >60 detik, trombosit <100.000/µL
**Kutipan sumber:** Peningkatan kreatinin > 0,5 mg/dL atau 44,2 µmol/L; Kelainan koagulasi (INR > 1,5 atau aPTT > 60 detik); Trombositopenia (hitung trombosit < 100.000/µL)
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

### 94 — laboratory — PDF p.12
**Konsep:** Kriteria 2001: bilirubin total >4 mg/dL; hiperlaktatemia >1 mmol/L (variasi laboratorium >2)
**Kutipan sumber:** Hiperbilirubinemia (bilirubin total plasma > 4 mg/dL atau 70 µmol/L); Hiperlaktatemia (> 1 mmol/L)
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

### 95 — physical_findings — PDF p.12
**Konsep:** Kriteria 2001 perfusi jaringan: CRT terlambat atau kulit mottled
**Kutipan sumber:** Perlambatan pengisian kapiler kulit atau kulit bercak-bercak (mottle)
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

### 96 — diagnostic_criteria — PDF p.13
**Konsep:** Tabel definisi sepsis berat historis: hipoperfusi jaringan atau disfungsi organ akibat infeksi
**Kutipan sumber:** Definisi sepsis berat = hipoperfusi jaringan atau disfungsi organ diinduksi sepsis
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

### 97 — laboratory — PDF p.13
**Konsep:** Definisi sepsis berat historis mencantumkan kreatinin >2 mg/dL dan trombosit <100.000/µL
**Kutipan sumber:** Kreatinin > 2,0 mg/dL (176,8 µmol/L); Hitung trombosit < 100.000/µL
**Metode verifikasi:** SOURCE_VISUAL_REVIEW_LOG

**Batas cakupan:** Diagnosis-oriented curation; terapi dan rujukan tidak dikurasi dalam checkpoint sumber. Tidak ada clinical approval independen.

