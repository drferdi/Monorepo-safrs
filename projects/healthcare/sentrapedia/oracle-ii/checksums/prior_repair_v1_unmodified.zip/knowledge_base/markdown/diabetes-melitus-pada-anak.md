---
id: 161
title: "Diabetes Melitus Pada Anak"
slug: "diabetes-melitus-pada-anak"
icd_10: "E14"
clinical_qa_status: "SOURCE_GROUNDED_DIAGNOSTIC_SUBSET"
is_complete: false
verified_clinical_kb: false
---

# Diabetes Melitus Pada Anak

> **Clinical QA: SOURCE_GROUNDED_DIAGNOSTIC_SUBSET.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

**Sumber:** 003_PNPK_2024_Tata_Laksana_Diabetes_Melitus_pada_Anak.pdf (HK.01.07/MENKES/2009/2024)
**Regulasi:** UNVERIFIED
**Populasi:** anak

## Definisi
Diabetes adalah kelainan metabolik kompleks yang ditandai dengan adanya hiperglikemia kronik yang disebabkan karena adanya defek pada sekresi insulin, kerja insulin atau keduanya. (PDF p.13)

## Gejala
- Gejala DM anak: poliuria, polidipsia, nokturia dan penurunan berat badan tanpa sebab jelas
- DM tipe 1 anak sering bergejala poliuria, polidipsia dan penurunan BB cepat dalam 2–6 minggu

## Diagnosis (ringkasan berbasis fakta terkurasi)
- [PDF p.13; fact #136] PNPK DM anak meliputi diabetes tipe 1, tipe 2 dan monogenik
- [PDF p.13; fact #137] Pembedaan DM tipe 1 dan tipe 2 pada anak atau remaja dapat sulit
- [PDF p.14; fact #138] DM tipe 2 anak dapat datang dengan ketosis atau ketoasidosis menyerupai DM tipe 1
- [PDF p.15; fact #139] Autoantibodi GADA, IA2, IAA, ICA dan ZnT8 digunakan mendukung klasifikasi DM tipe 1
- [PDF p.15; fact #140] C-peptide 12–24 bulan setelah diagnosis dapat membantu membedakan tipe diabetes pada anak
- [PDF p.16; fact #142] Tanpa gejala klasik, pemeriksaan diagnosis glukosa harus diulang pada hari berbeda
- [PDF p.16; fact #143] DM anak dengan gejala klasik dan glukosa plasma sewaktu ≥200 mg/dL
- [PDF p.16; fact #144] DM anak: glukosa plasma puasa ≥126 mg/dL
- [PDF p.16; fact #145] DM anak: glukosa plasma 2 jam setelah TTGO ≥200 mg/dL
- [PDF p.16; fact #146] DM anak: HbA1c >6,5% terstandarisasi NGSP/DCCT menurut PNPK 2024
- [PDF p.16; fact #147] Gangguan glukosa puasa anak 100–125 mg/dL
- [PDF p.16; fact #148] HbA1c <6,5% tidak menyingkirkan DM anak; HbA1c saja tidak disarankan
- [PDF p.17; fact #151] Glukosuria menjadi petunjuk awal pada anak tetapi perlu konfirmasi kriteria diagnosis
- [PDF p.20; fact #179] Ketoasidosis diabetik anak dapat menyerupai gastroenteritis, pneumonia, asma atau akut abdomen

## Terapi
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Rujukan
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Fakta dan Sitasi PDF

### 136 — diagnostic_criteria — PDF p.13
**Konsep:** PNPK DM anak meliputi diabetes tipe 1, tipe 2 dan monogenik
**Kutipan sumber:** hiperglikemia kronik yang disebabkan karena adanya defek pada sekresi insulin, kerja insulin atau keduanya. DM pada Anak dibagi menjadi 3 tipe, yaitu: 1. DM Tipe-1. 2. DM Tipe-2. 3. DM Tipe Monogenik. DM Tipe-2 tidak selalu dapat dibedakan dengan mudah dari DM tipe lain pada anak dan remaja. Tabel 1 menunjukkan beberapa karakteristik DM Tipe-2 dibandingkan DM Tipe-1 dan diabetes monogenik. Sesuai
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 137 — differential_diagnosis — PDF p.13
**Konsep:** Pembedaan DM tipe 1 dan tipe 2 pada anak atau remaja dapat sulit
**Kutipan sumber:** Anak dibagi menjadi 3 tipe, yaitu: 1. DM Tipe-1. 2. DM Tipe-2. 3. DM Tipe Monogenik. DM Tipe-2 tidak selalu dapat dibedakan dengan mudah dari DM tipe lain pada anak dan remaja. Tabel 1 menunjukkan beberapa karakteristik DM Tipe-2 dibandingkan DM Tipe-1 dan diabetes monogenik. Sesuai patogenesisnya, proses autoimun yang mendestruksi sel beta pankreas pada DM Tipe-1 dan resistensi insulin
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 138 — differential_diagnosis — PDF p.14
**Konsep:** DM tipe 2 anak dapat datang dengan ketosis atau ketoasidosis menyerupai DM tipe 1
**Kutipan sumber:** pertama dari penderita DM tipe-1 berisiko 15 kali menjadi DM Tipe-1. 2. Penderita DM Tipe-2 dapat datang dalam kondisi ketosis/ketoasidosis sehingga menyerupai DM Tipe-1. Pada keadaan tersebut, kadar insulin atau C-peptida penderita bisa sangat rendah akibat glukotoksisitas atau ada ketergantungan insulin. jdih.kemkes.go.id
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 139 — supporting_investigation — PDF p.15
**Konsep:** Autoantibodi GADA, IA2, IAA, ICA dan ZnT8 digunakan mendukung klasifikasi DM tipe 1
**Kutipan sumber:** Autoantibodi yang berhubungan dengan diabetes antara lain: islet cell cytoplasmic antibodies (ICAs), glutamic acid decarboxylase 65 autoantibodies (GADA); Tyrosine phosphatase-like insulinoma antigen 2 (IA2); insulin autoantibodies (IAA); and β-cell-specific zinc transporter 8 autoantibodies (ZnT8). Pemeriksaan antibodi ini berhubungan dengan usia dan dapat ditemukan pada awal kehidupan, IAA
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 140 — supporting_investigation — PDF p.15
**Konsep:** C-peptide 12–24 bulan setelah diagnosis dapat membantu membedakan tipe diabetes pada anak
**Kutipan sumber:** Salah satu cara membedakan DM tipe-2 dari DM Tipe-1 yang mungkin dapat digunakan adalah pemeriksaan C-peptide sekitar 12-24 bulan setelah diagnosis karena sangat jarang penderita DM Tipe-1 yang masih mempunyai kadar C-peptide normal pada saat tersebut. 5. Pemeriksaan autoantibodi yang berhubungan dengan diabetes dapat memastikan diagnosis DM Tipe-1. Autoantibodi yang berhubungan dengan diabetes
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 141 — signs_symptoms — PDF p.16
**Konsep:** Gejala DM anak: poliuria, polidipsia, nokturia dan penurunan berat badan tanpa sebab jelas
**Kutipan sumber:** ada/tidaknya gejala klinis DM dan hasil pengukuran kadar glukosa plasma. Gejala klinis klasik DM yaitu poliuria, polidipsia, nokturia, dan penurunan berat badan tanpa sebab yang jelas. Tanpa adanya gejala klinis DM, pemeriksaan harus diulang pada hari yang berbeda. Diagnosis DM dapat ditegakkan apabila memenuhi salah satu kriteria sebagai berikut: 1. Ditemukannya gejala klinis poliuria, polidipsia,
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 142 — diagnostic_criteria — PDF p.16
**Konsep:** Tanpa gejala klasik, pemeriksaan diagnosis glukosa harus diulang pada hari berbeda
**Kutipan sumber:** polidipsia, nokturia, dan penurunan berat badan tanpa sebab yang jelas. Tanpa adanya gejala klinis DM, pemeriksaan harus diulang pada hari yang berbeda. Diagnosis DM dapat ditegakkan apabila memenuhi salah satu kriteria sebagai berikut: 1. Ditemukannya gejala klinis poliuria, polidipsia, nokturia, enuresis, penurunan berat badan, polifagia, dan kadar glukosa plasma sewaktu ≥ 200 mg/dL (11,1
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 143 — diagnostic_criteria — PDF p.16
**Konsep:** DM anak dengan gejala klasik dan glukosa plasma sewaktu ≥200 mg/dL
**Kutipan sumber:** gejala klinis poliuria, polidipsia, nokturia, enuresis, penurunan berat badan, polifagia, dan kadar glukosa plasma sewaktu ≥ 200 mg/dL (11,1 mmol/L); atau 2. Kadar glukosa plasma puasa ≥ 126 mg/dL (7 mmol/L); atau 3. Kadar glukosa plasma ≥ 200 mg/dL (11,1 mmol/L) pada jam ke-2 TTGO (Tes Toleransi Glukosa Oral); atau 4. HbA1c >6,5% (dengan standar NGSP dan DCCT) Penilaian glukosa plasma puasa:
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 144 — diagnostic_criteria — PDF p.16
**Konsep:** DM anak: glukosa plasma puasa ≥126 mg/dL
**Kutipan sumber:** berat badan, polifagia, dan kadar glukosa plasma sewaktu ≥ 200 mg/dL (11,1 mmol/L); atau 2. Kadar glukosa plasma puasa ≥ 126 mg/dL (7 mmol/L); atau 3. Kadar glukosa plasma ≥ 200 mg/dL (11,1 mmol/L) pada jam ke-2 TTGO (Tes Toleransi Glukosa Oral); atau 4. HbA1c >6,5% (dengan standar NGSP dan DCCT) Penilaian glukosa plasma puasa: 1. Normal: < 100 mg/dL (5,6 mmol/L) 2. Gangguan glukosa plasma
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 145 — diagnostic_criteria — PDF p.16
**Konsep:** DM anak: glukosa plasma 2 jam setelah TTGO ≥200 mg/dL
**Kutipan sumber:** glukosa plasma puasa ≥ 126 mg/dL (7 mmol/L); atau 3. Kadar glukosa plasma ≥ 200 mg/dL (11,1 mmol/L) pada jam ke-2 TTGO (Tes Toleransi Glukosa Oral); atau 4. HbA1c >6,5% (dengan standar NGSP dan DCCT) Penilaian glukosa plasma puasa: 1. Normal: < 100 mg/dL (5,6 mmol/L) 2. Gangguan glukosa plasma puasa (Impaired Fasting glucose = IFG): 100–125 mg/dL (5,6–6,9 mmol/L) 3. Diabetes: ≥ 126 mg/dL
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 146 — diagnostic_criteria — PDF p.16
**Konsep:** DM anak: HbA1c >6,5% terstandarisasi NGSP/DCCT menurut PNPK 2024
**Kutipan sumber:** glukosa plasma ≥ 200 mg/dL (11,1 mmol/L) pada jam ke-2 TTGO (Tes Toleransi Glukosa Oral); atau 4. HbA1c >6,5% (dengan standar NGSP dan DCCT) Penilaian glukosa plasma puasa: 1. Normal: < 100 mg/dL (5,6 mmol/L) 2. Gangguan glukosa plasma puasa (Impaired Fasting glucose = IFG): 100–125 mg/dL (5,6–6,9 mmol/L) 3. Diabetes: ≥ 126 mg/dL (7,0 mmol/L) Penilaian tes toleransi glukosa oral: 1. Normal:
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 147 — laboratory — PDF p.16
**Konsep:** Gangguan glukosa puasa anak 100–125 mg/dL
**Kutipan sumber:** Normal: < 100 mg/dL (5,6 mmol/L) 2. Gangguan glukosa plasma puasa (Impaired Fasting glucose = IFG): 100–125 mg/dL (5,6–6,9 mmol/L) 3. Diabetes: ≥ 126 mg/dL (7,0 mmol/L) Penilaian tes toleransi glukosa oral: 1. Normal: <140 mg/dL (7,8 mmol/L) 2. Gangguan glukosa toleransi (Impaired glucose tolerance = IGT): 140– 200 mg/dL (7,8 - < 11,1 mmol/L) 3. Diabetes: ≥ 200 mg/dL (11,1 mmol/L) Hal-hal
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 148 — diagnostic_criteria — PDF p.16
**Konsep:** HbA1c <6,5% tidak menyingkirkan DM anak; HbA1c saja tidak disarankan
**Kutipan sumber:** terganggu. Diagnosis tidak ditegakkan berdasarkan satu kali pemeriksaan. 2. Kadar HbA1c < 6,5% tidak menyingkirkan diagnosis dan pemeriksaan HbA1c saja tidak disarankan untuk diagnosis. 3. Satu pemeriksaan glukosa plasma sewaktu yang diambil pada saat stress (trauma, infeksi berat, dll.) tanpa gejala DM sebelumnya, tidak dapat menjadi dasar diagnosis DM. Pemeriksaan harus dikonfirmasi
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 149 — red_flags_severity — PDF p.16
**Konsep:** Hiperglikemia sewaktu stres/infeksi berat tanpa gejala DM sebelumnya harus dikonfirmasi kembali
**Kutipan sumber:** tidak disarankan untuk diagnosis. 3. Satu pemeriksaan glukosa plasma sewaktu yang diambil pada saat stress (trauma, infeksi berat, dll.) tanpa gejala DM sebelumnya, tidak dapat menjadi dasar diagnosis DM. Pemeriksaan harus dikonfirmasi lagi. 4. Tes Toleransi Glukosa Oral (oral glucose tolerance test, OGTT) tidak jdih.kemkes.go.id
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 150 — red_flags_severity — PDF p.17
**Konsep:** Ketonemia atau ketonuria dengan hiperglikemia berat membutuhkan tata laksana segera
**Kutipan sumber:** kriteria glukosa plasma puasa atau sewaktu karena berisiko mengakibatkan hiperglikemia berat. 5. Adanya ketonemia atau ketonuria yang menyertai hiperglikemia berat menunjukkan diagnosis DM dan membutuhkan tata laksana segera. 6. Ditemukannya glukosa pada urin dapat menjadi petunjuk diabetes pada anak dan remaja. Hasil pemeriksaan ini perlu dikonfirmasi dengan kriteria diagnosis di atas.
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 151 — laboratory — PDF p.17
**Konsep:** Glukosuria menjadi petunjuk awal pada anak tetapi perlu konfirmasi kriteria diagnosis
**Kutipan sumber:** menyertai hiperglikemia berat menunjukkan diagnosis DM dan membutuhkan tata laksana segera. 6. Ditemukannya glukosa pada urin dapat menjadi petunjuk diabetes pada anak dan remaja. Hasil pemeriksaan ini perlu dikonfirmasi dengan kriteria diagnosis di atas. Penggunaan Klinis Pemeriksaan Insulin dan C-peptida Pemeriksaan insulin terutama untuk fasting hypoglycemia, selain itu untuk evaluasi
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 152 — signs_symptoms — PDF p.17
**Konsep:** DM tipe 1 anak sering bergejala poliuria, polidipsia dan penurunan BB cepat dalam 2–6 minggu
**Kutipan sumber:** Tipe-1 mempunyai riwayat perjalanan klinis yang akut. Poliuria, polidipsia, nokturia, enuresis, penurunan berat badan yang cepat dalam 2-6 minggu sebelum diagnosis ditegakkan, kadang-kadang disertai polifagia dan gangguan penglihatan. Apabila gejala-gejala klinis ini disertai dengan hiperglikemia maka diagnosis DM tidak diragukan lagi. Sering terjadi kesalahan dan keterlambatan diagnosis
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 153 — red_flags_severity — PDF p.20
**Konsep:** Gejala gawat pada DM anak mencakup dehidrasi sedang-berat dan muntah berulang
**Kutipan sumber:** kulit berulang. 2) Terdapat kegawatan (Ketoasidosis diabetik atau hiperglikemia hiperosmolar) a) Dehidrasi sedang sampai berat. b) Muntah berulang dan pada beberapa kasus nyeri perut (menyebabkan kesalahan diagnosis sebagai gastroenteritis). c) Tetap terjadi poliuri meskipun dehidrasi. d) Kehilangan berat badan oleh karena kehilangan cairan dan otot serta lemak. e) Pipi kemerahan karena
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 177 — physical_findings — PDF p.14
**Konsep:** Akantosis nigrikans pada tabel karakteristik DM anak lebih berkaitan dengan DM tipe 2
**Kutipan sumber:** dengan Lebih sering Sesuai dengan prevalensi prevalensi obesitas di populasi obesitas di populasi Akantosis nigrikans Tidak Ya Tidak Persentase dari seluruh DM Biasanya > Pada umumnya 1-4% anak 90% <10% (60-80% di Jepang) Orang tua menderita DM 2-4% 80% 90% Faktor risiko: 1. Individu dengan turunan urutan pertama dari penderita DM tipe-1 berisiko 15 kali menjadi DM Tipe-1. 2. Penderita
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 178 — red_flags_severity — PDF p.20
**Konsep:** Kussmaul, bau napas aseton, disorientasi dan syok adalah temuan gawat ketoasidosis diabetik anak
**Kutipan sumber:** kemerahan karena ketoasidosis. f) Bau pernapasan aseton. g) Hiperventilasi pada ketoasidosis diabetik (pernapasan Kussmaul). h) Gangguan sensorik (disorientasi, apatis sampai dengan koma). i) Syok (nadi cepat, sirkulasi perifer memburuk dengan sianosis perifer). j) Hipotensi (tanda paling terlambat dan jarang pada anak ketoasidosis diabetik). 3) Kondisi yang menyebabkan keterlambatan diagnosis
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 179 — differential_diagnosis — PDF p.20
**Konsep:** Ketoasidosis diabetik anak dapat menyerupai gastroenteritis, pneumonia, asma atau akut abdomen
**Kutipan sumber:** Dehidrasi sedang sampai berat. b) Muntah berulang dan pada beberapa kasus nyeri perut (menyebabkan kesalahan diagnosis sebagai gastroenteritis). c) Tetap terjadi poliuri meskipun dehidrasi. d) Kehilangan berat badan oleh karena kehilangan cairan dan otot serta lemak. e) Pipi kemerahan karena ketoasidosis. f) Bau pernapasan aseton. g) Hiperventilasi pada ketoasidosis diabetik (pernapasan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

**Batas cakupan:** Diagnosis-oriented curation; terapi dan rujukan tidak dikurasi dalam checkpoint sumber. Tidak ada clinical approval independen.

