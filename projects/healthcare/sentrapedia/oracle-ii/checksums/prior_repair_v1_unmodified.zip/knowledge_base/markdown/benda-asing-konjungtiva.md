---
id: 328
title: "Benda Asing Konjungtiva"
slug: "benda-asing-konjungtiva"
icd_10: "T15.1"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Benda Asing Konjungtiva

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Benda asing konjungtiva adalah adanya partikel eksternal (debu, serpihan pasir, serangga, gram logam) yang menempel atau terperangkap pada permukaan konjungtiva bulbi, forniks, atau konjungtiva tarsal.

## Gejala
- Rasa mengganjal hebat mendadak pada mata
- Mata berair (lakrimasi berlebih)
- Mata merah dan fotofobia ringan
- Nyeri saat berkedip (terutama bila benda asing menempel di konjungtiva tarsal superior)

## Diagnosis
Pemeriksaan mata luar dengan slit lamp atau loupe dan senter: inspeksi konjungtiva bulbi dan wajib melakukan eversi kelopak mata atas untuk mengevaluasi sulkus subtarsalis. Tes fluoresin untuk memastikan tidak ada erosi kornea.

## Terapi
1. Anestesi topikal: Pantokain 0.5% atau Tetrakain 0.5% 1-2 tetes pada mata yang terkena.
2. Ekstraksi Benda Asing:
   - Irigasi lembut menggunakan larutan NaCl 0.9% steril, atau
   - Angkat benda asing secara hati-hati menggunakan lidi kapas steril basah atau jarum suntik 25G steril dari arah tepi.
3. Medikamentosa Pasca-ekstraksi:
   - Kloramfenikol 1% salep mata atau tetes mata antibiotik profilaksis 3-4 kali sehari selama 3-5 hari.

## Rujukan
Rujuk ke Spesialis Mata bila benda asing tertanam dalam pada stroma sklera/kornea, benda asing logam dengan cincin karat (rust ring), benda asing intraokular tembus, atau timbul infeksi sekunder keratitis.

