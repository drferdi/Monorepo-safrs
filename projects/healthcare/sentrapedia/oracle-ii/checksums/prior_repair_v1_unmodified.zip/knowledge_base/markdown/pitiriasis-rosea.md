---
id: 347
title: "Pitiriasis Rosea"
slug: "pitiriasis-rosea"
icd_10: "L42"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Pitiriasis Rosea

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Pitiriasis rosea adalah penyakit erupsi kulit eritemoskuamosa akut yang bersifat swasirna (self-limiting), diduga berhubungan dengan reaktivasi infeksi virus Human Herpesvirus 6 dan 7 (HHV-6/7), berlangsung selama 4 hingga 10 minggu.

## Gejala
- Herald patch (mother plaque): lesi inisial berupa plak soliter oval merah muda dengan tepi kolaret skuama halus, muncul 1-2 minggu sebelum erupsi luas
- Erupsi lesi sekunder: bercak oval kemerahan lebih kecil di badan mengikuti garis lipatan kulit (Langer's lines) membentuk pola pohon cemara terbalik (Christmas tree pattern)
- Gatal ringan hingga sedang

## Diagnosis
Ditegakkan berdasarkan morfologi klinis khas herald patch yang diikuti erupsi sekunder berbentuk pola pohon cemara di punggung. Kerokan KOH negatif menyingkirkan tinea korporis. VDRL/TPHA non-reaktif menyingkirkan sifilis sekunder.

## Terapi
1. Reassurance: Edukasi bahwa penyakit ini jinak, tidak menular, dan akan sembuh tuntas secara spontan dalam 6-8 minggu tanpa meninggalkan bekas parut.
2. Terapi Simtomatik:
   - Emolien pelembap atau bedak kocok kalamin untuk meredakan gatal.
   - Antihistamin oral (Setirizin 10 mg/hari) bila gatal mengganggu tidur.
   - Kortikosteroid topikal potensi ringan-sedang (Hidrokortison 2.5% atau Mometason 0.1%) pada lesi yang sangat gatal.
   - Mandi air suam-suam kuku, hindari mandi air panas dan sabun keras.

## Rujukan
Rujuk ke Spesialis Kulit dan Kelamin bila lesi atipikal tidak sembuh setelah > 10-12 minggu, erupsi sangat berat luas, atau dicurigai sifilis sekunder / erupsi obat (drug eruption).

