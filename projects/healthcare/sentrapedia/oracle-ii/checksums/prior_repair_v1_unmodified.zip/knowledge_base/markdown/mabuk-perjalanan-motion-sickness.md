---
id: 319
title: "Mabuk Perjalanan (Motion Sickness)"
slug: "mabuk-perjalanan-motion-sickness"
icd_10: "T75.3"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Mabuk Perjalanan (Motion Sickness)

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Mabuk perjalanan (kinetosis) adalah sindrom gangguan fisiologis yang timbul akibat ketidakcocokan sensorik (sensory conflict) antara input visual, vestibular (telinga dalam), dan proprioseptif selama berada di kendaraan bergerak.

## Gejala
- Mual dan muntah
- Pusing / melayang
- Keringat dingin (diaporesis)
- Wajah pucat
- Hipersalivasi
- Mengantuk dan lemas

## Diagnosis
Penegakan diagnosis klinis berdasarkan riwayat timbulnya gejala khas saat bepergian dengan transportasi darat, laut, atau udara, dan menghilang secara bertahap setelah gerakan berhenti.

## Terapi
1. Non-farmakologis: Duduk di bagian kendaraan dengan gerakan paling stabil (depan mobil, tengah kapal, atas sayap pesawat), memandang lurus ke garis horizon yang stabil, sirkulasi udara segar cukup, hindari membaca atau menatap layar gadget saat kendaraan berjalan.
2. Farmakologis Profilaksis (diminum 30-60 menit sebelum keberangkatan):
   - Dimenhidrinat: 50-100 mg oral (dewasa) atau 25-50 mg (anak 6-12 tahun), dapat diulang setiap 4-6 jam prn.
   - Skopolamin transdermal patch (ditempel di retroaurikular 4 jam sebelum perjalanan).
   - Antiemetik: Domperidone 10 mg oral atau Metoklopramid 10 mg oral bila mual berat.

## Rujukan
Rujuk ke Spesialis Saraf / THT bila pusing dan muntah menetap lama berhari-hari setelah perjalanan usai, atau terdapat kecurigaan kelainan vestibular sentral / vertigo patologis lain.

