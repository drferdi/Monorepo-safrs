---
id: 313
title: "Rinitis Alergika"
slug: "rinitis-alergika"
icd_10: "J30.4"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Rinitis Alergika

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Rinitis alergika adalah kelainan inflamasi mukosa hidung yang diperantarai oleh reaksi hipersensitivitas tipe I (IgE-mediated) setelah paparan alergen inhalan (tungau debu rumah, serbuk sari, bulu hewan peliharaan).

## Gejala
- Bersin-bersin berulang (paroksismal > 5 kali berurutan)
- Rinorea cair encer bening
- Hidung tersumbat
- Gatal pada hidung, palatum, dan mata
- Allergic shiners (lingkaran hitam bawah mata)
- Allergic salute dan allergic crease (garis horizontal dorsum hidung)

## Diagnosis
Anamnesis riwayat atopi pribadi atau keluarga. Pemeriksaan rinoskopi anterior: mukosa konka inferior edema, basah, berwarna pucat atau kebiruan (livid) dengan sekret serosa jernih berlimpah.

## Terapi
1. Penghindaran alergen pencetus (pencegahan primer terpenting: cuci seprai air panas, bersihkan AC, kurangi karpet/boneka).
2. Farmakologis Lini Pertama:
   - Antihistamin Oral Generasi ke-2 (Non-sedatif): Setirizin 1 x 10 mg/hari, Loratadin 1 x 10 mg/hari, atau Feksofenadin 1 x 120-180 mg/hari.
   - Kortikosteroid Intranasal (Paling efektif untuk hidung tersumbat): Flutikason furoat/propionat atau Mometason furoat semprot hidung 1-2 semprotan per lubang hidung 1 kali sehari.
   - Cuci hidung dengan cairan NaCl fisiologis 0.9% 1-2 kali sehari.
   - Dekongestan oral pseudoefedrin maksimal 3-5 hari bila sumbatan sangat berat.

## Rujukan
Rujuk ke Spesialis THT-KL bila terdapat deviasi septum berat, polip hidung, rinosinusitis kronik komorbiditas, atau tidak responsif terhadap kortikosteroid topikal dan antihistamin optimal setelah 4 minggu.

