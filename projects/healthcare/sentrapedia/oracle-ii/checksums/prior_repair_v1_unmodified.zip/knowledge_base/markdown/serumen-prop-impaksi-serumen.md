---
id: 318
title: "Serumen Prop (Impaksi Serumen)"
slug: "serumen-prop-impaksi-serumen"
icd_10: "H61.2"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Serumen Prop (Impaksi Serumen)

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Serumen prop adalah penumpukan dan pemadatan massa serumen (kotoran telinga) di liang telinga yang menyumbat kanalis akustikus eksternus, sering diperburuk oleh kebiasaan membersihkan telinga menggunakan cotton bud.

## Gejala
- Penurunan pendengaran konduktif
- Telinga terasa tersumbat/penuh (terutama setelah kemasukan air/mandi)
- Tinnitus (berdenging)
- Rasa gatal atau nyeri tumpul di liang telinga

## Diagnosis
Ditegakkan dari pemeriksaan otoskopi liang telinga: terlihat gumpalan massa serumen berwarna kuning kecokelatan hingga hitam pekat yang menyumbat seluruh atau sebagian lumen liang telinga.

## Terapi
1. Evakuasi Serumen:
   - Serumen lunak: dikeluarkan langsung dengan sendok serumen (cerumen hook) atau kuretase hati-hati.
   - Serumen keras padat: tetesi pelunak serumen (Karbogliserin / Gliserin 10% atau tetes telinga Natrium Dokusat 0.5%) 3 x 2-3 tetes sehari selama 3-5 hari sebelum evakuasi.
   - Irigasi liang telinga dengan air hangat suam-suam kuku (suhu tubuh ~37°C) menggunakan spuit irigasi ke arah posterosuperior liang telinga (KONTRAINDIKASI irigasi bila ada riwayat perforasi membran timpani).

## Rujukan
Rujuk ke Spesialis THT-KL bila serumen sangat keras melekat erat pada dinding kanalis yang gagal dievakuasi, pasien tidak kooperatif, atau dicurigai perforasi membran timpani bersamaan.

