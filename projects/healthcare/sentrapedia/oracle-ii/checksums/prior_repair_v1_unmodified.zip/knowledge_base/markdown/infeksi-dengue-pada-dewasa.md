---
id: 165
title: "Infeksi Dengue Pada Dewasa"
slug: "infeksi-dengue-pada-dewasa"
icd_10: "A91"
clinical_qa_status: "SOURCE_GROUNDED_DIAGNOSTIC_SUBSET"
is_complete: false
verified_clinical_kb: false
---

# Infeksi Dengue Pada Dewasa

> **Clinical QA: SOURCE_GROUNDED_DIAGNOSTIC_SUBSET.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

**Sumber:** 044_PNPK_2020_Tata_Laksana_Infeksi_Dengue_Pada_Dewasa.pdf (HK.01.07/MENKES/9845/2020)
**Regulasi:** UNVERIFIED
**Populasi:** dewasa

## Definisi
Infeksi dengue adalah penyakit infeksi virus akut yang disebabkan oleh virus dengue yang ditandai demam 2–7 hari disertai dengan manifestasi perdarahan, penurunan trombosit (trombositopenia), adanya hemokonsentrasi yang ditandai kebocoran plasma (peningkatan hematokrit, asites, efusi pleura, hipoalbuminemia). (PDF p.5)

## Gejala
- Dengue dewasa: demam akut, nyeri kepala, mialgia, artralgia, ruam, perdarahan, leukopenia
- Demam dengue dapat berupa sakit kepala berat, mialgia, artralgia, ruam, leukopenia dan trombositopenia
- Dengue dewasa fase demam 2–7 hari disertai flushing, nyeri badan, mual dan muntah

## Diagnosis (ringkasan berbasis fakta terkurasi)
- [PDF p.13; fact #3] Demam dengue dengan perdarahan perlu dibedakan dari demam berdarah dengue; pembeda adalah kebocoran plasma
- [PDF p.17; fact #8] Dewasa: peningkatan hematokrit ≥20%, asites, efusi pleura, hipoalbuminemia menandakan kebocoran plasma
- [PDF p.19; fact #10] USG dan foto toraks lateral dekubitus membantu mendeteksi kebocoran plasma, termasuk efusi pleura
- [PDF p.19; fact #11] USG: edema dinding kandung empedu dapat mendahului efusi pleura atau asites
- [PDF p.21; fact #13] Klasifikasi WHO 2011 pada PNPK dewasa: demam dengue, DBD I-IV, sindrom syok dengue
- [PDF p.22; fact #14] Probable dengue dewasa: demam akut 2–7 hari, ≥2 manifestasi dan dukungan serologi atau epidemiologi setempat
- [PDF p.22; fact #15] Dengue dewasa probable: leukosit ≤5.000/mm³ atau trombosit ≤150.000/mm³ termasuk manifestasi pendukung
- [PDF p.22; fact #16] Konfirmasi dengue dewasa dapat melalui isolasi virus, serologi, atau deteksi virus/antigen
- [PDF p.23; fact #17] DBD dewasa WHO 2011: demam 2–7 hari, perdarahan, trombosit ≤100.000/mm³ dan bukti kebocoran plasma
- [PDF p.23; fact #18] DBD dewasa: hemokonsentrasi ≥20% dibanding standar atau temuan efusi pleura, asites, hipoalbuminemia
- [PDF p.23; fact #19] Dengue shock syndrome dewasa: dengue disertai tanda syok termasuk takikardia, akral dingin, pengisian kapiler memanjang
- [PDF p.24; fact #20] Leukopenia dan perubahan rasio neutrofil/limfosit dapat mendahului trombositopenia atau kenaikan hematokrit
- [PDF p.24; fact #21] Trombosit turun mendadak <100.000/mm³ pada akhir fase demam atau sebelum syok
- [PDF p.25; fact #22] DDx fase demam dengue dewasa: influenza, campak, chikungunya, rubela, reaksi obat, infeksi meningokokus
- [PDF p.25; fact #23] DDx fase kritis dengue dewasa: gastroenteritis, leptospirosis, malaria, tifoid, hepatitis virus, leukemia, akut abdomen, DKA
- [PDF p.26; fact #24] NS1 dan RT-PCR paling bermanfaat saat fase akut; IgM/IgG bermanfaat setelah fase akut
- [PDF p.27; fact #25] Antigen NS1 merupakan pilihan mendeteksi dengue fase akut, dengan sensitivitas lebih tinggi pada infeksi primer
- [PDF p.28; fact #26] NS1 negatif tidak menyingkirkan dengue terutama jika diambil setelah hari akut
- [PDF p.29; fact #27] IgM/IgG satu sampel memiliki risiko negatif palsu dini, positif palsu riwayat infeksi/reaksi silang
- [PDF p.35; fact #28] Foto toraks dewasa dan USG mendukung evaluasi manifestasi kebocoran plasma

## Terapi
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Rujukan
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Fakta dan Sitasi PDF

### 1 — signs_symptoms — PDF p.12
**Konsep:** Dengue dewasa: demam akut, nyeri kepala, mialgia, artralgia, ruam, perdarahan, leukopenia
**Kutipan sumber:** yang lain. Gejala dan tanda klinis infeksi dengue dapat berupa flu-like syndrome, demam mendadak tinggi, mialgia, artralgia, nyeri retro-orbital, terdapat ruam, mimisan, gusi berdarah, limfadenopati, trombositopenia, leukopenia, peningkatan hematokrit, hipoalbuminemia, diatesis hemoragik, hingga syok dan kematian. Berdasarkan kriteria WHO tahun 2011 infeksi dengue dibagi menjadi seperti gambar berikut ini. Gambar 1. Manifestasi klinis infeksi virus dengue a. Demam yang tidak berdiferensiasi (demam tidak jelas) Demam pada kategori ini sebagian besar terlihat
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 2 — signs_symptoms — PDF p.13
**Konsep:** Demam dengue dapat berupa sakit kepala berat, mialgia, artralgia, ruam, leukopenia dan trombositopenia
**Kutipan sumber:** biasanya berupa demam akut, terkadang dapat juga berupa demam bifasik, disertai gejala sakit kepala berat, mialgia, artralgia, ruam, leukopenia dan trombositopenia. Ruam kulit umumnya asimtomatik dan hanya pada 16-27% kasus disertai dengan pruritus. Perdarahan jarang terlihat pada DD, namun epistaksis dan perdarahan gingiva, hipermenore, petekie atau purpura, dan perdarahan saluran gastrointestinal dapat juga terjadi. Di daerah endemik dengue, wabah DD jarang terjadi di kalangan masyarakat setempat. Wabah infeksi DEN-1 di Taiwan menunjukkan bahwa perdarahan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 3 — differential_diagnosis — PDF p.13
**Konsep:** Demam dengue dengan perdarahan perlu dibedakan dari demam berdarah dengue; pembeda adalah kebocoran plasma
**Kutipan sumber:** kurang dari 1%. Penting untuk membedakan kasus DD dengan perdarahan dengan kasus DBD. Pada DBD terjadi hemokonsentrasi yang timbul akibat adanya peningkatan permeabilitas vaskular, sedangkan pada DD tidak. c. Demam Berdarah Dengue (DBD) Di daerah hiperendemik infeksi dengue, DBD lebih sering terjadi pada anak di bawah 15 tahun. Hal tersebut sering dihubungkan dengan infeksi dengue berulang. DBD paling sering ditemukan pada infeksi dengue sekunder. Angka kejadian DBD pada orang dewasa belakangan ini meningkat. DBD ditandai dengan demam mendadak tinggi disertai dengan tanda dan gejala yang mirip dengan DD fase akut. Manifestasi perdarahan juga dapat terjadi. Manifestasi perdarahan tersebut dapat berupa uji bending atau tourniquet test positif (terdapat ≥10 petekie / inci persegi), petekie, mudah memar, dan atau pada
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 4 — red_flags_severity — PDF p.14
**Konsep:** Tanda peringatan dengue dewasa: muntah menetap, nyeri perut, letargi/gelisah, perdarahan, akral dingin, oliguria
**Kutipan sumber:** umumnya terjadi pada fase kritis. Adanya tanda peringatan (warning signs) dini seperti muntah terus-menerus dan tidak dapat minum, nyeri perut hebat, letargi dan atau gelisah, perdarahan, pusing atau lemas, akral pucat, dingin dan basah, dan oliguria penting untuk diketahui karena keadaan tersebut dapat mendahului terjadinya syok. Hemostasis tidak normal dan kebocoran plasma merupakan pemegang peran utama patofisiologi DBD. d. Expanded Dengue Syndrome Manifestasi yang tidak lazim penderita dengue dengan keterlibatan organ berat seperti hati, ginjal, otak atau jantung semakin banyak dilaporkan baik pada kasus DBD dan juga pada penderita infeksi dengue yang tidak mengalami kebocoran plasma (demam dengue/DD). Sebagian besar penderita DBD yang memiliki manifestasi yang tidak biasa itu timbul akibat terjadinya syok yang berkepanjangan (prolonged shock) dengan kegagalan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 5 — population_context — PDF p.10
**Konsep:** Komorbid, kehamilan, usia lanjut dan penyakit kronis dapat memengaruhi risiko dengue berat
**Kutipan sumber:** memberikan kekebalan selama 2-3 bulan terhadap serotipe yang berbeda (proteksi silang). Faktor risiko individu turut menentukan tingkat keparahan penyakit. Faktor-faktor tersebut antara lain infeksi sekunder, usia, etnis, bayi, obesitas, lansia, ibu hamil, menstruasi, dan kemungkinan penyakit kronis seperti asma bronkial, anemia sel sabit, hipertensi, diabetes mellitus, ulkus peptikum, penyakit hemolitik, penyakit jantung bawaan, gagal ginjal kronik, sirosis, pengobatan yang menggunakan steroid atau NSAID, dan lain sebagainya. Hingga saat ini belum ada satu teori pun yang dapat menjelaskan patogenesis infeksi
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 6 — signs_symptoms — PDF p.16
**Konsep:** Dengue dewasa fase demam 2–7 hari disertai flushing, nyeri badan, mual dan muntah
**Kutipan sumber:** organ 1) Fase Demam Demam mendadak tinggi merupakan gejala yang khas pada fase ini. Demam mendadak tinggi ini biasanya berlangsung 2-7 hari dan sering disertai facial flushing, eritema kulit, sakit di seluruh tubuh, mialgia, atralgia, dan sakit kepala, anoreksia, mual dan muntah. Sakit tenggorokan, injeksi faring, dan injeksi konjungtiva terkadang ditemukan juga pada penderita. Fase viremia dengan suhu tertinggi umumnya terjadi tiga sampai empat hari pertama setelah onset demam namun kemudian turun dengan cepat hingga tidak terdeteksi dalam beberapa hari berikutnya. Tingkat viremia dan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 7 — red_flags_severity — PDF p.17
**Konsep:** Fase kritis saat defervescence biasanya hari ke-3 sampai ke-7, dengan risiko kebocoran plasma
**Kutipan sumber:** fase demam (pendarahan gastrointestinal dapat dimulai pada tahap itu). 2) Fase Kritis Awal fase kritis umumnya ditandai dengan penurunan suhu tubuh hingga 37,5-38 0C atau kurang dan tetap di bawah level ini (penurunan suhu yang drastis ini disebut juga sebagai masa defervesens), dan umumnya terjadi pada hari 3-7 perjalanan penyakit. Walaupun fase ini disebut fase kritis, itu bukan berarti bahwa keadaan penderita pasti kritis. Disebut fase kritis karena pada fase inilah biasanya terjadi kebocoran plasma (biasanya berlangsung selama 24- 48 jam). Saat demam turun atau mereda, penderita memasuki periode dengan risiko tertinggi terjadinya manifestasi berat akibat kebocoran plasma. Pada periode ini penting sekali memantau timbulnya perdarahan dan kebocoran plasma ke rongga pleura dan abdomen, menerapkan terapi yang tepat, dan menstabilkan volume cairan dalam tubuh. Jika tidak
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 8 — laboratory — PDF p.17
**Konsep:** Dewasa: peningkatan hematokrit ≥20%, asites, efusi pleura, hipoalbuminemia menandakan kebocoran plasma
**Kutipan sumber:** dekompensasi kordis. Tanda-tanda kebocoran plasma meliputi terjadinya hemokonsentrasi (peningkatan hematokrit mendadak ≥20% dari awal), adanya asites, efusi pleura, albumin serum atau protein yang rendah (sesuai dengan usia dan jenis kelamin). Pada penderita dengan kebocoran plasma parameter hemodinamik yang berhubungan dengan syok terkompensasi seperti peningkatan denyut jantung sesuai dengan usia (terutama bila tidak ada demam), denyut nadi cepat dan lemah, akral dingin, tekanan nadi yang sempit (sistolik dikurangi diastolik <20 mmHg), masa pengisian kapiler (capillary refill
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 9 — physical_findings — PDF p.17
**Konsep:** Syok dengue terkompensasi: nadi cepat lemah, akral dingin, tekanan nadi sempit, CRT memanjang, oliguria
**Kutipan sumber:** seperti peningkatan denyut jantung sesuai dengan usia (terutama bila tidak ada demam), denyut nadi cepat dan lemah, akral dingin, tekanan nadi yang sempit (sistolik dikurangi diastolik <20 mmHg), masa pengisian kapiler (capillary refill time/CRT) >3 detik, dan penurunan diuresis (oliguria) harus dipantau dengan ketat. Penderita yang menunjukkan tanda-tanda kekurangan volume intravaskular yang terus meningkat, impending shock, atau manifestasi perdarahan yang berat harus dirawat di unit
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 10 — supporting_investigation — PDF p.19
**Konsep:** USG dan foto toraks lateral dekubitus membantu mendeteksi kebocoran plasma, termasuk efusi pleura
**Kutipan sumber:** berupa asites dan atau efusi pleura dapat dideteksi lebih dini dengan pemeriksaan rontgen toraks dan ultrasonografi (USG). Pemeriksaan rontgen right lateral decubitus dapat dilakukan untuk mendeteksi adanya efusi pleura. Edema dinding kandung empedu yang diperiksa dengan menggunakan USG sering menjadi temuan awal kebocoran plasma sebelum asites dan atau efusi pleura ditemukan. Penurunan albumin >0,5 gm / dl dari nilai awal atau <3,5 gm% adalah bukti tidak langsung dari kebocoran plasma. Pada kasus DBD ringan, semua tanda dan gejala mereda setelah demam mereda. Meredanya
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 11 — supporting_investigation — PDF p.19
**Konsep:** USG: edema dinding kandung empedu dapat mendahului efusi pleura atau asites
**Kutipan sumber:** rontgen right lateral decubitus dapat dilakukan untuk mendeteksi adanya efusi pleura. Edema dinding kandung empedu yang diperiksa dengan menggunakan USG sering menjadi temuan awal kebocoran plasma sebelum asites dan atau efusi pleura ditemukan. Penurunan albumin >0,5 gm / dl dari nilai awal atau <3,5 gm% adalah bukti tidak langsung dari kebocoran plasma. Pada kasus DBD ringan, semua tanda dan gejala mereda setelah demam mereda. Meredanya demam dapat disertai dengan keringat dingin dan perubahan pada nadi dan tekanan darah. Perubahan ini mencerminkan gangguan sirkulasi
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 12 — physical_findings — PDF p.20
**Konsep:** Syok dengue dewasa: nadi cepat lemah, tekanan nadi ≤20 mmHg atau hipotensi, CRT >3 detik
**Kutipan sumber:** - 20 - dengan penyempitan tekanan nadi ≤20 mmHg dengan tekanan diastolik yang meningkat, misalnya 100/90 mmHg, atau hipotensi. Tanda-tanda penurunan perfusi jaringan dapat berupa masa pengisian kapiler yang melambat (>3 detik), kulit dingin dan berkeringat, serta gelisah. Selanjutnya bila tidak ditangani dengan baik penderita dapat masuk ke dalam tahap syok yang sangat dalam dengan tekanan darah dan / atau nadi yang tidak terdeteksi (DBD derajat IV). Syok dapat reversibel dan berlangsung dengan durasi
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 13 — diagnostic_criteria — PDF p.21
**Konsep:** Klasifikasi WHO 2011 pada PNPK dewasa: demam dengue, DBD I-IV, sindrom syok dengue
**Kutipan sumber:** perlu diketahui klasifikasi derajat penyakit seperti tertera pada tabel 1. Tabel 1. Klasifikasi infeksi dengue dan derajat keparahan DBD menurut WHO DD/DBD DERAJAT TANDA DAN GEJALA UJI LABORATORIUM DD Demam dengan dua dari • Leukopenia (leukosit berikut ini: ≤5000 sel/mm3) • Nyeri kepala • Trombositopenia • Nyeri retro-orbital (trombosit ≤150,000 • Mialgia sel/mm3) • Artralgia • Peningkatan hematokrit • Ruam kulit (5% - 10%) • Manifestasi • Tidak ada bukti perdarahan kebocoran plasma • Tidak ada bukti kebocoran plasma DBD I Demam dan manifestasi Trombositopenia (trombosit perdarahan (uji torniket ≤100,000 sel/mm3); positif) dan adanya bukti peningkatan Hematokrit kebocoran plasma ≥20% DBD II DBD derajat I dan Trombositopenia (trombosit perdarahan spontan ≤100,000 sel/mm3); peningkatan Hematokrit ≥20% DBD III DBD derajat I dan II Trombositopenia (trombosit disertai
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 14 — diagnostic_criteria — PDF p.22
**Konsep:** Probable dengue dewasa: demam akut 2–7 hari, ≥2 manifestasi dan dukungan serologi atau epidemiologi setempat
**Kutipan sumber:** menduga terjadinya infeksi dengue pada seseorang. 1) Tersangka (probable) dengue: Demam akut/mendadak selama 2-7 hari disertai 2 atau lebih manifestasi klinis berikut ini: a) Sakit kepala; b) Nyeri retri-orbital; c) Mialgia; d) Arthralgia; e) Ruam kulit; f) Manifestasi perdarahan; g) Leukopenia (leukosit ≤5000 sel/mm3); dan h) Trombositopenia (trombosit ≤150,000 sel/mm3). dan setidaknya satu dari keadaan di bawah ini: a) Pemeriksaan serologi dengue positif; dan b) atau ditemukan penderita DD/DBD yang sudah dikonfirmasi pada lokasi dan waktu yang sama. 2) Diagnosis terkonfirmasi Kasus probable dengan setidaknya satu dari beberapa di bawah ini: a) Isolasi virus dengue dari serum, cairan serebrospinal, atau sample autopsy; b) Peningkatan serum IgG (dengan uji hemaglutinasi inhibisi) dengan kelipatan empat atau lebih atau peningkatan antibodi IgM yang spesifik virus dengue; c)
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 15 — laboratory — PDF p.22
**Konsep:** Dengue dewasa probable: leukosit ≤5.000/mm³ atau trombosit ≤150.000/mm³ termasuk manifestasi pendukung
**Kutipan sumber:** retri-orbital; c) Mialgia; d) Arthralgia; e) Ruam kulit; f) Manifestasi perdarahan; g) Leukopenia (leukosit ≤5000 sel/mm3); dan h) Trombositopenia (trombosit ≤150,000 sel/mm3). dan setidaknya satu dari keadaan di bawah ini: a) Pemeriksaan serologi dengue positif; dan b) atau ditemukan penderita DD/DBD yang sudah dikonfirmasi pada lokasi dan waktu yang sama. 2) Diagnosis terkonfirmasi Kasus probable dengan setidaknya satu dari beberapa di bawah ini: a) Isolasi virus dengue dari serum, cairan serebrospinal, atau sample autopsy; b) Peningkatan serum IgG (dengan uji hemaglutinasi
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 16 — laboratory — PDF p.22
**Konsep:** Konfirmasi dengue dewasa dapat melalui isolasi virus, serologi, atau deteksi virus/antigen
**Kutipan sumber:** ditemukan penderita DD/DBD yang sudah dikonfirmasi pada lokasi dan waktu yang sama. 2) Diagnosis terkonfirmasi Kasus probable dengan setidaknya satu dari beberapa di bawah ini: a) Isolasi virus dengue dari serum, cairan serebrospinal, atau sample autopsy; b) Peningkatan serum IgG (dengan uji hemaglutinasi inhibisi) dengan kelipatan empat atau lebih atau peningkatan antibodi IgM yang spesifik virus dengue; c) Deteksi virus dengue atau antigen pada jaringan, serum atau cairan serebrospinal dengan pemeriksaan immunohistochemistry, immunofloresens, enzyme-linked
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 17 — diagnostic_criteria — PDF p.23
**Konsep:** DBD dewasa WHO 2011: demam 2–7 hari, perdarahan, trombosit ≤100.000/mm³ dan bukti kebocoran plasma
**Kutipan sumber:** memperkuat diagnosis DBD. b. Demam Berdarah Dengue (DBD) Berdasarkan kriteria WHO 2011 diagnosis DBD ditegakkan bila semua hal dibawah ini terpenuhi: 1) Demam mendadak tinggi dengan selama 2-7 hari; 2) Manifestasi perdarahan dapat berupa salah satu dari gejala berikut: tes torniket positif, petekie, ekimosis atau purpura, atau perdarahan dari mukosa, saluran pencernaan, tempat injeksi, atau perdarahan dari tempat lain; 3) Trombosit ≤100.000 sel/mm3; dan 4) Terdapat minimal satu tanda-tanda plasma leakage (kebocoran plasma) sebagai berikut: a) Peningkatan hematokrit / hemokonsentrasi ≥20% dibandingkan standar sesuai dengan umur dan jenis kelamin; b) Penurunan hematokrit >20% setelah mendapat terapi cairan, dibadningkan dengan nilai hematokrit sebelumya; dan/atau c) Tanda kebocoran plasma seperti efusi pleura, asites atau hipoproteinemia/hipoalbuminemia. Perbedaan utama antara DD dan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 18 — laboratory — PDF p.23
**Konsep:** DBD dewasa: hemokonsentrasi ≥20% dibanding standar atau temuan efusi pleura, asites, hipoalbuminemia
**Kutipan sumber:** Terdapat minimal satu tanda-tanda plasma leakage (kebocoran plasma) sebagai berikut: a) Peningkatan hematokrit / hemokonsentrasi ≥20% dibandingkan standar sesuai dengan umur dan jenis kelamin; b) Penurunan hematokrit >20% setelah mendapat terapi cairan, dibadningkan dengan nilai hematokrit sebelumya; dan/atau c) Tanda kebocoran plasma seperti efusi pleura, asites atau hipoproteinemia/hipoalbuminemia. Perbedaan utama antara DD dan DBD adalah terjadinya kebocoran plasma pada DBD sedangkan pada DD tidak. c. Sindroma Syok Dengue (SSD) Berdasarkan kriteria WHO 2011 diagnosis Sindroma Syok Dengue
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 19 — diagnostic_criteria — PDF p.23
**Konsep:** Dengue shock syndrome dewasa: dengue disertai tanda syok termasuk takikardia, akral dingin, pengisian kapiler memanjang
**Kutipan sumber:** sedangkan pada DD tidak. c. Sindroma Syok Dengue (SSD) Berdasarkan kriteria WHO 2011 diagnosis Sindroma Syok Dengue ditegakkan bila kriteria infeksi dengue seperti yang sudah dijelaskan sebelumnya disertai dengan tanda-tanda syok seperti: 1) Takikardi, akral dingin, masa pengisian kapiler melambat, nadi lemah, lesu atau gelisah, yang kemungkinan dapat menjadi tanda-tanda penurunan perfusi otak; 2) Tekanan nadi ≤20 mmHg dengan peningkatan tekanan diastolik, contoh: 100/80 mmHg; dan 3) Hipotensi menurut umur, yang diartikan dengan tekanan sistolik <80 mmHg untuk anak dibawah 5 tahun atau 80 sampai 90 mmHg untuk anak yang sudah lebih besar dan orang dewasa.
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 20 — laboratory — PDF p.24
**Konsep:** Leukopenia dan perubahan rasio neutrofil/limfosit dapat mendahului trombositopenia atau kenaikan hematokrit
**Kutipan sumber:** sel darah putih dan neutrofil, dan mencapai titik nadir menjelang akhir fase demam. Perubahan jumlah sel darah putih (≤5000 sel / mm3) dan rasio neutrofil terhadap limfosit (neutrofil < limfosit) berguna untuk memprediksi periode kritis dari kebocoran plasma. Temuan ini mendahului temuan trombositopenia atau peningkatan hematokrit. Limfositosis relatif dengan limfosit atipikal yang meningkat biasanya terjadi pada akhir fase demam dan saat menuju masa konvalesens. Perubahan ini juga terlihat pada Demam Dengue. 2) Jumlah trombosit umumnya normal pada fase awal demam. Penurunan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 21 — laboratory — PDF p.24
**Konsep:** Trombosit turun mendadak <100.000/mm³ pada akhir fase demam atau sebelum syok
**Kutipan sumber:** umumnya normal pada fase awal demam. Penurunan ringan dapat ditemukan setelah fase awal. Penurunan secara tiba-tiba jumlah trombosit hingga di bawah 100.000 sel/mm3 terjadi pada akhir fase demam (penurunan suhu atau fase defervesens) dan atau sebelum timbulnya syok. Derajat trombositopenia berkorelasi dengan tingkat keparahan DBD. Perubahan itu terjadi dalam waktu singkat dan umumnya kembali normal pada masa konvalesens. 3) Hematokrit didapatkan dalam batas normal pada awal fase demam. Adanya sedikit peningkatan dikarenakan adanya demam tinggi, anoreksia dan muntah. Peningkatan hematokrit
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 22 — differential_diagnosis — PDF p.25
**Konsep:** DDx fase demam dengue dewasa: influenza, campak, chikungunya, rubela, reaksi obat, infeksi meningokokus
**Kutipan sumber:** berbagai kondisi klinis yang mirip dengan infeksi dengue pada fase awal dan kritis. Tabel 2. Beberapa kondisi klinis yang mirip dengan infeksi dengue pada fase demam Flu-like syndrome Influenza, campak, cikungunya, penyakit HIV serokonversi Penyakit dengan Campak, demam skarlet, rubella, infeksi ruam menigokokus, cikungunya, reaksi obat Penyakit diare Rotavirus, infeksi enterik Manifestasi Meningo/ensefalitis neurologis Kejang demam HIV-Human Immunodeficiency Virus Tabel 3. Kondisi klinis yang mirip dengan infeksi dengue fase kritis Infeksi Gastroentritis akut, leptospirosis, malaria, demam typhoid, hepatitis virus, HIV Akut Penyakit maligna Leukemia akut dan penyakit maligna lainnya Kondisi lain-lain Appendisitis akut, akut abdomen, kolesistitis akut, perforasi viskus, ketoasidosis diabetikum, asidosis laktat, leukopenia dan trombositopenia, gangguan trombosit,
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 23 — differential_diagnosis — PDF p.25
**Konsep:** DDx fase kritis dengue dewasa: gastroenteritis, leptospirosis, malaria, tifoid, hepatitis virus, leukemia, akut abdomen, DKA
**Kutipan sumber:** Manifestasi Meningo/ensefalitis neurologis Kejang demam HIV-Human Immunodeficiency Virus Tabel 3. Kondisi klinis yang mirip dengan infeksi dengue fase kritis Infeksi Gastroentritis akut, leptospirosis, malaria, demam typhoid, hepatitis virus, HIV Akut Penyakit maligna Leukemia akut dan penyakit maligna lainnya Kondisi lain-lain Appendisitis akut, akut abdomen, kolesistitis akut, perforasi viskus, ketoasidosis diabetikum, asidosis laktat, leukopenia dan trombositopenia, gangguan trombosit, gagal ginjal, distress pernapasan (pernapasan Kussmaul), lupus eritematosus sistemik 3. Pemeriksaan Penunjang a. Pemeriksaan penunjang laboratorium Pada dasarnya uji-uji ini bertujuan untuk mendeteksi dan mengidentifikasi virus dengue atau komponennya (protein, RNA),
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 24 — laboratory — PDF p.26
**Konsep:** NS1 dan RT-PCR paling bermanfaat saat fase akut; IgM/IgG bermanfaat setelah fase akut
**Kutipan sumber:** yang optimal. Pemeriksaan dipilih sesuai perjalanan penyakit dari infeksi dengue. Virus dengue berada di dalam kadar tertinggi di darah saat fase akut (hari 1-3 demam) dan menurun saat demam turun. Dengan demikian, isolasi virus atau deteksi komponen virus (deteksi antigen NS1, RT PCR) akan memberikan hasil optimal dengan sampel darah, serum, atau plasma yang diambil saat fase akut. Antibodi dapat dideteksi setelah fase akut, sehingga uji serologi mendeteksi IgM/IgG merupakan pilihan pada fase konvalesen. Terdapat perbedaan pola imunoglobulin pada infeksi primer dan infeksi sekunder.
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 25 — laboratory — PDF p.27
**Konsep:** Antigen NS1 merupakan pilihan mendeteksi dengue fase akut, dengan sensitivitas lebih tinggi pada infeksi primer
**Kutipan sumber:** dapat ditemukan di dalam dan di permukaan sel terinfeksi, dan disekresikan keluar sel. Tingginya kadar NS1 di serum, menjadikan uji antigen ini pilihan untuk mendeteksi virus dengue terutama pada fase akut. Deteksi antigen NS1 dapat dilakukan dengan metode ELISA dan imunokromatografi. Saat ini telah tersedia beberapa kit diagnosis antigen NS1 yang praktis yang dikenal sebagai Rapid test (RDT) sehingga dapat digunakan di tempat perawatan pasien. Meta analisis oleh Shan dkk mendapatkan kit antigen NS1 secara keseluruhan memiliki sensitivitas 66% (95% CI 64.5– 67.5) dan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 26 — laboratory — PDF p.28
**Konsep:** NS1 negatif tidak menyingkirkan dengue terutama jika diambil setelah hari akut
**Kutipan sumber:** untuk mendapatkan hasil yang optimal. Dari data di atas, terlihat bahwa terdapat hasil negatif palsu pada pemeriksaan antigen NS1. Hal ini dapat terjadi bila pemeriksaan dilakukan setelah NS1 menghilang dari darah, atau terdapat kompleks imun pada infeksi sekunder yang menurunkan sensitivitas uji. Amat jarang juga dijumpai hasil positif palsu. Penyebab positif palsu belum diketahui dengan jelas. 2) Uji serologi IgM/IgG Pemeriksaan ini dilakukan dengan serum atau plasma fase konvalesen. Kit pemeriksaan IgM/IgG dengue tersedia dalam metode ELISA atau RTD dengan imunokromatografi.
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 27 — laboratory — PDF p.29
**Konsep:** IgM/IgG satu sampel memiliki risiko negatif palsu dini, positif palsu riwayat infeksi/reaksi silang
**Kutipan sumber:** palsu atau positif palsu pada pemeriksaan IgM/IgG bila dilakukan dengan satu sampel. Negatif palsu dapat terjadi bila uji dilakukan saat antibodi belum terbentuk. Untuk memastikan hal ini, uji dapat diulang 1 minggu kemudian. Positif palsu dapat terjadi bila masih terdapat IgM/IgG yang terbentuk pada infeksi dengue beberapa bulan sebelumnya. Infeksi dengue dapat tanpa gejala, sehingga dari anamnesis pasien tidak menyatakan pernah terinfeksi dengue. Selain itu, IgM positif palsu dapat disebabkan kerena infeksi silang dengan virus lain dari keluarga Flaviviridae (misal, Japanese
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 28 — supporting_investigation — PDF p.35
**Konsep:** Foto toraks dewasa dan USG mendukung evaluasi manifestasi kebocoran plasma
**Kutipan sumber:** pengunaan APD dan alat berbeda di tiap ruang penting untuk mencegah kontaminasi. b. Pemeriksaan penunjang radiologi Pada pasien dewasa, pemeriksaan Radiologi yang dilakukan adalah foto toraks posisi PA (Postero Anterior) Erect dan Lateral. Bila pasien tidak bisa dalam posisi tegak (erect) maka dilakukan posisi AP Supine (telentang ) atau AP duduk /semi fowler. Untuk mendeteksi effusi pleura minimal sebaiknya dilakukan lateral dekubitus, tergantung kecurigaan di sisi kiri atau kanan , atau USG (Ultrasonografi). Pada pasien dengan perawatan ICU dilakukan foto toraks AP
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

**Batas cakupan:** Diagnosis-oriented curation; terapi dan rujukan tidak dikurasi dalam checkpoint sumber. Tidak ada clinical approval independen.

