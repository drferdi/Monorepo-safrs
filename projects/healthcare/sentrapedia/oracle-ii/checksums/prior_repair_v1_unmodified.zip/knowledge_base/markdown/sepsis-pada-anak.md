---
id: 227
title: "Sepsis Pada Anak"
slug: "sepsis-pada-anak"
icd_10: "A41"
clinical_qa_status: "SOURCE_GROUNDED_DIAGNOSTIC_SUBSET"
is_complete: false
verified_clinical_kb: false
---

# Sepsis Pada Anak

> **Clinical QA: SOURCE_GROUNDED_DIAGNOSTIC_SUBSET.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

**Sumber:** 041_PNPK_2021_Tata_Laksana_Sepsis_Pada_Anak.pdf (HK.01.07/MENKES/4722/2021)
**Regulasi:** UNVERIFIED
**Populasi:** anak

## Definisi
Sepsis adalah disfungsi organ yang mengancam kehidupan (life- threatening organ dysfunction) yang disebabkan oleh disregulasi imun terhadap infeksi. (PDF p.10)

## Gejala
- Infeksi anak dapat ditandai demam atau hipotermia serta fokus infeksi

## Diagnosis (ringkasan berbasis fakta terkurasi)
- [PDF p.10; fact #54] Definisi sepsis anak: disfungsi organ yang mengancam jiwa disebabkan disregulasi imun terhadap infeksi
- [PDF p.13; fact #55] Sepsis anak: kecurigaan atau bukti infeksi, penilaian warning signs, dan skor PELOD-2 ≥10
- [PDF p.13; fact #56] PELOD-2 ≥10 dipakai PNPK sepsis anak untuk menilai disfungsi organ berat
- [PDF p.14; fact #59] Biomarker pendukung pada sepsis anak termasuk leukosit, trombosit, CRP, prokalsitonin
- [PDF p.14; fact #60] Evaluasi infeksi anak melalui kultur, PCR, analisis urin, feses, LP, dan imaging berdasarkan fokus
- [PDF p.16; fact #66] Leukosit, CRP, transaminase dan prokalsitonin adalah penanda penilaian sepsis anak
- [PDF p.17; fact #67] Limfopenia <1300/µL adalah temuan yang dibahas dalam biomarker sepsis anak, namun tidak spesifik
- [PDF p.17; fact #68] Rasio neutrofil/limfosit >10 adalah penanda bakteremia yang disebut dalam tabel; bukan konfirmasi sepsis tunggal
- [PDF p.17; fact #69] Prokalsitonin dapat meningkat pada kondisi non-infeksi, sehingga tidak berdiri sendiri untuk menegakkan diagnosis
- [PDF p.18; fact #70] Diagnosis sepsis anak PNPK berdasarkan kriteria disfungsi organ PELOD-2 ≥10
- [PDF p.18; fact #71] Skor PELOD-2 memuat neurologi GCS/pupil, laktat dan MAP sebagai parameter disfungsi organ
- [PDF p.19; fact #72] Parameter PELOD-2 meliputi kreatinin usia, PaO2/FiO2, PaCO2, ventilasi invasif, leukosit dan trombosit
- [PDF p.19; fact #73] PNPK sepsis anak menyebut kultur darah sebagai baku emas identifikasi patogen
- [PDF p.20; fact #74] Dua set kultur darah lokasi berbeda dan volume spesimen dibedakan anak vs neonatus
- [PDF p.44; fact #77] Kesimpulan PNPK sepsis anak menegaskan ambang PELOD-2 ≥10

## Terapi
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Rujukan
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Fakta dan Sitasi PDF

### 54 — diagnostic_criteria — PDF p.10
**Konsep:** Definisi sepsis anak: disfungsi organ yang mengancam jiwa disebabkan disregulasi imun terhadap infeksi
**Kutipan sumber:** - 10 - BAB III HASIL DAN PEMBAHASAN A. Definisi Sepsis adalah disfungsi organ yang mengancam kehidupan (life- threatening organ dysfunction) yang disebabkan oleh disregulasi imun terhadap infeksi. B. Epidemiologi Sepsis merupakan salah satu penyebab terbanyak pasien dirawat di ruang perawatan intensif anak (Pediatric Intensive Care Unit/PICU) dengan morbiditas dan mortalitas yang tinggi serta memerlukan biaya tinggi dalam perawatannya. Epidemiologi sepsis pada anak bervariasi dari berbagai penelitian akibat populasi dan kriteria diagnostik yang berbeda-beda dari waktu ke waktu. Pasien dewasa dan anak memiliki perbedaan epidemiologi, fisiologi, predisposisi dan pendekatan tata laksana sepsis. Di Amerika Serikat pada tahun 1995 terdapat 42.000 kasus sepsis berat pada anak di bawah 19 tahun. Bayi berusia kurang dari 1 tahun berisiko 10 kali
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 55 — diagnostic_criteria — PDF p.13
**Konsep:** Sepsis anak: kecurigaan atau bukti infeksi, penilaian warning signs, dan skor PELOD-2 ≥10
**Kutipan sumber:** kehidupan disebabkan oleh disregulasi sistem imun sebagai respons terhadap infeksi. Untuk menegakkan diagnosis sepsis diperlukan bukti adanya infeksi berupa tanda SIRS, faktor predisposisi dan anamnesis adanya kecurigaan ke arah infeksi baik dari sistem saraf pusat, respirasi, saluran kemih, saluran cerna dan lain sebagainya. Bila terdapat 2 dari 4 tanda SIRS langkah berikutnya adalah mencari tanda bahaya (warning sign) adanya risiko terjadinya disfungsi organ pada pasien yang dicurigai mengalami sepsis. Konsensus sepsis 3 merekomendasikan quick-sequential organ failure assessement (qSOFA) pada pasien dewasa yang dicurigai mengalami sepsis. Disfungsi organ yang mengancam kehidupan ditetapkan dengan menggunakan skor PELOD-2 dengan titik potong ≥10. Alur penegakan diagnosis sepsis tertera pada Gambar 1. jdih.kemkes.go.id
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 56 — diagnostic_criteria — PDF p.13
**Konsep:** PELOD-2 ≥10 dipakai PNPK sepsis anak untuk menilai disfungsi organ berat
**Kutipan sumber:** mengalami sepsis. Disfungsi organ yang mengancam kehidupan ditetapkan dengan menggunakan skor PELOD-2 dengan titik potong ≥10. Alur penegakan diagnosis sepsis tertera pada Gambar 1. jdih.kemkes.go.id
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 57 — population_context — PDF p.13
**Konsep:** PNPK anak menyebut qSOFA sebagai rekomendasi konsensus untuk dewasa; gunakan pendekatan PELOD-2 dalam populasi anak
**Kutipan sumber:** sepsis. Konsensus sepsis 3 merekomendasikan quick-sequential organ failure assessement (qSOFA) pada pasien dewasa yang dicurigai mengalami sepsis. Disfungsi organ yang mengancam kehidupan ditetapkan dengan menggunakan skor PELOD-2 dengan titik potong ≥10. Alur penegakan diagnosis sepsis tertera pada Gambar 1. jdih.kemkes.go.id
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 58 — signs_symptoms — PDF p.14
**Konsep:** Infeksi anak dapat ditandai demam atau hipotermia serta fokus infeksi
**Kutipan sumber:** infeksi berdasarkan pemeriksaan klinis dan laboratoris. Secara klinis ditandai oleh demam atau hipotermia, atau adanya fokus infeksi. Secara laboratoris, digunakan penanda (biomarker) infeksi: pemeriksaan darah tepi (leukositosis/leukopenia, trombositopenia/trombositosis, rasio netrofil:limfosit, shift to the left), pemeriksaan morfologi darah tepi (granula toksik, Dohle body, dan vakuola dalam sitoplasma), c-reactive protein (CRP), dan prokalsitonin. Sepsis memerlukan pembuktian adanya mikroorganisme yang dapat dilakukan melalui pemeriksaan pulasan gram, hasil
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 59 — laboratory — PDF p.14
**Konsep:** Biomarker pendukung pada sepsis anak termasuk leukosit, trombosit, CRP, prokalsitonin
**Kutipan sumber:** atau adanya fokus infeksi. Secara laboratoris, digunakan penanda (biomarker) infeksi: pemeriksaan darah tepi (leukositosis/leukopenia, trombositopenia/trombositosis, rasio netrofil:limfosit, shift to the left), pemeriksaan morfologi darah tepi (granula toksik, Dohle body, dan vakuola dalam sitoplasma), c-reactive protein (CRP), dan prokalsitonin. Sepsis memerlukan pembuktian adanya mikroorganisme yang dapat dilakukan melalui pemeriksaan pulasan gram, hasil kultur (biakan), atau PCR. Pencarian fokus infeksi lebih lanjut dilakukan dengan pemeriksaan analisis urin,
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 60 — supporting_investigation — PDF p.14
**Konsep:** Evaluasi infeksi anak melalui kultur, PCR, analisis urin, feses, LP, dan imaging berdasarkan fokus
**Kutipan sumber:** hasil kultur (biakan), atau PCR. Pencarian fokus infeksi lebih lanjut dilakukan dengan pemeriksaan analisis urin, feses rutin, lumbal pungsi dan pencitraan sesuai indikasi. Kemampuan menduga etiologi sepsis sangatlah penting untuk memberikan terapi yang tepat sesuai mikroorganisme yang dituju. Pemberian antibiotik empirik spektrum luas merupakan terapi sementara yang segera akan menjadi terapi definitif pada saat etiologi sepsis telah diketahui. Pada pasien klinis sepsis namun telah diketahui etiologinya, misal pada demam tifoid dengan komplikasi, tata laksana akan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 61 — physical_findings — PDF p.15
**Konsep:** SIRS pediatrik: demam suhu inti >38,5°C atau hipotermia <36°C
**Kutipan sumber:** mikroorganisme masuk ke dalam tubuh dan akan memberikan reaksi sistemik, sebagai berikut: a. Demam (suhu inti >38,5°C atau suhu aksila >37,9°C) atau hipotermia (suhu inti <36°C); b. Takikardia: rerata denyut jantung di atas normal sesuai usia tanpa adanya stimulus eksternal, obat kronis, atau nyeri; atau peningkatan denyut jantung yang tidak dapat dijelaskan lebih dari 30 menit sampai 4 jam (Tabel 2.); c. Bradikardia (pada anak <1 tahun): rerata denyut jantung di bawah normal sesuai usia tanpa adanya stimulus vagal eksternal, beta-blocker, atau penyakit jantung kongenital;
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 62 — physical_findings — PDF p.15
**Konsep:** Takikardia menurut usia dan bradikardia bayi <1 tahun dapat menjadi tanda inflamasi
**Kutipan sumber:** jantung yang tidak dapat dijelaskan lebih dari 30 menit sampai 4 jam (Tabel 2.); c. Bradikardia (pada anak <1 tahun): rerata denyut jantung di bawah normal sesuai usia tanpa adanya stimulus vagal eksternal, beta-blocker, atau penyakit jantung kongenital; atau penurunan denyut jantung yang tidak dapat dijelaskan selama lebih dari 30 menit (Tabel 2.); dan d. Takipnea: rerata frekuensi napas di atas normal (Tabel 2.) Tabel 2. Tanda-Tanda Vital Normal Pada Anak Denyut Jantung dan Frekuensi Napas Normal Sesuai Kelompok Usia Kelompok Usia Denyut Jantung per menit* Frekuensi Napas
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 63 — physical_findings — PDF p.15
**Konsep:** Takipnea ditentukan menurut nilai rujukan kelompok usia
**Kutipan sumber:** jantung yang tidak dapat dijelaskan selama lebih dari 30 menit (Tabel 2.); dan d. Takipnea: rerata frekuensi napas di atas normal (Tabel 2.) Tabel 2. Tanda-Tanda Vital Normal Pada Anak Denyut Jantung dan Frekuensi Napas Normal Sesuai Kelompok Usia Kelompok Usia Denyut Jantung per menit* Frekuensi Napas per menit# 0 hari – 1 bulan 100** - 190 ≤68 >1 bulan – <2 90** - 180 ≤58 tahun 2-5 tahun ≤160 ≤44 6-12 tahun ≤140 ≤38 13-18 tahun ≤130 ≤35 mean +2,2 SD, koreksi suhu 37°C [rumus denyut jantung normal terkoreksi suhu = denyut jantung terukur – 10(suhu terukur - 37°C)];
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 64 — red_flags_severity — PDF p.16
**Konsep:** Warning sign sepsis anak: GCS <11, dukungan oksigen untuk SpO2 >92%, gangguan kardiovaskular
**Kutipan sumber:** Persentil 5 tekanan darah sistolik sesuai kelompok usia 2. Kecurigaan Disfungsi Organ Kecurigaan disfungsi organ (warning signs) bila ditemukan 2 dari 3 tanda klinis: penurunan kesadaran yang ditandai dengan Glasgow Coma Scale (GCS) < 11, saturasi oksihemoglobin > 92% hanya dapat dicapai dengan terapi oksigen atau ventilasi mekanik, dan gangguan kardiovaskular, yang ditetapkan bila ditemukan sedikitnya dua dari tiga gelaja berikut, yaitu pemanjangan waktu pengisian kapiler, perbedaan suhu inti dan perifer > 30 C, dan produksi urin < 0,5 mL/kg/jam. Secara laboratoris, respons inflamasi berdasarkan pada jumlah leukosit, CRP, transaminase serum, dan prokalsitonin (Tabel 3). Diduga suatu infeksi jika dijumpai predisposisi, fokus, tanda dan gejala klinis infeksi berupa tiga dari empat gejala klinis di atas, ditambah dua atau lebih penanda biologis infeksi. Tabel 3.
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 65 — physical_findings — PDF p.16
**Konsep:** Gangguan kardiovaskular anak meliputi pengisian kapiler memanjang dan oliguria <0,5 mL/kg/jam
**Kutipan sumber:** kardiovaskular, yang ditetapkan bila ditemukan sedikitnya dua dari tiga gelaja berikut, yaitu pemanjangan waktu pengisian kapiler, perbedaan suhu inti dan perifer > 30 C, dan produksi urin < 0,5 mL/kg/jam. Secara laboratoris, respons inflamasi berdasarkan pada jumlah leukosit, CRP, transaminase serum, dan prokalsitonin (Tabel 3). Diduga suatu infeksi jika dijumpai predisposisi, fokus, tanda dan gejala klinis infeksi berupa tiga dari empat gejala klinis di atas, ditambah dua atau lebih penanda biologis infeksi. Tabel 3. Penanda Biologis Penanda Kegunaan Keterbatasan Cut-off Validitas
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 66 — laboratory — PDF p.16
**Konsep:** Leukosit, CRP, transaminase dan prokalsitonin adalah penanda penilaian sepsis anak
**Kutipan sumber:** suhu inti dan perifer > 30 C, dan produksi urin < 0,5 mL/kg/jam. Secara laboratoris, respons inflamasi berdasarkan pada jumlah leukosit, CRP, transaminase serum, dan prokalsitonin (Tabel 3). Diduga suatu infeksi jika dijumpai predisposisi, fokus, tanda dan gejala klinis infeksi berupa tiga dari empat gejala klinis di atas, ditambah dua atau lebih penanda biologis infeksi. Tabel 3. Penanda Biologis Penanda Kegunaan Keterbatasan Cut-off Validitas biologis Leukosit • Diagnosis Keterbatasan 1 bln-1 thn : Sensitivitas: untuk : tidak >17.500 atau 57,6% infeksi spesifik <5.000/mm3 Spesifitas: 53,5%
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 67 — laboratory — PDF p.17
**Konsep:** Limfopenia <1300/µL adalah temuan yang dibahas dalam biomarker sepsis anak, namun tidak spesifik
**Kutipan sumber:** Kegunaan Keterbatasan Cut-off Validitas biologis Limfosit • Limfopeni Keterbatasan <1300 /uL Sensitivitas: a : dapat 73,9% menunjuk menurun Spesifitas: 57,6% kan pada infeksi PPV: 63,6% diagnosis virus, NPV: 68,8% bakteremi penyakit a kritis, atau malnutrisi Rasio • Peningkat Keterbatasan >10 Sensitivitas: netrofil : an rasio : dapat 77,2% limfosit menunjuk menurun Spesifitas: 63,0% kan pada infeksi PPV: 67,6% diagnosis virus, NPV: 73,4% bakteremi penyakit a kritis, atau malnutrisi C- • Diagnosis Keterbatasan 1,56–110 mg/L Sensitivitas: 43- reactive
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 68 — laboratory — PDF p.17
**Konsep:** Rasio neutrofil/limfosit >10 adalah penanda bakteremia yang disebut dalam tabel; bukan konfirmasi sepsis tunggal
**Kutipan sumber:** 68,8% bakteremi penyakit a kritis, atau malnutrisi Rasio • Peningkat Keterbatasan >10 Sensitivitas: netrofil : an rasio : dapat 77,2% limfosit menunjuk menurun Spesifitas: 63,0% kan pada infeksi PPV: 67,6% diagnosis virus, NPV: 73,4% bakteremi penyakit a kritis, atau malnutrisi C- • Diagnosis Keterbatasan 1,56–110 mg/L Sensitivitas: 43- reactive untuk : kinetik 90% (infeksi); 31- protein infeksi lambat, tidak 82% (sepsis) (CRP) dan sepsis spesifik Spesifitas: 33- • Menentuk untuk 88% an derajat menunjukka PPV: 31-100% keparahan n infeksi NPV: 81-97%
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 69 — laboratory — PDF p.17
**Konsep:** Prokalsitonin dapat meningkat pada kondisi non-infeksi, sehingga tidak berdiri sendiri untuk menegakkan diagnosis
**Kutipan sumber:** 31-100% keparahan n infeksi NPV: 81-97% infeksi (meningkat pada keadaan inflamasi) Prokalsit 1. Diagnosis Keterbatasan 0,3–8,05 ng/ml Sensitivitas: 74,8- onin dini sepsis : dapat 100% (PCT) 2. Faktor meningkat Spesifitas: 70- prognostik pada 100% (indikator penyakit PPV: 55-100% perbaikan non-infeksi NPV: 56,3-100% sepsis) (trauma 3. Menentuk berat, pasca an lama henti pemberian jantung, antibiotik pembedahan, karsinoma tiroid medular, jdih.kemkes.go.id
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 70 — diagnostic_criteria — PDF p.18
**Konsep:** Diagnosis sepsis anak PNPK berdasarkan kriteria disfungsi organ PELOD-2 ≥10
**Kutipan sumber:** sistem saraf pusat, dan hepatik. Disfungsi organ ditegakkan berdasarkan skor PELOD-2. Diagnosis sepsis ditegakkan bila skor ≥10. Perhitungan skor PELOD-2 dapat dilihat pada Tabel 4. Tabel 4. Pediatric Logistic Organ Dysfunction (PELOD)-2 Disfungsi organ dan Poin Berdasarkan Tingkat Keparahan variabel 0 1 2 3 4 5 6 ≥ 11 5 - 3 - 4 Kedua Neurologi 10 -nya Glasgow Coma Score Kedua non - Pupillary reaction -nya reaktif reaktif < 5.0 5.0 – ≥ 10.9 11.0 Kardiovaskular Laktatemia (mmol/L) Mean arterial pressure (mmHg) ≥ 46 31 – 17 – ≤ 0 - < 1 bulan ≥ 55 45 30 16 1 – 11 bulan ≥ 60 39 – 25 – ≤ 12 – 23 bulan ≥ 62 54 38 24 24 – 59 bulan ≥ 65 44 – 31 – ≤ 60 – 143 bulan ≥ 67 59 43 30 ≥144 bulan 46 – 32 – ≤ 61 44 31 49 – 36 – ≤ 64 48 35 jdih.kemkes.go.id
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 71 — laboratory — PDF p.18
**Konsep:** Skor PELOD-2 memuat neurologi GCS/pupil, laktat dan MAP sebagai parameter disfungsi organ
**Kutipan sumber:** ditegakkan bila skor ≥10. Perhitungan skor PELOD-2 dapat dilihat pada Tabel 4. Tabel 4. Pediatric Logistic Organ Dysfunction (PELOD)-2 Disfungsi organ dan Poin Berdasarkan Tingkat Keparahan variabel 0 1 2 3 4 5 6 ≥ 11 5 - 3 - 4 Kedua Neurologi 10 -nya Glasgow Coma Score Kedua non - Pupillary reaction -nya reaktif reaktif < 5.0 5.0 – ≥ 10.9 11.0 Kardiovaskular Laktatemia (mmol/L) Mean arterial pressure (mmHg) ≥ 46 31 – 17 – ≤ 0 - < 1 bulan ≥ 55 45 30 16 1 – 11 bulan ≥ 60 39 – 25 – ≤ 12 – 23 bulan ≥ 62 54 38 24 24 – 59 bulan ≥ 65 44 – 31 – ≤ 60 – 143 bulan ≥ 67 59 43 30 ≥144 bulan 46
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 72 — laboratory — PDF p.19
**Konsep:** Parameter PELOD-2 meliputi kreatinin usia, PaO2/FiO2, PaCO2, ventilasi invasif, leukosit dan trombosit
**Kutipan sumber:** - 19 - 52 - 38 - ≤ 68 51 37 Renal Kreatinin (μmol/L) 0 - < 1bulan ≤ 69 ≥ 70 1 – 11 bulan ≤ 22 ≥ 23 12 – 23 bulan ≤ 34 ≥ 35 24 – 59 bulan ≤ 50 ≥ 51 60 – 143 bulan ≤ 58 ≥ 59 ≥144 bulan ≤ 92 ≥ 93 Respiratori ≥ ≤ 60 PaO2 (mmHg)/FiO2 PaCO2 (mmHg) ≤ 59 - ≥ 95 Ventilasi invasif Tidak 94 ya Hematologi > 2 ≤ 2 Hitung sel darah putih (x 109/L) ≥ 142 77 - ≤ 76 Platelet (x 109/L) 141 E. Penunjang Diagnosis Infeksi Kultur darah, merupakan baku emas untuk mendiagnosis sepsis. Tata cara pengambilan spesimen, sebagai berikut:
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 73 — supporting_investigation — PDF p.19
**Konsep:** PNPK sepsis anak menyebut kultur darah sebagai baku emas identifikasi patogen
**Kutipan sumber:** putih (x 109/L) ≥ 142 77 - ≤ 76 Platelet (x 109/L) 141 E. Penunjang Diagnosis Infeksi Kultur darah, merupakan baku emas untuk mendiagnosis sepsis. Tata cara pengambilan spesimen, sebagai berikut: 1. Alat a. Wing needle. b. Botol kultur darah (Bactec/BacTAlert). c. Antiseptik. d. Sarung tangan steril. e. Kapas alcohol. 2. Waktu Pengambilan Spesimen a. Darah diambil sebaiknya pada saat suhu badan naik. b. Untuk tifoid diambil pada demam minggu pertama. c. Sebaiknya sebelum pemberian antibiotik atau setelah 3 hari antibiotik dihentikan. d. Bila pasien telah mendapat antibiotik,
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 74 — supporting_investigation — PDF p.20
**Konsep:** Dua set kultur darah lokasi berbeda dan volume spesimen dibedakan anak vs neonatus
**Kutipan sumber:** didekontaminasi tidak boleh dipalpasi ulang kecuali memakai sarung tangan steril. f. Ambil 2 set dalam satu waktu pada lokasi yang berbeda dengan tenggang waktu 5 sampai 10 menit (untuk kasus infektif endokarditis ambil 3 set darah dalam satu waktu dari tiga lokasi yang berbeda). Satu set adalah satu botol kultur darah aerob dan 1 botol kultur darah anaerob pada satu sisi lengan. 4. Catatan Untuk Volume Darah Yang Diambil/Botol Kultur Darah 1) Anak-anak: darah vena diambil 5-10 ml. 2) Neonatus - Infant: darah vena diambil 1-3 ml. a. Masukkan spesimen darah secara aseptik
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 75 — red_flags_severity — PDF p.34
**Konsep:** Sepsis tidak respons cairan dapat berkembang menjadi renjatan sepsis
**Kutipan sumber:** noninvasif/invasif yang memadai (peralatan dan operator) Tabel 10. Parameter refrakter cairan Sepsis yang tidak respons dengan cairan ditata laksana sebagai renjatan sepsis atau septik syok. Renjatan sepsis adalah sepsis yang membutuhkan obat vasoaktif untuk mempertahankan jdih.kemkes.go.id
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 76 — physical_findings — PDF p.35
**Konsep:** Syok dingin: ekstremitas dingin akibat vasokonstriksi; syok hangat: ekstremitas hangat karena vasodilatasi
**Kutipan sumber:** Panduan penggunaan obat vasoaktif tergantung pada tipe renjatan atau syok (Tabel 11). Syok dingin adalah syok yang ditandai ekstremitas dingin akibat vasokonstriksi perifer, sedangkan syok hangat adalah syok yang ditandai ekstremitas hangat akibat vasodilatasi perifer. Tabel 11. Profil hemodinamik dan pilihan obat vasoaktif pada syok anak Profil Pilihan Obat No. Jenis Syok Karakteristik Hemodinamik Vasoaktif* 1 Syok dingin Low output, • Akral dingin Inotropik dengan high resistance • Waktu • Epinefrin normotensi + Normotensi pengisian 0,05-0,3 kapiler >2 mcg/kg/mnt
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 77 — diagnostic_criteria — PDF p.44
**Konsep:** Kesimpulan PNPK sepsis anak menegaskan ambang PELOD-2 ≥10
**Kutipan sumber:** Prognosis Disfungsi organ yang mengancam kehidupan ditetapkan dengan menggunakan skor PELOD-2 dengan titik potong ≥ 10. jdih.kemkes.go.id
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

**Batas cakupan:** Diagnosis-oriented curation; terapi dan rujukan tidak dikurasi dalam checkpoint sumber. Tidak ada clinical approval independen.

