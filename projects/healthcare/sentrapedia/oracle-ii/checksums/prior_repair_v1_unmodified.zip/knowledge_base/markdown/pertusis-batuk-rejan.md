---
id: 308
title: "Pertusis (Batuk Rejan)"
slug: "pertusis-batuk-rejan"
icd_10: "A37.9"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Pertusis (Batuk Rejan)

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Pertusis (whooping cough / batuk seratus hari) adalah infeksi bakteri akut saluran napas yang sangat menular yang disebabkan oleh Bordetella pertussis, ditandai dengan serangan batuk paroksismal hebat diakhiri suara tarikan napas melengking (whoop).

## Gejala
- Stadium kataral (1-2 minggu): batuk ringan, pilek, bersin, demam subfebris
- Stadium paroksismal (2-6 minggu): batuk paroksismal beruntun (staccato cough) 5-15 kali tanpa henti, tarikan napas dalam bernada tinggi (whoop), muntah pasca-batuk (post-tussive emesis), sianosis perioral saat batuk
- Stadium konvalesen: batuk berkurang bertahap selama berminggu-minggu

## Diagnosis
Diagnosis klinis ditegakkan dari riwayat batuk paroksismal khas > 2 minggu dengan whoop inspiratorik atau post-tussive emesis, terutama pada anak tanpa imunisasi DTP lengkap. Penunjang laboratorium: leukositosis nyata (20.000-50.000/uL) dengan limfositosis absolut dominan.

## Terapi
1. Antibiotik Makrolida Lini Pertama (efektif mengeliminasi kuman bila diberikan dini):
   - Azitromisin: 10 mg/kgBB/hari oral dosis tunggal pada hari ke-1 (maks 500 mg), dilanjutkan 5 mg/kgBB/hari pada hari 2-5 (maks 250 mg).
   - Alternatif: Eritromisin 40-50 mg/kgBB/hari oral dibagi 4 dosis selama 14 hari, atau Klaritromisin 15 mg/kgBB/hari dibagi 2 dosis selama 7 hari.
2. Suportif: oksigenasi, menjaga jalan napas, asupan nutrisi porsi kecil sering pasca-muntah.

## Rujukan
Rujuk SEGERA ke RS / ruang rawat intensif anak bila terjadi pada bayi usia < 6 bulan, episode apnea, sianosis berat, kejang hipoksik, pneumonia sekunder, atau ensefalopati pertusis.

