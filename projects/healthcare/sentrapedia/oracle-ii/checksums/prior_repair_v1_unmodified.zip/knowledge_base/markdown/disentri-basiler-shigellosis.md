---
id: 295
title: "Disentri Basiler (Shigellosis)"
slug: "disentri-basiler-shigellosis"
icd_10: "A03.9"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Disentri Basiler (Shigellosis)

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Disentri basiler adalah infeksi invasif usus besar yang disebabkan oleh bakteri genus Shigella (S. dysenteriae, S. flexneri, S. sonnei, S. boydii), ditandai dengan peradangan mukosa kolon, ulserasi, dan eksudat inflamasi.

## Gejala
- Diare dengan tinja berlendir dan bercampur darah
- Tenesmus (rasa mengedan dan nyeri saat BAB)
- Kram perut hebat
- Demam tinggi mendadak
- Mual dan muntah
- Anoreksia

## Diagnosis
Ditegakkan berdasarkan anamnesis sindrom disentri (diare lendir darah + tenesmus + demam). Pemeriksaan feses mikroskopis langsung menunjukkan eritrosit banyak, leukosit PMN melimpah (> 10-15 per LPB), dan makrofag, tanpa ditemukan trofozoit amuba.

## Terapi
1. Rehidrasi oralit atau cairan IV sesuai derajat dehidrasi.
2. Antibiotik Lini Pertama:
   - Siprofloksasin 2 x 500 mg oral selama 3-5 hari (dewasa).
   - Azitromisin 1 x 500 mg oral pada hari 1, dilanjutkan 1 x 250 mg hari 2-5 (pilihan anak dan ibu hamil).
   - Seftriakson 50-100 mg/kgBB/hari IV selama 3-5 hari pada kasus berat/rawat inap.
3. Antipiretik parasetamol bila demam. KONTRAINDIKASI obat antimotilitas usus (loperamid/diphenoxylate) karena memperparah invasi toksin dan memicu megakolon toksik.

## Rujukan
Rujuk ke RS bila terjadi komplikasi megakolon toksik, perforasi usus, prolaps rekti, sindrom hemolitik uremik (HUS), dehidrasi berat tidak teratasi, atau malnutrisi berat pada balita.

