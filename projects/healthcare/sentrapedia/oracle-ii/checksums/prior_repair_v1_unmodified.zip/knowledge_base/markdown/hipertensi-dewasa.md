---
id: 221
title: "Hipertensi Dewasa"
slug: "hipertensi-dewasa"
icd_10: "I10"
clinical_qa_status: "SOURCE_GROUNDED_DIAGNOSTIC_SUBSET"
is_complete: false
verified_clinical_kb: false
---

# Hipertensi Dewasa

> **Clinical QA: SOURCE_GROUNDED_DIAGNOSTIC_SUBSET.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

**Sumber:** 035_PNPK_2021_Tata_Laksana_Hipertensi_Dewasa.pdf (HK.01.07/MENKES/4634/2021)
**Regulasi:** SUPERSEDED
**Populasi:** dewasa

> **Historical only:** PNPK ini telah digantikan. Jangan digunakan sebagai pedoman klinis aktif.

## Definisi
Hipertensi adalah suatu keadaan dimana tekanan darah sistolik >140 mmHg dan/atau diastolik >90 mmHg. (PDF p.10)

## Gejala
- Tanda gejala komplikasi kardiovaskular: nyeri dada, sesak, edema, palpitasi dan sinkop
- Gejala kerusakan organ otak dan mata meliputi TIA, gangguan penglihatan, defisit sensorimotor dan stroke

## Diagnosis (ringkasan berbasis fakta terkurasi)
- [PDF p.10; fact #118] PNPK historis hipertensi dewasa memakai TDS ≥140 dan/atau TDD ≥90 mmHg
- [PDF p.10; fact #119] Klasifikasi hipertensi dewasa derajat 1: sistolik 140–159 dan/atau diastolik 90–99 mmHg
- [PDF p.10; fact #120] Klasifikasi hipertensi dewasa derajat 2: sistolik 160–179 dan/atau diastolik 100–109 mmHg
- [PDF p.10; fact #121] Klasifikasi hipertensi dewasa derajat 3: sistolik ≥180 dan/atau diastolik ≥110 mmHg
- [PDF p.10; fact #122] Hipertensi sistolik terisolasi: sistolik ≥140 dengan diastolik <90 mmHg
- [PDF p.11; fact #126] Hipertensi baru derajat 2–3 pada usia <40 tahun atau perburukan mendadak perlu evaluasi sekunder
- [PDF p.11; fact #127] Kecurigaan feokromositoma: berkeringat, sakit kepala, cemas dan palpitasi berulang
- [PDF p.11; fact #128] Hipokalemia spontan atau setelah diuretik dan kelemahan otot dapat mengarah hiperaldosteronisme
- [PDF p.12; fact #129] Hipertensi sekunder dapat disebabkan sleep apnea dengan mengorok dan mengantuk siang
- [PDF p.12; fact #130] Evaluasi penyakit parenkim ginjal dapat menggunakan kreatinin, elektrolit, eGFR, rasio albumin kreatinin dan USG
- [PDF p.12; fact #131] Doppler arteri renalis, CT atau MR angiografi dipakai untuk penilaian hipertensi renovaskular
- [PDF p.13; fact #132] Feokromositoma dicurigai dengan hipertensi paroksismal, palpitasi, pucat dan keringat; evaluasi metanefrin
- [PDF p.13; fact #172] Hipokalemia merupakan petunjuk laboratorium untuk evaluasi hiperaldosteronisme primer
- [PDF p.47; fact #175] Evaluasi emergensi dapat mencakup funduskopi, EKG, kreatinin, elektrolit dan urinalisis
- [PDF p.47; fact #176] Hipertensi urgensi berbeda dari emergensi karena tanpa bukti klinis kerusakan organ target

## Terapi
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Rujukan
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Fakta dan Sitasi PDF

### 118 — diagnostic_criteria — PDF p.10
**Konsep:** PNPK historis hipertensi dewasa memakai TDS ≥140 dan/atau TDD ≥90 mmHg
**Kutipan sumber:** - 10 - BAB III HASIL DAN PEMBAHASAN A. Definisi dan Klasifikasi Hipertensi Hipertensi adalah suatu keadaan dimana tekanan darah sistolik >140 mmHg dan/atau diastolik >90 mmHg. Tabel 1. Rekomendasi klasifikasi TD Rekomendasi Peringkat Bukti Derajat Rekomendasi TD diklasifikasikan menjadi optimal, I C normal, normal-tinggi, atau hipertensi derajat 1-3, berdasarkan pengukuran
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 119 — diagnostic_criteria — PDF p.10
**Konsep:** Klasifikasi hipertensi dewasa derajat 1: sistolik 140–159 dan/atau diastolik 90–99 mmHg
**Kutipan sumber:** Bukti Derajat Rekomendasi TD diklasifikasikan menjadi optimal, I C normal, normal-tinggi, atau hipertensi derajat 1-3, berdasarkan pengukuran TD di klinik Sumber: Williams B, Mancia G, Spiering W, Agabiti RE, Azizi M, Burnier M, et al; ESC Scientific Document Group. 2018 ESC/ESH Guidelines for the management of arterial hypertension. Eur Heart J. 2018;39:3021-104. Tabel 2. Klasifikasi
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 120 — diagnostic_criteria — PDF p.10
**Konsep:** Klasifikasi hipertensi dewasa derajat 2: sistolik 160–179 dan/atau diastolik 100–109 mmHg
**Kutipan sumber:** dan/atau 80-84 Normal tinggi 130-139 dan/atau 85-89 Hipertensi derajat 1 140-159 dan/atau 90-99 Hipertensi derajat 2 160-179 dan/atau 100-109 Hipertensi derajat 3 ≥180 dan/atau ≥110 Hipertensi sistolik ≥140 dan <90 terisolasi Sumber: Williams B, Mancia G, Spiering W, Agabiti RE, Azizi M, Burnier M, et al; ESC Scientific Document Group. 2018 ESC/ESH Guidelines for the management of arterial
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 121 — diagnostic_criteria — PDF p.10
**Konsep:** Klasifikasi hipertensi dewasa derajat 3: sistolik ≥180 dan/atau diastolik ≥110 mmHg
**Kutipan sumber:** 85-89 Hipertensi derajat 1 140-159 dan/atau 90-99 Hipertensi derajat 2 160-179 dan/atau 100-109 Hipertensi derajat 3 ≥180 dan/atau ≥110 Hipertensi sistolik ≥140 dan <90 terisolasi Sumber: Williams B, Mancia G, Spiering W, Agabiti RE, Azizi M, Burnier M, et al; ESC Scientific Document Group. 2018 ESC/ESH Guidelines for the management of arterial hypertension. Eur Heart J. 2018;39:3021-104.
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 122 — diagnostic_criteria — PDF p.10
**Konsep:** Hipertensi sistolik terisolasi: sistolik ≥140 dengan diastolik <90 mmHg
**Kutipan sumber:** dan/atau 90-99 Hipertensi derajat 2 160-179 dan/atau 100-109 Hipertensi derajat 3 ≥180 dan/atau ≥110 Hipertensi sistolik ≥140 dan <90 terisolasi Sumber: Williams B, Mancia G, Spiering W, Agabiti RE, Azizi M, Burnier M, et al; ESC Scientific Document Group. 2018 ESC/ESH Guidelines for the management of arterial hypertension. Eur Heart J. 2018;39:3021-104. B. Epidemiologi Prevalensi global pasien
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 123 — population_context — PDF p.11
**Konsep:** Anamnesis hipertensi meliputi riwayat hipertensi, stroke dan penyakit ginjal pada individu dan keluarga
**Kutipan sumber:** riwayat individu dan keluarga (Tabel 3.). Tabel 3. Anamnesis riwayat dan faktor risiko Faktor risiko Riwayat menderita hipertensi, penyakit kardiovaskular, stroke, atau penyakit ginjal pada individu dan keluarga Riwayat faktor risiko hipertensi pada individu dan keluarga (misal: hiperkolesterolemia familial) Riwayat merokok Riwayat pola diet dan konsumsi garam Riwayat konsumsi alcohol Kurangnya
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 124 — signs_symptoms — PDF p.11
**Konsep:** Tanda gejala komplikasi kardiovaskular: nyeri dada, sesak, edema, palpitasi dan sinkop
**Kutipan sumber:** revaskularisasi arteri karotis, gangguan kognitif, demensia pada geriatri, gangguan penglihatan Jantung: nyeri dada, sesak nafas, edema, infark miokard, revaskularisasi koroner, sinkop, riwayat palpitasi, aritmia (fibrilasi atrial), gagal jantung Ginjal: poliuria, nokturia, hematuria, infeksi saluran kemih Arteri perifer: akral dingin, klaudikasio intermitten (nyeri pada tungkai menghilang
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 125 — signs_symptoms — PDF p.11
**Konsep:** Gejala kerusakan organ otak dan mata meliputi TIA, gangguan penglihatan, defisit sensorimotor dan stroke
**Kutipan sumber:** gejala kerusakan organ akibat hipertensi, penyakit kardiovaskular, stroke, dan penyakit ginjal Otak dan mata: sakit kepala, vertigo, sinkop, TIA, defisit sensoris dan motoris, stroke, revaskularisasi arteri karotis, gangguan kognitif, demensia pada geriatri, gangguan penglihatan Jantung: nyeri dada, sesak nafas, edema, infark miokard, revaskularisasi koroner, sinkop, riwayat palpitasi,
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 126 — differential_diagnosis — PDF p.11
**Konsep:** Hipertensi baru derajat 2–3 pada usia <40 tahun atau perburukan mendadak perlu evaluasi sekunder
**Kutipan sumber:** ginjal poilikistik) Riwayat kemungkinan hipertensi sekunder Terdiagnosis hipertensi derajat 2-3 pada usia muda (<40 tahun), atau perburukan hipertensi yang mendadak pada pasien usia tua. Riwayat penyakit ginjal/saluran kemih Penggunaan obat ‘recreational’/ penyalahgunaan obat/terapi yang dijalani saat ini: kortikosteroid, vasokontriktor nasal, kemoterapi, yohimbine, liquorice Adanya gejala
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 127 — differential_diagnosis — PDF p.11
**Konsep:** Kecurigaan feokromositoma: berkeringat, sakit kepala, cemas dan palpitasi berulang
**Kutipan sumber:** yohimbine, liquorice Adanya gejala berkeringat, sakit kepala, cemas, atau palpitasi yang berulang dan mengarah kecurigaan adanya feokromositoma Riwayat hipokalemia baik spontan maupun akibat diuretik, gejala kelemahan otot, dan tetani (hiperaldosteronisme) Gejala sugestif penyakit tiroid atau hiperparatiroidism Riwayat kehamilan saat ini dan penggunaan kontrasepsi Riwayat sleep apnoe Terapi
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 128 — differential_diagnosis — PDF p.11
**Konsep:** Hipokalemia spontan atau setelah diuretik dan kelemahan otot dapat mengarah hiperaldosteronisme
**Kutipan sumber:** feokromositoma Riwayat hipokalemia baik spontan maupun akibat diuretik, gejala kelemahan otot, dan tetani (hiperaldosteronisme) Gejala sugestif penyakit tiroid atau hiperparatiroidism Riwayat kehamilan saat ini dan penggunaan kontrasepsi Riwayat sleep apnoe Terapi obat antihipertensi Riwayat penggunaan obat antihipertensi saat ini ataupun sebelumnya, baik efektivitas maupun intoleransi terhadap
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 129 — differential_diagnosis — PDF p.12
**Konsep:** Hipertensi sekunder dapat disebabkan sleep apnea dengan mengorok dan mengantuk siang
**Kutipan sumber:** Tabel 4. Etiologi sekunder hipertensi Penyebab Prevalensi Gejala dan tanda sugestif Investigasi Obstructive sleep 5-10% Mengorok; obesitas; sakit Skor Epworth apnoe kepala pagi hari; dan tes poligraf mengantuk pada siang selama 24 jam hari Penyakit parenkim 2-10% Biasanya asimtomatik: Kreatinin ginjal diabetes; hematuria, plasma dan proteinuria, nokturia; elektrolit, eGFR; anemia, masa
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 130 — supporting_investigation — PDF p.12
**Konsep:** Evaluasi penyakit parenkim ginjal dapat menggunakan kreatinin, elektrolit, eGFR, rasio albumin kreatinin dan USG
**Kutipan sumber:** sakit Skor Epworth apnoe kepala pagi hari; dan tes poligraf mengantuk pada siang selama 24 jam hari Penyakit parenkim 2-10% Biasanya asimtomatik: Kreatinin ginjal diabetes; hematuria, plasma dan proteinuria, nokturia; elektrolit, eGFR; anemia, masa ginjal pada dipstik urin pasien dewasa yang untuk darah mengalami penyakit ginjal dan protein, kronik akibat polikistik rasio albumin:kreatin
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 131 — supporting_investigation — PDF p.12
**Konsep:** Doppler arteri renalis, CT atau MR angiografi dipakai untuk penilaian hipertensi renovaskular
**Kutipan sumber:** albumin:kreatin in urin; USG ginjal Penyakit vaskular ginjal Aterosklerosis 1-10% Pada usia tua: PAD; Duplex renal vaskular ginjal diabetes; riwayat merokok; artery doppler, edema pulmonal rekuren; CT angiografi, bruit abdomen MR angiografi Fibromuskular Pada usia muda; biasanya dysplasia pada perempuan; bruit abdomen Penyebab endokrin Aldosteronisme 5-15% Biasanya asimtomatik: Aldosteron dan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 132 — supporting_investigation — PDF p.13
**Konsep:** Feokromositoma dicurigai dengan hipertensi paroksismal, palpitasi, pucat dan keringat; evaluasi metanefrin
**Kutipan sumber:** jumlah kecil): Hipokalemia dapat menurunkan jumlah aldosteron. Feokromositoma <1% Gejala: hipertensi Metanefrin paroksismal, sakit kepala terfraksi pada berdenyut, berkeringat, plasma atau palpitasi, dan pucat, TD urin 24 jam yang labil; TD yang naik disebabkan oleh obat (opioid, antidepresan, metoklorpramid, penyekat beta) Sindrom Cushing’s <1% Moon face, obesitas Urin 24 jam sentral, atrofi
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 133 — physical_findings — PDF p.13
**Konsep:** Perbedaan tekanan darah ekstremitas dan pulsasi radial–femoral dapat menunjang koarktasio aorta
**Kutipan sumber:** hipotiroidisme) Hiperparatiroidisme <1% Hiperkalsemia, Hormon hipoposfatemia paratiroid, Ca2+ Penyebab lain Koarktasio aorta <1% Biasanya terdeteksi pada Ekokardiografi usia anak-remaja TD (≥20/10 mmHg) antara ekstremitas atas-bawah, atau antara kedua lengan dan pulsasi radial-femoral yang melambat; ABI rendah, murmur ejeksi interskapula; rib notching pada foto toraks Sumber: Williams B, Mancia G,
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 134 — population_context — PDF p.14
**Konsep:** Evaluasi hipertensi mencakup faktor metabolik diabetes dan risiko kardiovaskular
**Kutipan sumber:** - 14 - 2. Penentuan Risiko Kardiovaskular Direkomendasikan untuk selalu mencari faktor risiko metabolik (diabetes, gangguan tiroid dan lainnya) pada pasien dengan hipertensi dengan atau tanpa penyakit jantung dan pembuluh darah. Penilaian faktor risiko dapat menggunakan sesuai pedoman European Society of Cardiologist (ESC) (Tabel 5 dan 6.) dan World Health Organization
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 135 — population_context — PDF p.55
**Konsep:** Diagnosis hipertensi lansia membutuhkan anamnesis dan pemeriksaan klinis secara cermat
**Kutipan sumber:** - 55 - hipotensi postural karena dapat memperburuk komorbiditas tersebut. Untuk menegakkan diagnosis hipertensi pada lanjut usia, diperlukan anamnesis mendalam, pemeriksaan fisik dan pemeriksaan laboratorium dan penunjang yang bertujuan untuk mengidentifikasi onset terjadinya hipertensi (onset baru, kronis atau hipertensi sekunder), mengevaluasi risiko kardiovaskular secara
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 172 — laboratory — PDF p.13
**Konsep:** Hipokalemia merupakan petunjuk laboratorium untuk evaluasi hiperaldosteronisme primer
**Kutipan sumber:** - 13 - Penyebab Prevalensi Gejala dan tanda sugestif Investigasi hipokalemia (dalam jumlah kecil): Hipokalemia dapat menurunkan jumlah aldosteron. Feokromositoma <1% Gejala: hipertensi Metanefrin paroksismal, sakit kepala terfraksi pada berdenyut, berkeringat, plasma atau palpitasi, dan pucat, TD urin 24 jam yang labil; TD yang naik disebabkan oleh obat
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 173 — red_flags_severity — PDF p.46
**Konsep:** Hipertensi emergensi dewasa melibatkan tekanan darah berat dan kerusakan organ akut
**Kutipan sumber:** Hipertensi Krisis (Hipertensi Emergensi dan Urgensi) Hipertensi Emergensi Hipertensi emergensi adalah hipertensi derajat 3 (TDS ≥180 dan/atau TDD ≥110) dengan HMOD akut. Hal ini sering kali mengancam jiwa dan memerlukan penanganan segera dan seksama. Untuk menurunkan tekanan darah biasanya memerlukan obat intravena. Besar dan cepatnya peningkatan TD sama pentingnya dengan menentukan batas TD
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 174 — red_flags_severity — PDF p.46
**Konsep:** Hipertensi maligna dapat disertai perdarahan retina, papiledema, ensefalopati dan gagal ginjal akut
**Kutipan sumber:** Hipertensi maligna: hipertensi berat (umumnya derajat 3) dengan perubahan gambaran funduskopi (perdarahan retina dan atau papiledema), mikroangiopati dan koagulasi intravaskular diseminata serta ensefalopati (terjadi pada sekitar 15% kasus), gagal jantung akut, penurunan fungsi ginjal akut. Gambaran dapat berupa nekrosis fibrinoid arteri kecil di ginjal, retina dan otak. Makna maligna
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 175 — supporting_investigation — PDF p.47
**Konsep:** Evaluasi emergensi dapat mencakup funduskopi, EKG, kreatinin, elektrolit dan urinalisis
**Kutipan sumber:** - 47 - penurunan tekanan darah hendaknya dilakukan dengan hati- hati. Pemeriksaan yang umum di lakukan pada keadaan hipertensi emergensi adalah funduskopi, EKG 12-lead, pemeriksaan kimia darah (haemoglobin, hitung trombosit, fibrinogen, kreatinin, eGFR, elektrolit, LDH dan haptoglobin), rasio albumin kreatinin urin, urinalisa untuk melihat sel darah merah, leukosit
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 176 — differential_diagnosis — PDF p.47
**Konsep:** Hipertensi urgensi berbeda dari emergensi karena tanpa bukti klinis kerusakan organ target
**Kutipan sumber:** penggunaan methamphetamine atau kokain. Hipertensi Urgensi Hipertensi urgensi merupakan hipertensi berat tanpa bukti klinis keterlibatan organ target. Umumnya tidak memerlukan rawat inap dan dapat diberikan obat oral sesuai dengan algoritma tata laksana hiperteni urgensi. Peningkatan tekanan darah mendadak dapat diakibatkan obat- obat simpatomimetik. Keluhan nyeri dada berat atau stres psikis
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

**Batas cakupan:** Diagnosis-oriented curation; terapi dan rujukan tidak dikurasi dalam checkpoint sumber. Tidak ada clinical approval independen.

