---
id: 170
title: "Katarak Pada Dewasa"
slug: "katarak-pada-dewasa"
icd_10: "H25-H28"
clinical_qa_status: "QUARANTINED_PNPK_SOURCE_REQUIRED"
is_complete: false
verified_clinical_kb: false
---

# Katarak Pada Dewasa

> **Clinical QA: QUARANTINED_PNPK_SOURCE_REQUIRED.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Arsip PNPK sebelumnya mengandung section misclassification; semua field klinis lama dipindah ke `raw_original/` untuk audit.

**Referensi sumber:** PNPK 2018

## Definisi
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Gejala
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Diagnosis
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Terapi
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Rujukan
Belum tersedia — lengkapi dan verifikasi oleh klinisi

