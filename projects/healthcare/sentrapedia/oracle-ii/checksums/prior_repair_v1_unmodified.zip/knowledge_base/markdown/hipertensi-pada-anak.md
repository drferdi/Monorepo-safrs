---
id: 220
title: "Hipertensi Pada Anak"
slug: "hipertensi-pada-anak"
icd_10: "I10"
clinical_qa_status: "SOURCE_GROUNDED_DIAGNOSTIC_SUBSET"
is_complete: false
verified_clinical_kb: false
---

# Hipertensi Pada Anak

> **Clinical QA: SOURCE_GROUNDED_DIAGNOSTIC_SUBSET.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

**Sumber:** 034_PNPK_2021_Tata_Laksana_Hipertensi_Pada_Anak.pdf (HK.01.07/MENKES/4613/2021)
**Regulasi:** UNVERIFIED
**Populasi:** anak

## Definisi
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Gejala
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Diagnosis (ringkasan berbasis fakta terkurasi)
- [PDF p.10; fact #154] Klasifikasi hipertensi anak 1–13 tahun berdasarkan persentil usia/jenis kelamin/tinggi badan
- [PDF p.10; fact #155] Anak 1–13 tahun: tekanan darah normal jika sistolik dan diastolik <persentil 90
- [PDF p.10; fact #156] Anak 1–13 tahun: tekanan darah meningkat pada persentil ≥90 hingga <95
- [PDF p.10; fact #157] Anak ≥13 tahun hipertensi derajat 1 pada 130/80–138/89 mmHg menurut tabel PNPK
- [PDF p.10; fact #158] Anak ≥13 tahun hipertensi derajat 2 pada ≥140/90 mmHg menurut tabel PNPK
- [PDF p.11; fact #160] Tabel skrining tekanan darah disederhanakan membutuhkan evaluasi jika melewati ambang
- [PDF p.12; fact #161] Hipertensi primer lebih sering pada anak ≥6 tahun dengan obesitas atau riwayat keluarga
- [PDF p.12; fact #162] Hipertensi sekunder pada anak sering terkait penyakit parenkim ginjal dan renovaskular
- [PDF p.15; fact #168] Temuan kulit akantosis nigrikans dapat mengarah pada diabetes tipe 2 sebagai komorbid
- [PDF p.16; fact #169] Pengukuran tekanan darah anak dianjurkan setelah istirahat 5 menit
- [PDF p.17; fact #170] Tekanan darah anak >persentil 90 perlu dua pengukuran tambahan dan dirata-ratakan
- [PDF p.41; fact #182] Hipertensi urgensi anak perlu dibedakan dari emergensi berdasarkan kerusakan organ

## Terapi
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Rujukan
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Fakta dan Sitasi PDF

### 154 — diagnostic_criteria — PDF p.10
**Konsep:** Klasifikasi hipertensi anak 1–13 tahun berdasarkan persentil usia/jenis kelamin/tinggi badan
**Kutipan sumber:** seperti terlihat pada tabel 1. Tabel 1. Klasifikasi Hipertensi pada anak menurut AAP tahun 2017 Anak Usia 1-13 Anak usia ≥ 13 tahun tahun Tekanan darah normal Sistolik dan diastolik < 120/80 mmHg < persentil 90 Tekanan darah Sistolik dan diastolik meningkat ≥ persentil 90 tetapi 120/<80 mmHg < persentil 95, -129/< 80 mmHg atau 120/80mmHg tetapi < persentil 95 Sistolik dan Diastolik diantara
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 155 — diagnostic_criteria — PDF p.10
**Konsep:** Anak 1–13 tahun: tekanan darah normal jika sistolik dan diastolik <persentil 90
**Kutipan sumber:** Usia 1-13 Anak usia ≥ 13 tahun tahun Tekanan darah normal Sistolik dan diastolik < 120/80 mmHg < persentil 90 Tekanan darah Sistolik dan diastolik meningkat ≥ persentil 90 tetapi 120/<80 mmHg < persentil 95, -129/< 80 mmHg atau 120/80mmHg tetapi < persentil 95 Sistolik dan Diastolik diantara persentil 95 dan 130/80 mmHg Hipertensi tingkat 1 persentil 95 + 12 -138/89 mmHg mmHg, atau 130/80
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 156 — diagnostic_criteria — PDF p.10
**Konsep:** Anak 1–13 tahun: tekanan darah meningkat pada persentil ≥90 hingga <95
**Kutipan sumber:** Sistolik dan diastolik < 120/80 mmHg < persentil 90 Tekanan darah Sistolik dan diastolik meningkat ≥ persentil 90 tetapi 120/<80 mmHg < persentil 95, -129/< 80 mmHg atau 120/80mmHg tetapi < persentil 95 Sistolik dan Diastolik diantara persentil 95 dan 130/80 mmHg Hipertensi tingkat 1 persentil 95 + 12 -138/89 mmHg mmHg, atau 130/80 mmHg -138/89 mmHg Sistolik atau Hipertensi tingkat 2 Diastolik
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 157 — diagnostic_criteria — PDF p.10
**Konsep:** Anak ≥13 tahun hipertensi derajat 1 pada 130/80–138/89 mmHg menurut tabel PNPK
**Kutipan sumber:** atau 120/80mmHg tetapi < persentil 95 Sistolik dan Diastolik diantara persentil 95 dan 130/80 mmHg Hipertensi tingkat 1 persentil 95 + 12 -138/89 mmHg mmHg, atau 130/80 mmHg -138/89 mmHg Sistolik atau Hipertensi tingkat 2 Diastolik ≥ persentil ≥140/90mmHg 95 + 12 mmHg, atau ≥140/90 mmHg Sumber : Pedoman AAP tahun 2017 Pada tahun 2017 AAP juga mengeluarkan tabel normatif tekanan darah yang
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 158 — diagnostic_criteria — PDF p.10
**Konsep:** Anak ≥13 tahun hipertensi derajat 2 pada ≥140/90 mmHg menurut tabel PNPK
**Kutipan sumber:** Hipertensi tingkat 1 persentil 95 + 12 -138/89 mmHg mmHg, atau 130/80 mmHg -138/89 mmHg Sistolik atau Hipertensi tingkat 2 Diastolik ≥ persentil ≥140/90mmHg 95 + 12 mmHg, atau ≥140/90 mmHg Sumber : Pedoman AAP tahun 2017 Pada tahun 2017 AAP juga mengeluarkan tabel normatif tekanan darah yang telah disederhanakan, yang bertujuan sebagai alat skrining dalam mengidentifikasi anak dan remaja yang
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 159 — population_context — PDF p.11
**Konsep:** Neonatus/bayi usia 0–1 tahun menggunakan kurva Second Task Force, bukan batas usia remaja
**Kutipan sumber:** 108 72 109 72 11 110 74 111 74 12 113 75 114 75 ≥ 13 120 80 120 80 Sumber: Pedoman AAP tahun 2017 Batasan hipertensi pada neonatus dan bayi ( 0 -1 tahun ) masih tetap menggunakan kurva yang dibuat oleh The Second Task Force Report Blood Pressure karena banyak faktor yang memengaruhi tekanan darah pada neonatus sehingga sulit untuk menentukan batasan hipertensi secara pasti. Insert kurva
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 160 — supporting_investigation — PDF p.11
**Konsep:** Tabel skrining tekanan darah disederhanakan membutuhkan evaluasi jika melewati ambang
**Kutipan sumber:** - 11 - Tabel 2 Tabel Skrining Tekanan Darah yang Telah Disederhanakan Tekanan darah (mmHg) Usia Laki-laki Perempuan (Tahun) Sistole Diastole Sistole Diastole 1 98 52 98 54 2 100 55 101 58 3 101 58 102 60 4 102 60 103 62 5 103 63 104 64 6 105 66 105 67 7 106 68 106 68 8 107 69 107 69 9 107 70 108 71 10 108
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 161 — differential_diagnosis — PDF p.12
**Konsep:** Hipertensi primer lebih sering pada anak ≥6 tahun dengan obesitas atau riwayat keluarga
**Kutipan sumber:** kulit putih. Terdapat perubahan dalam prevalensi jenis hipertensi pada anak. Di Amerika Serikat, hipertensi primer lebih banyak pada anak-anak yang berusia 6 tahun ke atas, memiliki riwayat keluarga hipertensi dan berat badan lebih atau obesitas. Hasil penelitian berupa serial kasus secara retrospektif pada anak-anak dengan hipertensi sekunder menunjukkan bahwa penyakit parenkim ginjal
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 162 — differential_diagnosis — PDF p.12
**Konsep:** Hipertensi sekunder pada anak sering terkait penyakit parenkim ginjal dan renovaskular
**Kutipan sumber:** berupa serial kasus secara retrospektif pada anak-anak dengan hipertensi sekunder menunjukkan bahwa penyakit parenkim ginjal atau kelainan struktur ginjal didapatkan pada 34%–76% kasus, sedangkan penyakit renovaskular didapatkan pada 12%–13% kasus. Hipertensi sekunder tersebut lebih sering ditemukan pada anak-anak berusia di bawah 6 tahun. Terdapat kecenderungan bahwa penyakit dengan tekanan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 163 — physical_findings — PDF p.12
**Konsep:** Koarktasio aorta dapat menyebabkan tekanan lengan lebih tinggi dibanding kaki
**Kutipan sumber:** primer. Selain penyakit parenkim ginjal dan renovaskular, penyebab hipertensi sekunder lain adalah koarktasio aorta yang menunjukkan hipertensi dan tekanan darah lengan kanan lebih tinggi 20 mmHg atau lebih dibandingkan dengan ekstremitas bawah. Meskipun sudah dioperasi, koarktasio aorta dapat muncul kembali (re-koarktasio), sehingga pada pasien tersebut perlu dinilai dengan memeriksa tekanan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 164 — population_context — PDF p.13
**Konsep:** Riwayat berat badan lahir rendah, prematuritas dan hipertensi maternal relevan dalam anamnesis
**Kutipan sumber:** dan Keluarganya a) Riwayat Perinatal dan Keluarga Faktor perinatal berupa hipertensi pada ibu dan berat badan lahir rendah telah terbukti memengaruhi kejadian hipertensi pada anak di kemudian hari. Hubungan antara riwayat kelahiran prematur dan hipertensi juga telah dilaporkan. Riwayat hipertensi pada keluarga selain ibu juga perlu ditanyakan. b) Riwayat Asupan Makanan Asupan tinggi natrium
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 165 — population_context — PDF p.13
**Konsep:** Asupan natrium tinggi berkaitan dengan hipertensi anak
**Kutipan sumber:** dilaporkan. Riwayat hipertensi pada keluarga selain ibu juga perlu ditanyakan. b) Riwayat Asupan Makanan Asupan tinggi natrium dikaitkan dengan hipertensi pada anak dan peningkatan left ventricular mass index. Penelitian NHANES 2003-2008, menemukan pada anak-anak usia 8 hingga 18 tahun, asupan natrium yang lebih tinggi dikaitkan dengan peningkatan kejadian hipertensi, dan pengaruh ini lebih besar
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 166 — population_context — PDF p.14
**Konsep:** Kortikosteroid, dekongestan dan stimulan merupakan faktor obat yang dapat menaikkan tekanan darah
**Kutipan sumber:** Faktor Lingkungan Beberapa penggunaan obat-obatan yang dapat meningkatkan tekanan darah di antaranya kontrasepsi oral, stimulan sistem saraf pusat, kortikosteroid dan dekongestan (pseudoefedrin dan fenilpropanolamin). Riwayat penggunaan obat-obatan tersebut perlu ditanyakan dalam anamnesis untuk mencari kemungkinan etiologi hipertensi sekunder. Paparan terhadap timah, merkuri, ftalat maupun
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 167 — physical_findings — PDF p.14
**Konsep:** Perbedaan tekanan darah lengan/kaki serta pulsasi femoralis lemah menunjang koarktasio
**Kutipan sumber:** dibandingkan dengan lengan. Bila tekanan darah pada tungkai lebih rendah daripada lengan, atau bila pulsasi arteri femoralis lemah atau tidak ada, mungkin menunjukkan adanya koarktasio aorta. Pemeriksaan tekanan darah keempat anggota ekstremitas juga dianjurkan pada kecurigaan adanya penyakit pembuluh darah perifer, seperti penyakit Takayashu. Pemeriksaan fisik untuk mencari etiologi hipertensi
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 168 — differential_diagnosis — PDF p.15
**Konsep:** Temuan kulit akantosis nigrikans dapat mengarah pada diabetes tipe 2 sebagai komorbid
**Kutipan sumber:** café-au-lait tuberous sclerosis adenoma lupus sistemik sebaceum diabetes melitus tipe II bercak malar acanthosis nigricans Hematologi pucat, sickle cell penyakit ginjal anemia Toraks, jantung nyeri dada, penyakit jantung jdih.kemkes.go.id
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 169 — supporting_investigation — PDF p.16
**Konsep:** Pengukuran tekanan darah anak dianjurkan setelah istirahat 5 menit
**Kutipan sumber:** Darah Pasien harus tenang, tidak dalam keadaan cemas atau gelisah, maupun kesakitan. Dianjurkan istirahat 5 menit sebelum pemeriksaan. Pasien tidak melakukan aktivitas olah raga minimal 30 menit sebelum pemeriksaan. Pasien tidak menggunakan obat-obatan yang mengandung stimulan adrenergik, seperti fenilefrin atau pseudoefedrin (misalnya obat flu, obat tetes mata). Pasien tidak sedang dalam
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 170 — diagnostic_criteria — PDF p.17
**Konsep:** Tekanan darah anak >persentil 90 perlu dua pengukuran tambahan dan dirata-ratakan
**Kutipan sumber:** dikalibrasi atau dengan teknik auskultasi menggunakan sfigmomanomenter aneroid atau air raksa. Jika tekanan darah awal meningkat (> persentil ke-90), maka harus dilakukan 2 kali tambahan pemeriksaan pada kunjungan yang sama, lalu dirata- ratakan. Jika rata-rata tekanan darah dengan osilometrik menunjukkan > persentil 90, maka harus dilakukan 2 kali pemeriksaan menggunakan teknik auskultasi,
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 171 — physical_findings — PDF p.17
**Konsep:** Jika osilometrik tetap tinggi, verifikasi dengan dua pengukuran auskultasi
**Kutipan sumber:** pertama kali dapat dilakukan dengan menggunakan osilometrik yang telah dikalibrasi atau dengan teknik auskultasi menggunakan sfigmomanomenter aneroid atau air raksa. Jika tekanan darah awal meningkat (> persentil ke-90), maka harus dilakukan 2 kali tambahan pemeriksaan pada kunjungan yang sama, lalu dirata- ratakan. Jika rata-rata tekanan darah dengan osilometrik menunjukkan > persentil
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 180 — red_flags_severity — PDF p.34
**Konsep:** Hipertensi anak dengan retinopati, LVH atau proteinuria mengindikasikan kerusakan organ target
**Kutipan sumber:** - 34 - a. Hipertensi simtomatik. b. Kerusakan organ target, seperti retinopati, hipertrofi ventrikel kiri, dan proteinuria. c. Hipertensi sekunder. d. Diabetes melitus. e. Hipertensi tingkat 1 yang tidak menunjukkan respons dengan perubahan gaya hidup. f. Hipertensi tingkat 2. Pemilihan obat yang pertama kali diberikan sangat
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 181 — red_flags_severity — PDF p.40
**Konsep:** Hipertensi emergensi anak dapat disertai kejang, sakit kepala, gangguan penglihatan atau gagal jantung
**Kutipan sumber:** yang menunjukkan tekanan darah yang harus diturunkan dalam waktu satu jam, karena pada penderita didapatkan kejang, nyeri kepala, gangguan penglihatan, atau payah jantung. Pemberian nifedipin secara oral atau sublingual sangat membantu pada tahap awal pengobatan, sambil mencari cara agar obat suntikan dapat segera diberikan. Pengobatan secara intravena yang harus segera diberikan adalah
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 182 — differential_diagnosis — PDF p.41
**Konsep:** Hipertensi urgensi anak perlu dibedakan dari emergensi berdasarkan kerusakan organ
**Kutipan sumber:** dengan nifedipin. Meskipun demikian diperlukan obat-obat lain yang memilki masa kerja panjang. Hipertensi urgensi biasanya terjadi pada penderita glomerulonefritis akut, hipertensi akselerasi, dan setelah dilakukan transplantasi ginjal. Salah satu bentuk hipertensi emergensi adalah hipertensi krisis, yaitu tekanan darah meningkat dengan cepat hingga mencapai sistolik ≥ 180 mmHg atau
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

**Batas cakupan:** Diagnosis-oriented curation; terapi dan rujukan tidak dikurasi dalam checkpoint sumber. Tidak ada clinical approval independen.

