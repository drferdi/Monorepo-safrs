---
id: 329
title: "Trikiasis"
slug: "trikiasis"
icd_10: "H02.0"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Trikiasis

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Trikiasis adalah posisi bulu mata (silia) yang tumbuh melengkung ke arah dalam bola mata sehingga menggesek kornea dan konjungtiva bulbi, sering disebabkan oleh sikatriks tepi kelopak pasca-trakoma, blefaritis kronik, trauma, atau luka bakar.

## Gejala
- Mata terasa mengganjal dan perih terus-menerus
- Mata merah dan berair
- Fotofobia (silau)
- Sensasi benda asing setiap kali berkedip

## Diagnosis
Pemeriksaan senter/loupe: terlihat satu atau lebih helai bulu mata yang mengarah ke dalam dan menyentuh permukaan kornea atau konjungtiva bulbi. Tes fluoresin kornea sering memperlihatkan erosi kornea pungtata.

## Terapi
1. Epilasi mekanik: Mencabut bulu mata yang malposisi menggunakan pinset silia steril (solusi sementara, silia akan tumbuh kembali dalam 4-6 minggu).
2. Medikamentosa: Salep mata antibiotik (kloramfenikol 1%) dan air mata buatan untuk mencegah infeksi dan melumasi defek epitel kornea.

## Rujukan
Rujuk ke Spesialis Mata untuk terapi permanen elektrolisis, krioterapi, ablasi radiofrekuensi folikel silia, atau koreksi bedah kelopak mata bila disertai entropion sikatriks.

