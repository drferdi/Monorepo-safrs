---
id: 350
title: "Miliaria (Biang Keringat)"
slug: "miliaria-biang-keringat"
icd_10: "L74.3"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Miliaria (Biang Keringat)

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Miliaria (keringat buntet / biang keringat) adalah kelainan kulit yang timbul akibat retensi dan sumbatan saluran kelenjar keringat ekrin di lingkungan panas dan lembap. Tipe kristalina: sumbatan di stratum korneum; Tipe rubra: sumbatan di epidermis tengah dengan inflamasi.

## Gejala
- Miliaria kristalina: vesikel jernih kecil superfisial seperti tetesan embun tanpa eritema, tidak gatal, mudah pecah
- Miliaria rubra: papul dan vesikel merah kecil gatal menusuk dan pedih pada area tertutup pakaian/lipatan tubuh
- Banyak berkeringat
- Umum pada bayi, balita, atau orang yang tirah baring lama

## Diagnosis
Ditegakkan dari inspeksi klinis lesi papulovesikel mikro di area oklusi keringat (leher, dada, punggung, lipatan ketiak/paha) pada cuaca panas lembap.

## Terapi
1. Modifikasi Lingkungan (Pilar Utama Penanganan):
   - Menjaga sirkulasi udara sejuk dan ventilasi baik (gunakan AC/kipas angin).
   - Memakai pakaian tipis, longgar, menyerap keringat berbahan katun.
   - Mandi air dingin dan segera keringkan tubuh.
2. Farmakologis Topikal:
   - Bedak kocok kalamin (Caladine) atau bedak salisil 1-2% dioleskan pada area lesi.
   - Krim Hidrokortison 1% tipis jangka pendek (2-3 hari) bila miliaria rubra sangat meradang dan gatal.
   - Antihistamin oral bila gatal mengganggu tidur bayi/anak.

## Rujukan
Rujuk ke Spesialis Kulit bila timbul komplikasi infeksi bakteri sekunder luas (miliaria pustulosa / impetiginisasi) yang membutuhkan antibiotik sistemik atau tidak membaik dengan tata laksana primer.

