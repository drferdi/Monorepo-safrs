---
id: 301
title: "Oksiuriasis (Enterobiasis / Cacing Kremi)"
slug: "oksiuriasis-enterobiasis-cacing-kremi"
icd_10: "B80"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Oksiuriasis (Enterobiasis / Cacing Kremi)

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Oksiuriasis adalah infeksi usus yang disebabkan oleh cacing kremi Enterobius vermicularis, sangat menular antaranggota keluarga melalui autoinfeksi dan kontak feses-oral.

## Gejala
- Pruritus ani nokturnal (gatal hebat di area perianal terutama malam hari)
- Tidur gelisah dan rewel pada anak
- Ekskoriasi lecet kulit perianal akibat garukan
- Kadang terlihat cacing kecil putih seperti benang bergerak di perianal/tinja

## Diagnosis
Diagnosis ditegakkan dari keluhan gatal perianal malam hari. Penegakan pasti menggunakan metode Graham tape test (scotch adhesive tape swab pada kulit perianal pagi hari sebelum mandi): pemeriksaan mikroskopis menunjukkan telur cacing asimetris lonjong pipih di satu sisi.

## Terapi
1. Farmakologis (Wajib diulang 2 minggu kemudian untuk memutus siklus cacing matang baru):
   - Pirantel Pamoat: 10-11 mg/kgBB oral dosis tunggal (maksimum 1 gram), diulang setelah 2 minggu.
   - Albendazol: 400 mg oral dosis tunggal, diulang setelah 2 minggu.
   - Mebendazol: 100-500 mg oral dosis tunggal, diulang setelah 2 minggu.
2. Pengobatan serentak seluruh anggota keluarga yang tinggal serumah.
3. Edukasi kebersihan: mencuci seprai pakaian dengan air panas, memotong kuku pendek, mencuci tangan.

## Rujukan
Rujuk ke FKRTL bila terjadi komplikasi salpingitis/vulvovaginitis cacing kremi ektopik pada anak perempuan atau infeksi sekunder selulitis perianal refrakter.

