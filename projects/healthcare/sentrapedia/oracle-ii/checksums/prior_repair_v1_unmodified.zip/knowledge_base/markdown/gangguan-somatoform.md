---
id: 339
title: "Gangguan Somatoform"
slug: "gangguan-somatoform"
icd_10: "F45.9"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Gangguan Somatoform

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Gangguan somatoform adalah kelompok gangguan psikiatrik di mana pasien mengeluhkan keluhan fisik somatik berulang (seperti nyeri dada, sesak, kembung, kesemutan) yang menimbulkan distres berat, namun tidak ditemukan kelainan organik atau patologi medis yang mendasari setelah investigasi menyeluruh.

## Gejala
- Keluhan fisik multipel yang berpindah-pindah (nyeri kepala, dada, perut, persendian)
- Pencarian konfirmasi medis berulang ke berbagai dokter (doctor shopping)
- Kekhawatiran persisten bahwa dirinya menderita penyakit fisik berbahaya
- Penolakan terhadap penjelasan dokter bahwa hasil pemeriksaan penunjang normal

## Diagnosis
Ditegakkan berdasarkan kriteria PPDGJ-III: adanya keluhan fisik multipel minimal 2 tahun yang tidak dapat dijelaskan secara medis, penolakan persisten terhadap bukti medis negatif, dan hendaya fungsi psikososial.

## Terapi
1. Pendekatan Dokter-Pasien (Kunci Keberhasilan):
   - Validasi penderitaan pasien (jangan mengatakan 'ini hanya ada di pikiran Anda').
   - Jadwalkan kunjungan kontrol teratur dengan satu dokter tetap di FKTP (menghindari doctor shopping).
   - Alihkan fokus dari keluhan fisik ke stresor emosional psikososial.
2. Psikoterapi: CBT dan teknik relaksasi.
3. Farmakologis: SSRI dosis rendah (Sertralin 25-50 mg/hari oral) bila disertai gejala kecemasan atau depresi penyerta. Hindari analgesik narkotik atau polifarmasi somatik.

## Rujukan
Rujuk ke Spesialis Kedokteran Jiwa (Sp.KJ) bila kecemasan hipokondriakal sangat parah tidak terkendali, distres fungsi berat, atau timbul depresi berat sekunder dengan ide bunuh diri.

