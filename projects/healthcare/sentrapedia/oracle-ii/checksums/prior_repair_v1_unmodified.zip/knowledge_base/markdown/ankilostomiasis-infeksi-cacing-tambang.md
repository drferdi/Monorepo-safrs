---
id: 300
title: "Ankilostomiasis (Infeksi Cacing Tambang)"
slug: "ankilostomiasis-infeksi-cacing-tambang"
icd_10: "B76.0"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Ankilostomiasis (Infeksi Cacing Tambang)

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Ankilostomiasis adalah infeksi parasit cacing tambang (Necator americanus atau Ancylostoma duodenale) di usus halus manusia yang menempel pada mukosa dan mengisap darah pejamu, memicu anemia defisiensi besi berat.

## Gejala
- Ground itch (ruam papulovesikel gatal di tempat penetrasi kulit kaki)
- Gejala saluran cerna: nyeri ulu hati, mual, diare intermiten
- Gejala anemia defisiensi besi berat: pucat, lemas, mudah lelah, palpitasi, pusing, pica
- Koilonikia (spoon nails) pada anemia kronik

## Diagnosis
Penegakan diagnosis berdasarkan anamnesis kontak tanah tanpa alas kaki dan pucat kronis. Pemeriksaan tinja mikroskopis: ditemukan telur cacing tambang bersegmen dengan dinding bening transparan oval. Pemeriksaan darah: anemia hipokromik mikrositik dan eosinofilia.

## Terapi
1. Antelmintik:
   - Albendazol: 400 mg oral dosis tunggal selama 3 hari berturut-turut pada infeksi berat.
   - Mebendazol: 500 mg dosis tunggal atau 2 x 100 mg/hari selama 3 hari.
   - Pirantel Pamoat: 10-11 mg/kgBB oral harian selama 3 hari berturut-turut.
2. Terapi Anemia Defisiensi Besi:
   - Sulfas Ferosus 3 x 200 mg/hari oral (atau preparat besi elemental 100-200 mg/hari) selama minimal 2-3 bulan sampai cadangan besi (feritin) pulih.

## Rujukan
Rujuk ke FKRTL bila anemia berat simptomatik (Hb < 7 g/dL) yang membutuhkan transfusi Packed Red Cells (PRC) atau jika disertai gagal jantung anemik.

