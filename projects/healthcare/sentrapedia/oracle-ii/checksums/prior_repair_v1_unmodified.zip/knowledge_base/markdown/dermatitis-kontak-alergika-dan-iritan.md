---
id: 341
title: "Dermatitis Kontak Alergika dan Iritan"
slug: "dermatitis-kontak-alergika-dan-iritan"
icd_10: "L23.9"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Dermatitis Kontak Alergika dan Iritan

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Dermatitis kontak adalah reaksi inflamasi kulit yang timbul akibat kontak dengan substansi eksternal. Dermatitis Kontak Iritan (DKI, 80%) diakibatkan oleh kerusakan fisik/kimiawi sawar kulit tanpa sensitisasi imunologis; Dermatitis Kontak Alergika (DKA) merupakan reaksi hipersensitivitas tipe IV (cell-mediated) terhadap alergen spesifik (nikel, lateks, pewarna rambut).

## Gejala
- DKI: rasa pedih, terbakar, eritema, fisura, kulit kering bersisik setelah kontak dengan deterjen/zat kimia
- DKA: gatal hebat yang dominan, eritema berbatas tegas sesuai bentuk kontak, vesikel, bula, eksudasi
- Lokasi predileksi: tangan, pergelangan tangan (jam tangan), daun telinga (anting imitasi), dahi/leher

## Diagnosis
Penegakan diagnosis klinis dari anamnesis riwayat pekerjaan, hobi, dan kontak zat kimia/logam. Pemeriksaan fisik: morfologi lesi sesuai bentuk benda kontak. Konfirmasi DKA: uji tempel (patch test) setelah fase akut sembuh.

## Terapi
1. Identifikasi dan penghentian kontak total dengan substansi pemicu (penggunaan sarung tangan pelindung).
2. Terapi Topikal:
   - Kompres terbuka larutan NaCl 0.9% pada lesi basah/eksudatif selama 15 menit 3 kali sehari.
   - Kortikosteroid Topikal: Betametason dipropionat 0.05% atau Mometason furoat 0.1% krim dioleskan 1-2 kali sehari selama 1-2 minggu pada lesi kering/papular.
   - Emolien pelembap untuk memulihkan barier kulit.
3. Antihistamin oral bila gatal mengganggu tidur.

## Rujukan
Rujuk ke Spesialis Kulit dan Kelamin (Sp.DV) bila lesi luas melibatkan > 20% luas permukaan tubuh, terjadi eritroderma, atau memerlukan patch test untuk identifikasi alergen profesional/industri.

