---
id: 296
title: "Disentri Amoeba (Amoebiasis)"
slug: "disentri-amoeba-amoebiasis"
icd_10: "A06.0"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Disentri Amoeba (Amoebiasis)

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Disentri amuba adalah infeksi usus besar yang disebabkan oleh protozoa parasit Entamoeba histolytica, yang menginvasi mukosa dinding kolon membentuk ulkus khas berbentuk botol (flask-shaped ulcer).

## Gejala
- Diare lendir darah berbau busuk khas
- Tenesmus ringan hingga sedang
- Nyeri perut bawah / kram abdomen
- BAB berulang dengan volume tinja sedikit-sedikit
- Demam ringan (subfebris)

## Diagnosis
Penegakan diagnosis melalui pemeriksaan mikroskopis tinja segar: ditemukan kista berinti 4 atau trofozoit motil Entamoeba histolytica yang memfagositosis sel darah merah (eritrofagositosit).

## Terapi
1. Rehidrasi adekuat.
2. Farmakologis Amebisid Jaringan:
   - Metronidazol: Dewasa 3 x 750 mg oral per hari selama 7-10 hari; Anak 35-50 mg/kgBB/hari dibagi 3 dosis selama 7-10 hari.
   - Alternatif: Tinidazol 1 x 2 gram oral per hari selama 3 hari.
3. Edukasi sanitasi air bersih, kebersihan mencuci tangan dengan sabun, dan memasak makanan hingga matang.

## Rujukan
Rujuk ke FKRTL bila dicurigai komplikasi ekstraintestinal seperti abses hati amuba (nyeri perut kuadran kanan atas, hepatomegali nyeri, demam septik), perforasi usus, atau peritonitis amuba.

