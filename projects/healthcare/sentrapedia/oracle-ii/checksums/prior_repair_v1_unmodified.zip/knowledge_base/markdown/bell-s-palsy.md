---
id: 335
title: "Bell's Palsy"
slug: "bell-s-palsy"
icd_10: "G51.0"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Bell's Palsy

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Bell's palsy adalah paresis atau paralisis akut nervus fasialis (nervus kranialis VII) perifer ipsilateral tanpa penyebab yang jelas (idiopatik), diduga akibat reaktivasi virus herpes simpleks yang memicu inflamasi dan edema saraf dalam foramen stilomastoideus.

## Gejala
- Kelemahan otot wajah sesisi mendadak (< 72 jam)
- Mulut mencong ke sisi yang sehat (asimetri sudut bibir)
- Tidak dapat menutup mata pada sisi yang sakit (lagophthalmos)
- Dahi pada sisi sakit tidak dapat berkerut (membedakan dari stroke sentral)
- Bell's phenomenon positif (bola mata berputar ke atas saat berusaha menutup kelopak mata)
- Nyeri di belakang telinga (nyeri mastoid)
- Hiperakusis (sensitif suara keras di satu telinga) atau penurunan pengecapan 2/3 anterior lidah

## Diagnosis
Penegakan diagnosis klinis paresis nervus VII tipe LMN (lower motor neuron: dahi tidak berkerut + lagofthalmos + plika nasolabialis datar + sudut mulut jatuh). Menyingkirkan stroke sentral (pada stroke hemisfer, otot dahi masih bisa berkerut bilateral). Menyingkirkan Ramsay Hunt syndrome (tidak ada vesikel herpetik di meatus akustikus).

## Terapi
1. Kortikosteroid Oral (Pilar Terapi Utama, dimulai < 72 jam sejak onset):
   - Prednison: 60 mg/hari oral (1 mg/kgBB/hari) selama 5 hari, dilanjutkan tapering off 10 mg per hari selama 5 hari berikutnya (total durasi 10 hari).
2. Antiviral (kombinasi pada paresis berat):
   - Asiklovir 5 x 400 mg oral atau Valasiklovir 3 x 1000 mg oral selama 7 hari.
3. Proteksi Mata Lagofthalmos (Mencegah keratitis eksposur):
   - Air mata buatan (artificial tears) tetes mata di siang hari setiap 2-3 jam.
   - Salep mata pelumas dan plester penutup mata (eye patch) saat tidur malam.
4. Fisioterapi wajah setelah fase inflamasi akut mereda.

## Rujukan
Rujuk ke Spesialis Saraf bila tidak ada tanda perbaikan fungsi saraf setelah 3-4 minggu, timbul defisit neurologis kranial lain, kecurigaan sindrom Guillain-Barre, atau paresis bilateral.

