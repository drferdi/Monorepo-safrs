---
id: 320
title: "Konjungtivitis Bakteri dan Viral"
slug: "konjungtivitis-bakteri-dan-viral"
icd_10: "H10.9"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Konjungtivitis Bakteri dan Viral

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Konjungtivitis adalah peradangan selaput lendir konjungtiva bulbi dan palpebra yang disebabkan oleh infeksi bakteri (Staphylococcus, Streptococcus) atau virus (Adenovirus), ditandai dengan hiperemia konjungtiva dan sekret mata.

## Gejala
- Mata merah (injeksi konjungtiva)
- Rasa mengganjal seperti berpasir
- Sekret mukopurulen/purulen lengket kelopak mata menempel saat bangun tidur (khas bakteri)
- Sekret serosa/berair dengan pembengkakan kelenjar getah bening preaurikular (khas virus)
- Tidak ada penurunan tajam penglihatan (visus normal)

## Diagnosis
Ditegakkan dari pemeriksaan mata luar: visus normal, injeksi konjungtival (pembuluh darah perifer konjungtiva melebar berkelok dan memucat ke arah limbus), sekret purulen atau serosa, kornea jernih, pupil reaktif.

## Terapi
1. Konjungtivitis Bakteri:
   - Kloramfenikol tetes mata 0.5-1% 1 tetes setiap 2-4 jam atau salep mata kloramfenikol 1% sebelum tidur selama 5-7 hari.
   - Alternatif: Tobramisin 0.3% atau Asam Fusidat tetes mata.
2. Konjungtivitis Viral:
   - Terapi suportif (swasirna dalam 7-14 hari): kompres dingin, air mata buatan (artificial tears) tetes mata 4-6 kali sehari.
3. Menjaga higienitas: tidak menyentuh/mengucek mata, cuci tangan, menggunakan handuk terpisah.

## Rujukan
Rujuk ke Spesialis Mata (Sp.M) bila visus menurun, ada fotofobia berat, kecurigaan ulkus kornea, sekret purulen hiperakut masif (curiga konjungtivitis gonore neonatal/dewasa yang membutuhkan terapi seftriakson sistemik), atau tidak membaik dalam 1 minggu.

