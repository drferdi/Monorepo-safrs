---
id: 304
title: "Ulkus Mulut (Stomatitis Aftosa Rekuren)"
slug: "ulkus-mulut-stomatitis-aftosa-rekuren"
icd_10: "K12.0"
clinical_qa_status: "UNVERIFIED_NON_PNPK_CANDIDATE"
is_complete: false
verified_clinical_kb: false
---

# Ulkus Mulut (Stomatitis Aftosa Rekuren)

> **Clinical QA: UNVERIFIED_NON_PNPK_CANDIDATE.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

## Status parsing
Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.

**Referensi sumber:** Permenkes No. 5 Tahun 2014, KMK No. HK.01.07/MENKES/1186/2022

## Definisi
Stomatitis Aftosa Rekuren (SAR / sariawan) adalah lesi ulseratif mukosa rongga mulut yang berulang, nyeri, berbatas tegas dengan dasar nekrotik putih-kekuningan dan halo eritematosa, sering dipicu trauma lokal, stres, defisiensi nutrisi, atau faktor genetik.

## Gejala
- Nyeri pada mukosa mulut (bibir dalam, pipi dalam, lidah)
- Nyeri saat makan, minum, atau berbicara
- Ulkus bulat dangkal berbatas merah dengan membran sentral putih-abu-abu

## Diagnosis
Ditegakkan secara klinis dari riwayat rekurensi ulkus dan morfologi khas tipe minor (< 10 mm, sembuh 7-14 hari tanpa jaringan parut) atau tipe mayor (> 10 mm).

## Terapi
1. Non-farmakologis: Menjaga higienitas mulut, hindari makanan pedas, asam, asin, dan bergerigi tajam.
2. Farmakologis Topikal:
   - Antiseptik kumur: Klorheksidin glukonat 0.1-0.2% kumur 2-3 kali sehari.
   - Anestesi topikal: Gel lidokain 2% dioleskan pada lesi sebelum makan untuk mengurangi rasa nyeri.
   - Kortikosteroid topikal: Triamsinolon asetonid pasta oral 0.1% dioleskan tipis pada lesi 2-3 kali sehari pasca makan.
3. Suplementasi vitamin B kompleks, vitamin C, asam folat, dan zat besi bila dicurigai defisiensi.

## Rujukan
Rujuk ke Spesialis Penyakit Mulut / Bedah Mulut bila ulkus tidak sembuh setelah > 3 minggu (waspada karsinoma sel skuamosa rongga mulut), ulkus sangat besar multipel, atau dicurigai manifestasi penyakit sistemik (Behcet disease, Crohn disease).

