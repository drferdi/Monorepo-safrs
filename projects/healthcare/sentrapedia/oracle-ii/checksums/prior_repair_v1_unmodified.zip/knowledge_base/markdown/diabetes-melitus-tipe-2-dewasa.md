---
id: 166
title: "Diabetes Melitus Tipe 2 Dewasa"
slug: "diabetes-melitus-tipe-2-dewasa"
icd_10: "E11"
clinical_qa_status: "SOURCE_GROUNDED_DIAGNOSTIC_SUBSET"
is_complete: false
verified_clinical_kb: false
---

# Diabetes Melitus Tipe 2 Dewasa

> **Clinical QA: SOURCE_GROUNDED_DIAGNOSTIC_SUBSET.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.

**Sumber:** 045_PNPK_2020_Tata_Laksana_Diabetes_Melitus_Tipe_2_Dewasa.pdf (HK.01.07/MENKES/603/2020)
**Regulasi:** SUPERSEDED
**Populasi:** dewasa

> **Historical only:** PNPK ini telah digantikan. Jangan digunakan sebagai pedoman klinis aktif.

## Definisi
DM merupakan suatu kelompok penyakit metabolik dengan karakteristik hiperglikemia yang terjadi karena kelainan sekresi insulin, kerja insulin atau kedua-duanya. (PDF p.11)

## Gejala
- Gejala klasik DM dewasa berupa poliuria, polidipsia, polifagia, dan penurunan berat badan
- Keluhan DM dewasa lain dapat berupa kesemutan, mata kabur, gatal dan disfungsi ereksi

## Diagnosis (ringkasan berbasis fakta terkurasi)
- [PDF p.11; fact #98] DM meliputi tipe 1, tipe 2, tipe lain dan diabetes gestasional
- [PDF p.11; fact #99] DM tipe 2 terkait resistensi insulin; gangguan sekresi insulin dapat berkembang
- [PDF p.12; fact #100] Diagnosis DM menggunakan glukosa plasma vena; glukosuria saja tidak menegakkan diagnosis
- [PDF p.12; fact #103] PNPK historis DM2 dewasa: glukosa plasma puasa ≥126 mg/dL; puasa ≥8 jam
- [PDF p.12; fact #104] PNPK historis DM2 dewasa: glukosa plasma 2 jam TTGO 75 gram ≥200 mg/dL
- [PDF p.12; fact #105] PNPK historis DM2 dewasa: glukosa plasma sewaktu ≥200 mg/dL dengan keluhan klasik
- [PDF p.12; fact #106] PNPK historis DM2 dewasa: HbA1c ≥6,5% menggunakan metode terstandarisasi NGSP
- [PDF p.13; fact #107] Prediabetes mencakup glukosa puasa 100–125 mg/dL dan HbA1c 5,7–6,4%
- [PDF p.13; fact #108] Toleransi glukosa terganggu: TTGO 2 jam 140–199 mg/dL
- [PDF p.13; fact #109] TTGO dewasa menggunakan beban glukosa 75 gram
- [PDF p.142; fact #115] HbA1c dapat tidak sesuai glukosa plasma pada hemoglobinopati

## Terapi
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Rujukan
Belum tersedia — lengkapi dan verifikasi oleh klinisi

## Fakta dan Sitasi PDF

### 98 — diagnostic_criteria — PDF p.11
**Konsep:** DM meliputi tipe 1, tipe 2, tipe lain dan diabetes gestasional
**Kutipan sumber:** kerja insulin atau kedua-duanya. 2. Klasifikasi Klasifikasi DM dapat dilihat pada Tabel 3. Tabel 3. Klasifikasi etiologi diabetes melitus Klasifikasi Keterangan Diabetes a. Destruksi sel beta, umumnya menjurus ke melitus tipe 1 defisiensi insulin absolut (DM tipe 1) b. Autoimun c. Idiopatik Diabetes Disebabkan oleh resistensi insulin, namun dlam melitus tipe 2 perjalanan penyakit dapat terjadi
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 99 — differential_diagnosis — PDF p.11
**Konsep:** DM tipe 2 terkait resistensi insulin; gangguan sekresi insulin dapat berkembang
**Kutipan sumber:** menjurus ke melitus tipe 1 defisiensi insulin absolut (DM tipe 1) b. Autoimun c. Idiopatik Diabetes Disebabkan oleh resistensi insulin, namun dlam melitus tipe 2 perjalanan penyakit dapat terjadi gangguan sekresi (DM tipe 2) insulin yang progresif. Diabetes a. Sindroma Diabetes Monogenik, seperti maturity- melitus tipe onset diabetes of the young (MODY) lain b. Gangguan pada kelenjar eksokrin
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 100 — diagnostic_criteria — PDF p.12
**Konsep:** Diagnosis DM menggunakan glukosa plasma vena; glukosuria saja tidak menegakkan diagnosis
**Kutipan sumber:** pengobatan dapat dilakukan dengan menggunakan pemeriksaan glukosa darah kapiler dengan glukometer. Diagnosis tidak dapat ditegakkan atas dasar adanya glukosuria. Berbagai keluhan dapat ditemukan pada pasien DM. Kecurigaan adanya DM perlu dipikirkan apabila terdapat keluhan klasik, seperti poliuria, polidipsia, polifagia dan penurunan berat badan yang tidak dapat dijelaskan sebabnya. Keluhan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 101 — signs_symptoms — PDF p.12
**Konsep:** Gejala klasik DM dewasa berupa poliuria, polidipsia, polifagia, dan penurunan berat badan
**Kutipan sumber:** pada pasien DM. Kecurigaan adanya DM perlu dipikirkan apabila terdapat keluhan klasik, seperti poliuria, polidipsia, polifagia dan penurunan berat badan yang tidak dapat dijelaskan sebabnya. Keluhan lain yang menyertai adalah badan lemah, kesemutan, gatal, mata kabur, dan disfungsi ereksi pada pria, serta pruritus vulva pada wanita. Tabel 4. Kriteria diagnosis DM Pemeriksaan glukosa
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 102 — signs_symptoms — PDF p.12
**Konsep:** Keluhan DM dewasa lain dapat berupa kesemutan, mata kabur, gatal dan disfungsi ereksi
**Kutipan sumber:** tidak dapat dijelaskan sebabnya. Keluhan lain yang menyertai adalah badan lemah, kesemutan, gatal, mata kabur, dan disfungsi ereksi pada pria, serta pruritus vulva pada wanita. Tabel 4. Kriteria diagnosis DM Pemeriksaan glukosa plasma puasa ≥ 126 mg/dl. (derajat rekomendasi B) Puasa adalah kondisi tidak ada asupan kalori minimal 8 jam Atau Pemeriksaan glukosa plasma ≥ 200 mg/dl 2 jam setelah
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 103 — diagnostic_criteria — PDF p.12
**Konsep:** PNPK historis DM2 dewasa: glukosa plasma puasa ≥126 mg/dL; puasa ≥8 jam
**Kutipan sumber:** ereksi pada pria, serta pruritus vulva pada wanita. Tabel 4. Kriteria diagnosis DM Pemeriksaan glukosa plasma puasa ≥ 126 mg/dl. (derajat rekomendasi B) Puasa adalah kondisi tidak ada asupan kalori minimal 8 jam Atau Pemeriksaan glukosa plasma ≥ 200 mg/dl 2 jam setelah tes toleransi glukosa oral (TTGO) dengan beban 75 gram. (derajat rekomendasi B) Atau Pemeriksaan glukosa plasma sewaktu
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 104 — diagnostic_criteria — PDF p.12
**Konsep:** PNPK historis DM2 dewasa: glukosa plasma 2 jam TTGO 75 gram ≥200 mg/dL
**Kutipan sumber:** kondisi tidak ada asupan kalori minimal 8 jam Atau Pemeriksaan glukosa plasma ≥ 200 mg/dl 2 jam setelah tes toleransi glukosa oral (TTGO) dengan beban 75 gram. (derajat rekomendasi B) Atau Pemeriksaan glukosa plasma sewaktu ≥ 200 mg/dL dengan keluhan klasik Atau Pemeriksaan HbA1C ≥ 6,5% dengan menggunakan metode high- performance liquid chromatography (HPLC) yang terstandarisasi oleh
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 105 — diagnostic_criteria — PDF p.12
**Konsep:** PNPK historis DM2 dewasa: glukosa plasma sewaktu ≥200 mg/dL dengan keluhan klasik
**Kutipan sumber:** tes toleransi glukosa oral (TTGO) dengan beban 75 gram. (derajat rekomendasi B) Atau Pemeriksaan glukosa plasma sewaktu ≥ 200 mg/dL dengan keluhan klasik Atau Pemeriksaan HbA1C ≥ 6,5% dengan menggunakan metode high- performance liquid chromatography (HPLC) yang terstandarisasi oleh National Glycohaemoglobin Standarization Program (NGSP). (derajat rekomendasi B) Hasil pemeriksaan yang tidak
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 106 — diagnostic_criteria — PDF p.12
**Konsep:** PNPK historis DM2 dewasa: HbA1c ≥6,5% menggunakan metode terstandarisasi NGSP
**Kutipan sumber:** (derajat rekomendasi B) Atau Pemeriksaan glukosa plasma sewaktu ≥ 200 mg/dL dengan keluhan klasik Atau Pemeriksaan HbA1C ≥ 6,5% dengan menggunakan metode high- performance liquid chromatography (HPLC) yang terstandarisasi oleh National Glycohaemoglobin Standarization Program (NGSP). (derajat rekomendasi B) Hasil pemeriksaan yang tidak memenuhi kriteria normal atau DM dapat digolongkan ke dalam
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 107 — diagnostic_criteria — PDF p.13
**Konsep:** Prediabetes mencakup glukosa puasa 100–125 mg/dL dan HbA1c 5,7–6,4%
**Kutipan sumber:** darah puasa dan glukosa darah 2 jam setelah TTGO. Kriteria untuk diagnosis prediabetes adalah bila glukosa darah puasa 100-125 mg/dL, atau glukosa darah 2 jam setelah TTGO 140-200 mg/dL, atau HbA1c 5,7-6,4%. Prediabetes dapat dibedakan menjadi glukosa puasa terganggu (GPT), toleransi glukosa terganggu (TGT) dan campuran keduanya. Glukosa puasa terganggu (GPT) bila hasil pemeriksaan glukosa
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 108 — diagnostic_criteria — PDF p.13
**Konsep:** Toleransi glukosa terganggu: TTGO 2 jam 140–199 mg/dL
**Kutipan sumber:** 140 mg/dL. Toleransi glukosa terganggu (TGT) bila hasil pemeriksaan glukosa 2 jam setelah TTGO antara 140-199 mg/dL. Tabel 5. Cara pelaksanaan TTGO Tiga hari sebelum pemeriksaan, pasien tetap makan (dengan karbohidrat yang cukup) dan melakukan kegiatan fisis seperti 1 kebiasaan sehari-hari Berpuasa paling sedikit 8 jam (mulai malam hari) sebelum 2 pemeriksaan, minum air putih tanpa gula
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 109 — supporting_investigation — PDF p.13
**Konsep:** TTGO dewasa menggunakan beban glukosa 75 gram
**Kutipan sumber:** minum air putih tanpa gula tetap diperbolehkan Dilakukan pemeriksaan kadar glukosa darah puasa 3 Diberikan glukosa 75 gram (orang dewasa), atau 1,75 gram/kgBB (anak-anak), dilarutkan dalam air 250 mL dan 4 diminum dalam waktu 5 menit Berpuasa kembali sampai pengambilan sampel darah untuk 5 pemeriksaan 2 jam setelah minum larutan glukosa selesai Dilakukan pemeriksaan kadar glukosa darah
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 110 — population_context — PDF p.13
**Konsep:** Skrining DM2 pada individu risiko tinggi tanpa gejala meliputi IMT ≥23 kg/m² bersama faktor risiko
**Kutipan sumber:** tidak menunjukkan gejala klasik DM yaitu: a. Kelompok dengan berat badan lebih (indeks massa tubuh (IMT) ≥ 23 kg/m2) yang disertai dengan satu atau lebih faktor risiko sebagai berikut: 1) First-degree relative DM (terdapat faktor keturunan DM
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 111 — population_context — PDF p.14
**Konsep:** Faktor risiko skrining DM2: riwayat keluarga, hipertensi, dislipidemia, PCOS dan akantosis nigrikans
**Kutipan sumber:** yang kurang 8) Kondisi klinis yang berkaitan dengan resistensi insulin, misalnya obesitas berat, acanthosis nigricans b. Pasien prediabetes (HbA1c ≥ 5,7%, GDPT, TGT) harus dilakukan pemeriksaan setiap tahun c. Wanita yang memiliki riwayat melahirkan bayi dengan BB > 4 kg atau mempunyai riwayat diabetes melitus gestasional (DMG), harus dilakukan pemeriksaan setiap 3 tahun selama hidupnya
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 112 — population_context — PDF p.14
**Konsep:** Skrining DM2 juga dipertimbangkan untuk semua orang di atas 45 tahun
**Kutipan sumber:** (DMG), harus dilakukan pemeriksaan setiap 3 tahun selama hidupnya d. Untuk semua orang berusia di atas 45 tahun, tanpa faktor risiko e. Apabila hasil pemeriksaan normal, pemeriksaan harus diulang sekurang-kurangnya setiap 3 tahun namun dapat dilakukan lebih sering tergantung dari hasil pemeriksaan awal dan status risiko B. Penatalaksanaan diabetes melitus Tujuan penatalaksanaan secara
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 113 — red_flags_severity — PDF p.15
**Konsep:** Komplikasi akut yang perlu digali pada evaluasi DM meliputi ketoasidosis, hiperosmolar dan hipoglikemia
**Kutipan sumber:** termasuk obat yang digunakan, perencanaan makan dan program latihan fisis 6) Riwayat komplikasi akut (ketoasidosis diabetik, hiperosmolar hiperglikemia, hipoglikemia) 7) Riwayat infeksi sebelumnya, terutama infeksi pada kulit, gigi, saluran pernapasan, dan saluran kemih 8) Gejala dan riwayat pengobatan komplikasi kronik pada ginjal, mata, jantung dan pembuluh darah, kaki, saluran pencernaan,
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 114 — physical_findings — PDF p.15
**Konsep:** Evaluasi awal DM2 meliputi faktor risiko kardiovaskular, ginjal, mata, jantung dan kaki
**Kutipan sumber:** infeksi pada kulit, gigi, saluran pernapasan, dan saluran kemih 8) Gejala dan riwayat pengobatan komplikasi kronik pada ginjal, mata, jantung dan pembuluh darah, kaki, saluran pencernaan, dan lain-lain 9) Pengobatan lain yang mungkin berpengaruh terhadap glukosa darah 10) Faktor risiko: merokok, hipertensi, riwayat penyakit jantung koroner, obesitas, dan riwayat penyakit keluarga (termasuk
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 115 — laboratory — PDF p.142
**Konsep:** HbA1c dapat tidak sesuai glukosa plasma pada hemoglobinopati
**Kutipan sumber:** pemeriksaan HbA1c dengan glukosa plasma, maka dapat disebabkan oleh faktor hemoglobin, misalnya hemoglobinopati. B 3. Pada beberapa keadaan yang mengakibatkan perubahan antara nilai HbA1c dengan kadar glukosa, maka hanya kriteria glukosa darah plasma yang digunakan untuk mendiagnosis diabetes, seperti penyakit anemia sel sabit, kehamilan trimester kedua dan ketiga, pasca persalinan, defisiensi
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 116 — population_context — PDF p.142
**Konsep:** Pada trimester kedua atau ketiga kehamilan dan kondisi hematologis tertentu digunakan kriteria glukosa plasma
**Kutipan sumber:** glukosa darah plasma yang digunakan untuk mendiagnosis diabetes, seperti penyakit anemia sel sabit, kehamilan trimester kedua dan ketiga, pasca persalinan, defisiensi enzim glukosa-6-fosfat dehydrogenase, penyakit HIV, pasien hemodialisis, mengalami perdarahan akut, pasca transfusi darah atau mendapat terapi erittopoetin. B 4. Pemeriksaan penyaring untuk menegakkan diagnosis DM tipe 2 dan
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

### 117 — population_context — PDF p.143
**Konsep:** Prediabetes memerlukan pemeriksaan ulang setiap tahun menurut dokumen 2020
**Kutipan sumber:** atas 45 tahun, tanpa faktor risiko 5. Pasien prediabetes (HbA1c ≥5,7%, GDPT, TGT) harus dilakukan pemeriksaan setiap tahun. B 6. Apabila hasil pemeriksaan normal, pemeriksaan harus diulang sekurang-kurangnya setiap 3 tahun namun dapat dilakukan lebih sering tergantung dari hasil pemeriksaan awal dan status risiko. B 7. Diagnosis prediabetes dan DM tipe 2 dapat menggunakan pemeriksaan glukosa
**Metode verifikasi:** PDF_TEXT_EXACT_MATCH

**Batas cakupan:** Diagnosis-oriented curation; terapi dan rujukan tidak dikurasi dalam checkpoint sumber. Tidak ada clinical approval independen.

