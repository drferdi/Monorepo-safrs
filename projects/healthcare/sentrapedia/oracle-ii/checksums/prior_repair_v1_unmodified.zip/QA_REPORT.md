# SENTRA — Knowledge Base Parsing Repair QA Report

**Overall result: PARTIAL SOURCE REPAIR COMPLETE / CLINICAL RELEASE BLOCKED**

## Deterministic counts

| Audit dimension | Verified result |
| --- | ---: |
| Input disease JSON records preserved by id/slug | 144/144 |
| Matching Markdown and catalog regenerated | 144/144 |
| Source-grounded PNPK diagnostic subsets rebuilt | 8/80 PNPK |
| PDF-cited diagnostic evidence facts preserved | 182 |
| Direct text matches against stored PDF pages | 168 |
| Previous visual review log anchors (not text-exact) | 14 |
| PDF source originals with matching SHA-256 | 8/8 |
| Definitions reconstructed with anchored PDF quotation | 7/8 |
| PNPK documents without available PDF in this recovery | 72/80 (quarantined) |
| Non-PNPK entries pending primary-source checks | 64/64 |
| Records labeled clinically verified or complete | 0/144 |
| Default-active clinical retrieval records | 0/144 |
| Original input ZIP preserved unmodified | PASS |
| ZIP CRC integrity | PASS |

## Corrections to confirmed defective examples

| Disease | Defect in original parsing | Recovery action |
| --- | --- | --- |
| Hipertensi Dewasa | `definisi` was diabetes complication definition | Recovered original PNPK HTN definition from PDF p.10; retained historical regulatory state; marked clinical QA incomplete |
| Diabetes Melitus Tipe 2 Dewasa | `diagnosis` contained bibliography about diabetic foot | Rebuilt diagnosis summary from 20 source-anchored curated facts, excluding bibliography |
| Diabetes Melitus Pada Anak | `definisi` was hypoglycemia | Recovered actual definition from PNPK p.13 |
| Sepsis | `definisi` described septic shock and `gejala` empty | Recovered sepsis source description from PNPK p.10, added available source-grounded diagnostic facts |
| Remaining 72 PNPK | Sections cannot be reconciled to source PDF locally | Replaced exposed fields with missing-data marker; preserved originals in raw archive |
| 64 non-PNPK records | No source-PDF or regulatory validation | Preserved existing text as unverified candidates, disabled clinical retrieval |

## Known clinical safety blockers

1. **No clinician attestation:** No result should be considered a validated clinical treatment guideline or diagnosis engine.
2. **Adult PNPK supersession:** DM type 2 2020 and HTN 2021 are historical. Active 2026 replacement source contents have not been ingested into these records.
3. **Regulatory status of six other PNPK sources:** Unverified in this repair. Do not assume `ACTIVE`.
4. **Diagnostic-only scope:** Prior SQLite curated diagnostic evidence but not treatment or referral. Accordingly those fields are explicitly missing and NOT filled with potentially wrong legacy text.
5. **14 visual-only sepsis facts:** Their source anchors use prior page-specific visual inspection logs, not machine-verifiable text-exact matches; retained as visual provenance, not independently revalidated clinical statements here.
6. **Pediatric HTN definition:** No concise one-sentence anchored definition was recovered; this field remains missing while relevant diagnostic classifications remain sourced under clinical evidence.
7. **Adult hypertension 2021 source wording:** A prose definition on PDF p.10 uses `>140`/`>90`, while the table on that page includes ranges starting at 140/90. Source text should be handled as historically versioned and clinician reviewed, not translated blindly into executable thresholds.
8. **Source quotations:** Original quote strings may contain embedded page watermarks, preserved in the audit evidence. They are separate from repaired reader-facing clinical fields.

## Verified input integrity

- SQLite: `PRAGMA integrity_check = ok`; no foreign-key violations.
- 8 source PDF originals: SHA-256 equals the stored PNPK document record.
- New ZIP: CRC passes; 144 repaired JSON, 144 new Markdown, 144 archived raw JSON, 8 PDF originals, original input ZIP, original SQLite checkpoint.

## Release decision

**Do not connect this recovered ZIP directly to automatic clinical decision-support retrieval.** Clinical consumers must enforce `metadata.clinical_retrieval_allowed = false` until the relevant field evidence is approved, current regulations are checked, and a clinician signs off. 8 source-grounded diagnostic subsets are available for human review and for building a safer parser. The full 144-document knowledge base is not yet clinically curated or validated.
