# Glass Health Indonesia - Clinical Knowledge Base (v2.0)

Basis Data Pengetahuan Klinis Standar Kompetensi Dokter Indonesia (SKDI 4A Layanan Primer / Puskesmas) bersumber dari Pedoman Nasional Pelayanan Kedokteran (PNPK) Kementerian Kesehatan RI.

## 📊 Statistik Koleksi
- **Total Penyakit**: 80 Penyakit Terstandarisasi
- **Kode ICD-10 UNKNOWN**: 0 (100% Terpetakan)
- **Definisi Medis**: 100% Terisi
- **Tatalaksana & Terapi**: 100% Terisi (Dosis & lini pengobatan PNPK)
- **Kriteria Rujukan**: 100% Terisi
- **Format**: PostgreSQL Database + Dual Artifact (RAG Markdown + JSON API)

## 📁 Struktur Direktori
```
knowledge_base/
├── catalog.json          # Master indeks seluruh 80 penyakit
├── json/                 # 80 dokumen JSON terstruktur untuk API & sistem
└── markdown/             # 80 dokumen Markdown dengan YAML frontmatter (RAG/Vector ready)
```

## 🤖 Pemanfaatan untuk AI & DX-RAG
1. **Semantic Search / Vector Store**:
   Gunakan file di `markdown/` sebagai unit chunking dokumen. YAML Frontmatter menyediakan metadata filtering (`category`, `icd_10`, `id`).
2. **Clinical Decision Support API**:
   Gunakan file di `json/` atau query langsung ke database PostgreSQL `glass_health`.
