Unmodified pre-repair JSON snapshots. NEVER use raw_original for active clinical retrieval.
