# Sentra Clinical Core — Parsed Knowledge Base Recovery

**Result: PARTIAL SOURCE REPAIR COMPLETE; NOT CLINICALLY CLEARED FOR USE.**

## What was fixed
- Kept 144 distinct disease IDs/slugs and updated the JSON/Markdown/catalog consistently.
- Rebuilt exactly 8 PNPK records from 182 curated facts in an independent PNPK SQLite checkpoint with per-fact PDF page links and original evidence quotations.
- Reconstructed 7 definitions as source-exact snippets with PDF page citations; no unsupported definitions were invented.
- Replaced incorrect or unverified therapeutic/referral and unreconciled PNPK sections with **Belum tersedia — lengkapi dan verifikasi oleh klinisi**.
- Quarantined 72 additional PNPK records because corresponding source PDFs were not available for deterministic source reconciliation in this run.
- Kept 64 non-PNPK entries as **UNVERIFIED CANDIDATES** only. Their existing text is not certified or rewritten.
- Set `verified_clinical_kb=false`, `is_complete=false` and `clinical_retrieval_allowed=false` for all 144 until independent clinical QA and legal version checks.
- Preserved all original 144 JSON snapshots and original ZIP unmodified in `raw_original/`.
- Included eight PDF originals with matching source SHA-256 and SQLite checkpoint for reproducible evidence reconciliation.

## Evidence
- 182 facts: 168 exact PDF-text matches, 14 visual evidence links verified through previous batch review logs.
- 2 superseded adult PNPKs: hypertension 2021 and type-2 diabetes 2020; do not use as active guidance.
- Other six sources remain regulatory-status UNVERIFIED (not an assertion of ACTIVE).
- No clinical reviewer attestation. No independent guideline-concordance certification.

## Safe implementation
Use `knowledge_base/catalog.json` status fields. Only promote any record after per-field clinical evidence review, supersession check, and explicit clinician approval. Unverified candidates and quarantined fields must not be included in default clinical decision support, automation, or therapy generation.

## Files
- `knowledge_base/json/`: 144 recovered records; all trust flags disabled.
- `knowledge_base/markdown/`: matching Markdown, prominently labeled with clinical QA state.
- `knowledge_base/catalog.json`: consistent listing and status.
- `source_grounded_diagnostic_facts.jsonl`: 182 facts with PDF page anchors.
- `source_pdfs/`: eight verified original PDFs.
- `source_checkpoint.sqlite`: previous PNPK curated DB, untouched.
- `raw_original/`: all initial JSON and ZIP for audit/reversibility.
- `repair_manifest.json`: machine-readable quality report.

## Work remaining
72 PNPK source reconciliations + 64 other-source validations; separate per-document curation of therapy/referral (not previously curated), pediatric HTN definition, regulatory check for 6 guideline versions, and independent clinician sign-off.
