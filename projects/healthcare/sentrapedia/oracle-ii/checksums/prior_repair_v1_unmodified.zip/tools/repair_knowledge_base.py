#!/usr/bin/env python3
"""Deterministic, safety-gated recovery of local Sentra knowledge_base.zip.

Recovers exact source evidence from the 8-document Sentra PNPK SQLite checkpoint.
Never infers clinical facts or treats unchecked legacy fields as verified.
"""
from __future__ import annotations
import collections
import datetime
import hashlib
import json
import pathlib
import re
import shutil
import sqlite3
import zipfile

ROOT=pathlib.Path('/mnt/data')
ORIGINAL=ROOT/'knowledge_base.zip'
DB=ROOT/'sentra_pnpk/sentra_clinical_core.sqlite'
OUT=ROOT/'knowledge_base_repaired'
KB=OUT/'knowledge_base'
MISSING='Belum tersedia — lengkapi dan verifikasi oleh klinisi'
MAP={
 '044':'infeksi-dengue-pada-dewasa',
 '039':'infeksi-dengue-anak-dan-remaja',
 '078':'sepsis',
 '041':'sepsis-pada-anak',
 '045':'diabetes-melitus-tipe-2-dewasa',
 '035':'hipertensi-dewasa',
 '003':'diabetes-melitus-pada-anak',
 '034':'hipertensi-pada-anak',
}
DEFINITIONS={
 '044':('Infeksi dengue adalah penyakit infeksi virus akut', 5),
 '039':('Infeksi dengue adalah penyakit yang disebabkan oleh virus dengue', 5),
 '078':('Sepsis merupakan respons sistemik pejamu terhadap infeksi', 10),
 '041':('Sepsis adalah disfungsi organ yang mengancam kehidupan', 10),
 '045':('DM merupakan suatu kelompok penyakit metabolik', 11),
 '035':('Hipertensi adalah suatu keadaan dimana', 10),
 '003':('Diabetes adalah kelainan metabolik kompleks', 13),
 # Pediatric HTN has a percentile-based table; no one-sentence definition is forced.
}
DIAGNOSTIC_CATS={'diagnostic_criteria','differential_diagnosis','laboratory','supporting_investigation'}
SIGNS_CATS={'signs_symptoms'}
REG_REPLACEMENTS={'045':('SUPERSEDED','HK.01.07/MENKES/302/2026'), '035':('SUPERSEDED','HK.01.07/MENKES/303/2026')}

def dump_json(path, data):
 path.parent.mkdir(parents=True, exist_ok=True)
 path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def norm(t):
 return re.sub(r'\s+',' ',t).strip().casefold()

def sha256(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def definition_from_page(text,phrase):
 match=re.search(re.escape(phrase), text,re.I)
 if not match:raise AssertionError('definition evidence phrase absent: '+phrase)
 end=text.find('.',match.start())
 if end<0 or end-match.start()>450: raise AssertionError('ambiguous definition boundary: '+phrase)
 return text[match.start():end+1].strip()

def md_escape(t):
 return str(t).replace('\\','\\\\').replace('"','\\"').replace('\n',' ')

def make_markdown(j):
 meta=j['metadata'];state=meta['clinical_qa_status'];
 lines=['---',f'id: {j["id"]}',f'title: "{md_escape(j["nama"])}"',f'slug: "{md_escape(j["slug"])}"',f'icd_10: "{md_escape(j["kode_icd"])}"',f'clinical_qa_status: "{state}"','is_complete: false','verified_clinical_kb: false','---','',f'# {j["nama"]}','',f'> **Clinical QA: {state}.** Tidak untuk penggunaan otomatis dalam pengambilan keputusan klinis sebelum validasi dokter.','']
 if meta['origin_type']=='PNPK' and state=='SOURCE_GROUNDED_DIAGNOSTIC_SUBSET':
  pv=j['source_provenance'];lines += [f'**Sumber:** {pv["filename"]} ({pv["kmk_number"]})',f'**Regulasi:** {pv["regulatory_status"]}',f'**Populasi:** {pv["population"]}','']
  if pv['regulatory_status']=='SUPERSEDED':lines += ['> **Historical only:** PNPK ini telah digantikan. Jangan digunakan sebagai pedoman klinis aktif.','']
  lines += ['## Definisi',j['definisi']+(' (PDF p.'+str(j['definition_citation']['pdf_page'])+')' if j['definition_citation'] else ''),'','## Gejala',*([f'- {x}' for x in j['gejala']] or [MISSING]),'','## Diagnosis (ringkasan berbasis fakta terkurasi)',j['diagnosis'],'','## Terapi',j['terapi'],'','## Rujukan',j['rujukan'],'','## Fakta dan Sitasi PDF','']
  for f in j['clinical_evidence']:
   lines += [f'### {f["fact_id"]} — {f["evidence_category"]} — PDF p.{f["pdf_page"]}',f'**Konsep:** {f["concept"]}',f'**Kutipan sumber:** {f["evidence_quote"]}',f'**Metode verifikasi:** {f["source_anchor_type"]}','']
  lines += ['**Batas cakupan:** Diagnosis-oriented curation; terapi dan rujukan tidak dikurasi dalam checkpoint sumber. Tidak ada clinical approval independen.','']
 else:
  lines += ['## Status parsing',('Arsip PNPK sebelumnya mengandung section misclassification; semua field klinis lama dipindah ke `raw_original/` untuk audit.' if meta['origin_type']=='PNPK' else 'Data SKDI/non-PNPK dipertahankan sebagai kandidat, belum direkonsiliasi dengan dokumen sumber asli.'),'',f'**Referensi sumber:** {", ".join(s.get("source", "-") for s in j["sumber"])}','']
  for label,key in [('Definisi','definisi'),('Gejala','gejala'),('Diagnosis','diagnosis'),('Terapi','terapi'),('Rujukan','rujukan')]:
   lines.append('## '+label)
   if key=='gejala':lines.extend([f'- {x}' for x in j[key]] if j[key] else [MISSING])
   else:lines.append(j[key])
   lines.append('')
 return '\n'.join(lines)+'\n'

def main():
 if OUT.exists():shutil.rmtree(OUT)
 for d in [KB/'json',KB/'markdown',OUT/'raw_original',OUT/'source_pdfs',OUT/'tools']:d.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(ORIGINAL) as z:
  assert z.testzip() is None,'Original ZIP integrity fail'
  originals={pathlib.PurePosixPath(n).stem:json.loads(z.read(n)) for n in z.namelist() if n.startswith('knowledge_base/json/') and n.endswith('.json')}
  old_catalog=json.loads(z.read('knowledge_base/catalog.json'))
  original_readme=z.read('knowledge_base/README.md').decode('utf-8')
 assert len(originals)==144
 db=sqlite3.connect(f'file:{DB.as_posix()}?mode=ro',uri=True);db.row_factory=sqlite3.Row
 assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
 assert db.execute('PRAGMA foreign_key_check').fetchall()==[]
 docs={r['file_no']:dict(r) for r in db.execute('SELECT * FROM documents')}
 assert set(MAP)==set(docs)
 factual={key:[dict(r) for r in db.execute('select * from clinical_facts where file_id=? order by fact_id',(d['file_id'],))] for key,d in docs.items()}
 assert sum(map(len,factual.values()))==182
 visual={(r['file_id'],r['pdf_page']):dict(r) for r in db.execute('select * from visual_review_log')}
 summary=collections.Counter();citation_checks=collections.Counter();failure=[]
 converted={}; sourced_facts=[]
 all_doc_refs={}
 for fn, slug in MAP.items():
  doc=docs[fn]
  pdf=ROOT/doc['filename']
  assert pdf.is_file() and sha256(pdf)==doc['sha256'],'Missing or changed source PDF '+fn
  shutil.copy2(pdf,OUT/'source_pdfs'/pdf.name)
  all_doc_refs[fn]={k:doc[k] for k in ('file_id','file_no','topic','year','kmk_number','clinical_population','disease_group','drive_url','filename','sha256','page_count')}
  all_doc_refs[fn]['regulatory_status'], all_doc_refs[fn]['replaced_by_kmk']=REG_REPLACEMENTS.get(fn,('UNVERIFIED',None))
  old=originals[slug]
  new=json.loads(json.dumps(old))
  data=[]
  for f in factual[fn]:
   rawpage=db.execute('select text_search from pages where file_id=? and pdf_page=?',(doc['file_id'],f['pdf_page'])).fetchone()
   assert rawpage is not None and f['review_status']=='SOURCE_VERIFIED'
   quote=f['evidence_quote']
   if norm(quote) in norm(rawpage[0]): anchor='PDF_TEXT_EXACT_MATCH';citation_checks['pdf_text_exact_match']+=1
   else:
    log=visual.get((doc['file_id'],f['pdf_page']))
    assert f['verification_method']=='direct_visual_verified' and log and log['clinical_validation']=='SOURCE_VERIFIED_DIAGNOSTIC',f"Unverifiable fact {f['fact_id']}"
    anchor='SOURCE_VISUAL_REVIEW_LOG';citation_checks['previous_visual_review_log']+=1
   it={k:f[k] for k in ('fact_id','pdf_page','printed_page','evidence_category','clinical_population','disease_group','disease_subtype','concept','evidence_quote','verification_method','source_char_offset','search_aliases','review_status')}
   it.update(source_anchor_type=anchor,source_pdf_sha256=doc['sha256'],source_pdf_filename=doc['filename'],source_drive_url=doc['drive_url'],regulatory_status=all_doc_refs[fn]['regulatory_status'])
   data.append(it);sourced_facts.append(dict(it,disease_slug=slug))
  assert data
  definition=MISSING
  definition_citation=None
  if fn in DEFINITIONS:
   phrase,page=DEFINITIONS[fn]
   text=db.execute('select text_search from pages where file_id=? and pdf_page=?',(doc['file_id'],page)).fetchone()[0]
   definition=definition_from_page(text,phrase)
   assert norm(definition) in norm(text)
   definition_citation={'pdf_page':page,'quote':definition,'pdf_filename':doc['filename'],'drive_url':doc['drive_url'],'source_anchor_type':'PDF_TEXT_EXACT_MATCH'}
  new['definisi']=definition
  new['gejala']=[f['concept'] for f in data if f['evidence_category'] in SIGNS_CATS]
  dx=[f"- [PDF p.{f['pdf_page']}; fact #{f['fact_id']}] {f['concept']}" for f in data if f['evidence_category'] in DIAGNOSTIC_CATS]
  new['diagnosis']='\n'.join(dx) if dx else MISSING
  new['terapi']=MISSING
  new['rujukan']=MISSING
  new['clinical_evidence']=data
  new['definition_citation']=definition_citation
  new['source_provenance']={'drive_file_id':doc['file_id'],'drive_url':doc['drive_url'],'filename':doc['filename'],'file_sha256':doc['sha256'],'kmk_number':doc['kmk_number'],'year':doc['year'],'population':doc['clinical_population'],'regulatory_status':all_doc_refs[fn]['regulatory_status'],'replaced_by_kmk':all_doc_refs[fn]['replaced_by_kmk'],'source_version_note':doc['source_version_note'],'source_pdf_page_count':doc['page_count']}
  new['sumber']=[{'source':f"PNPK {doc['year']} | {doc['kmk_number']}",'type':'PNPK','year':doc['year'],'file_id':doc['file_id'],'drive_url':doc['drive_url'],'sha256':doc['sha256'],'filename':doc['filename'],'regulatory_status':all_doc_refs[fn]['regulatory_status']}]
  new['metadata']={**new['metadata'],'is_complete':False,'verified_clinical_kb':False,'clinical_qa_status':'SOURCE_GROUNDED_DIAGNOSTIC_SUBSET','origin_type':'PNPK','clinical_approval':'NOT_PERFORMED','parser_repaired':True,'original_data_quarantined':True,'clinical_retrieval_allowed':False,'source_fact_count':len(data),'definition_status':('PDF_ANCHORED' if definition_citation else 'MISSING'),'clinical_scoping':'DIAGNOSTIC_ONLY'}
  converted[slug]=new
 for slug,old in originals.items():
  dump_json(OUT/'raw_original'/f'{slug}.json',old)
  if slug in converted:continue
  j=json.loads(json.dumps(old))
  pnpk=any(s.get('type','').upper()=='PNPK' for s in j['sumber'])
  if pnpk:
   j['definisi']=MISSING;j['gejala']=[];j['diagnosis']=MISSING;j['terapi']=MISSING;j['rujukan']=MISSING
   j['clinical_evidence']=[]
   j['metadata']['clinical_qa_status']='QUARANTINED_PNPK_SOURCE_REQUIRED'
   summary['pnpk_quarantined']+=1
  else:
   j['clinical_evidence']=[]
   j['metadata']['clinical_qa_status']='UNVERIFIED_NON_PNPK_CANDIDATE'
   summary['non_pnpk_candidates']+=1
  j['metadata'].update(is_complete=False,verified_clinical_kb=False,clinical_approval='NOT_PERFORMED',parser_repaired=False,origin_type='PNPK' if pnpk else 'NON_PNPK',original_data_quarantined=True,clinical_retrieval_allowed=False)
  converted[slug]=j
 assert len(converted)==144
 for slug,j in sorted(converted.items()):
  dump_json(KB/'json'/f'{slug}.json',j)
  (KB/'markdown'/f'{slug}.md').write_text(make_markdown(j),encoding='utf-8')
 assert len([x for x in converted.values() if x['metadata']['clinical_qa_status']=='SOURCE_GROUNDED_DIAGNOSTIC_SUBSET'])==8
 summary['source_grounded_subsets']=8
 catalog={**old_catalog,'title':'Sentra Clinical Core — Recovery catalog (clinical QA gated)','version':'3.0.0-recovery','repair_scope':'8 PNPK diagnostic subsets source-reconciled; 72 PNPK entries quarantined; 64 non-PNPK remain unverified','clinical_retrieval_default':'DISABLED_UNTIL_REGULATORY_AND_CLINICIAN_APPROVAL'}
 for item in catalog['diseases']:
  j=converted[item['slug']]
  item.update(gejala_count=len(j['gejala']),sources_count=len(j['sumber']),clinical_qa_status=j['metadata']['clinical_qa_status'],is_complete=False,verified_clinical_kb=False,clinical_retrieval_allowed=False,source_fact_count=len(j['clinical_evidence']))
 dump_json(KB/'catalog.json',catalog)
 (OUT/'raw_original'/'README.txt').write_text('Unmodified pre-repair JSON snapshots. NEVER use raw_original for active clinical retrieval.\n',encoding='utf-8')
 shutil.copy2(ORIGINAL,OUT/'raw_original'/'knowledge_base_original.zip')
 (OUT/'raw_original'/'original_README.md').write_text(original_readme,encoding='utf-8')
 shutil.copy2(DB,OUT/'source_checkpoint.sqlite')
 dump_json(OUT/'source_documents.json',all_doc_refs)
 facts_path=OUT/'source_grounded_diagnostic_facts.jsonl'
 with facts_path.open('w',encoding='utf-8') as fo:
  for r in sorted(sourced_facts,key=lambda x:x['fact_id']):fo.write(json.dumps(r,ensure_ascii=False)+'\n')
 result={
  'status':'PARTIAL_SOURCE_REPAIR_COMPLETE','date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'original_archive_sha256':sha256(ORIGINAL), 'source_database_sha256':sha256(DB),
  'total_records':144,**dict(summary),'source_anchored_facts':len(sourced_facts),
  'source_anchor_checks':dict(citation_checks), 'source_documents':len(docs),
  'definitions_pdf_anchored':sum(bool(x.get('definition_citation')) for x in converted.values()),
  'clinical_approved_records':0,
  'audit_issues':{
   'source_unavailable_for_rebuild_pnpk':summary['pnpk_quarantined'],
   'non_pnpk_source_not_verified':summary['non_pnpk_candidates'],
   'treatment_referral_not_recaptured_in_diagnostic_only_checkpoint':8,
   'pediatric_htn_definition_requires_dedicated_normalized_percentile_review':1,
   'regulatory_status_unverified_on_six_source_documents':6,
   '14 visually transcribed facts rely on previous direct_visual_review_log, not extracted PDF text':14,
  },
  'integrity_checks':{'zip_source_crc':'PASS','sqlite_integrity':'PASS','sqlite_foreign_keys':'PASS','source_pdf_sha256':'PASS_8_OF_8','fact_provenance':'PASS_182_OF_182','record_ids':'PRESERVED_144_OF_144','raw_originals':'PRESERVED_144_OF_144','all_trust_flags_false':'PASS','active_clinical_retrieval_disabled':'PASS'}
 }
 dump_json(OUT/'repair_manifest.json',result)
 # Recovery readme
 readme=f'''# Sentra Clinical Core — Parsed Knowledge Base Recovery\n\n**Result: PARTIAL SOURCE REPAIR COMPLETE; NOT CLINICALLY CLEARED FOR USE.**\n\n## What was fixed\n- Kept 144 distinct disease IDs/slugs and updated the JSON/Markdown/catalog consistently.\n- Rebuilt exactly 8 PNPK records from 182 curated facts in an independent PNPK SQLite checkpoint with per-fact PDF page links and original evidence quotations.\n- Reconstructed 7 definitions as source-exact snippets with PDF page citations; no unsupported definitions were invented.\n- Replaced incorrect or unverified therapeutic/referral and unreconciled PNPK sections with **{MISSING}**.\n- Quarantined 72 additional PNPK records because corresponding source PDFs were not available for deterministic source reconciliation in this run.\n- Kept 64 non-PNPK entries as **UNVERIFIED CANDIDATES** only. Their existing text is not certified or rewritten.\n- Set `verified_clinical_kb=false`, `is_complete=false` and `clinical_retrieval_allowed=false` for all 144 until independent clinical QA and legal version checks.\n- Preserved all original 144 JSON snapshots and original ZIP unmodified in `raw_original/`.\n- Included eight PDF originals with matching source SHA-256 and SQLite checkpoint for reproducible evidence reconciliation.\n\n## Evidence\n- {len(sourced_facts)} facts: {citation_checks['pdf_text_exact_match']} exact PDF-text matches, {citation_checks['previous_visual_review_log']} visual evidence links verified through previous batch review logs.\n- 2 superseded adult PNPKs: hypertension 2021 and type-2 diabetes 2020; do not use as active guidance.\n- Other six sources remain regulatory-status UNVERIFIED (not an assertion of ACTIVE).\n- No clinical reviewer attestation. No independent guideline-concordance certification.\n\n## Safe implementation\nUse `knowledge_base/catalog.json` status fields. Only promote any record after per-field clinical evidence review, supersession check, and explicit clinician approval. Unverified candidates and quarantined fields must not be included in default clinical decision support, automation, or therapy generation.\n\n## Files\n- `knowledge_base/json/`: 144 recovered records; all trust flags disabled.\n- `knowledge_base/markdown/`: matching Markdown, prominently labeled with clinical QA state.\n- `knowledge_base/catalog.json`: consistent listing and status.\n- `source_grounded_diagnostic_facts.jsonl`: 182 facts with PDF page anchors.\n- `source_pdfs/`: eight verified original PDFs.\n- `source_checkpoint.sqlite`: previous PNPK curated DB, untouched.\n- `raw_original/`: all initial JSON and ZIP for audit/reversibility.\n- `repair_manifest.json`: machine-readable quality report.\n\n## Work remaining\n72 PNPK source reconciliations + 64 other-source validations; separate per-document curation of therapy/referral (not previously curated), pediatric HTN definition, regulatory check for 6 guideline versions, and independent clinician sign-off.\n'''
 (OUT/'README.md').write_text(readme,encoding='utf-8')
 shutil.copy2(pathlib.Path(__file__), OUT/'tools'/'repair_knowledge_base.py')
 outzip=ROOT/'SENTRA_KNOWLEDGE_BASE_REPAIR_V1_PARTIAL_QA_GATED.zip'
 if outzip.exists():outzip.unlink()
 with zipfile.ZipFile(outzip,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
  for p in sorted(OUT.rglob('*')):
   if p.is_file():z.write(p,p.relative_to(OUT))
 with zipfile.ZipFile(outzip) as z:
  assert z.testzip() is None
  assert len([n for n in z.namelist() if n.startswith('knowledge_base/json/')])==144
  assert len([n for n in z.namelist() if n.startswith('knowledge_base/markdown/')])==144
  assert len([n for n in z.namelist() if n.startswith('source_pdfs/')])==8
  assert len([n for n in z.namelist() if n.startswith('raw_original/') and n.endswith('.json')])==144
  assert all(not json.loads(z.read(n))['metadata']['verified_clinical_kb'] for n in z.namelist() if n.startswith('knowledge_base/json/') and n.endswith('.json'))
 print('REPAIR',json.dumps(result,ensure_ascii=False))
 print('ZIP',outzip,outzip.stat().st_size,'entries',len(z.namelist()))
 print('README',OUT/'README.md')
 print('MANIFEST',OUT/'repair_manifest.json')

if __name__=='__main__':main()
