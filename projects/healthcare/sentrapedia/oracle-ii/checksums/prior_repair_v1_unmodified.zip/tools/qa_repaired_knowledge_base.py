#!/usr/bin/env python3
import collections,hashlib,json,re,sqlite3,zipfile
from pathlib import Path
R=Path('/mnt/data/knowledge_base_repaired');Z=Path('/mnt/data/SENTRA_KNOWLEDGE_BASE_REPAIR_V1_PARTIAL_QA_GATED.zip');O=Path('/mnt/data/knowledge_base.zip')
assert Z.is_file() and Z.stat().st_size>0
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 assert 'tools/repair_knowledge_base.py' in z.namelist()
 assert 'source_checkpoint.sqlite' in z.namelist()
 manifest=json.loads(z.read('repair_manifest.json'))
 assert manifest['total_records']==144
 objs={Path(n).stem:json.loads(z.read(n)) for n in z.namelist() if re.fullmatch(r'knowledge_base/json/[^/]+\.json',n)}
 assert len(objs)==144
 asserts=collections.Counter()
 cat=json.loads(z.read('knowledge_base/catalog.json'))
 assert len(cat['diseases'])==144 and len({v['slug'] for v in cat['diseases']})==144
 asserts['catalog_records_and_unique_slugs']=144
 for row in cat['diseases']:
  d=objs[row['slug']]
  assert row['id']==d['id'] and row['source_fact_count']==len(d['clinical_evidence'])
  assert row['gejala_count']==len(d['gejala']) and row['sources_count']==len(d['sumber'])
  assert row['verified_clinical_kb'] is False and row['clinical_retrieval_allowed'] is False
  assert not d['metadata']['verified_clinical_kb'] and not d['metadata']['is_complete'] and not d['metadata']['clinical_retrieval_allowed']
  md=z.read(row['markdown_file'].replace('markdown/','knowledge_base/markdown/')).decode()
  assert 'is_complete: false' in md and 'verified_clinical_kb: false' in md
  old=json.loads(z.read(f'raw_original/{d["slug"]}.json'))
  assert old['id']==d['id'] and old['slug']==d['slug']
  asserts['record_schema_catalog_raw_parity']=144
 states=collections.Counter(d['metadata']['clinical_qa_status'] for d in objs.values())
 assert states=={'SOURCE_GROUNDED_DIAGNOSTIC_SUBSET':8,'QUARANTINED_PNPK_SOURCE_REQUIRED':72,'UNVERIFIED_NON_PNPK_CANDIDATE':64}
 asserts['status_gate_counts']=1
 assert all(len(d['clinical_evidence'])==0 and d['diagnosis'].startswith('Belum tersedia') for d in objs.values() if d['metadata']['clinical_qa_status']=='QUARANTINED_PNPK_SOURCE_REQUIRED')
 asserts['pnpk_quarantine_suppressed_exposed_fields']=72
 assert all(not d['metadata']['clinical_retrieval_allowed'] for d in objs.values())
 asserts['default_clinical_gate']=144
 base=json.loads(z.read('source_documents.json'))
 for num,doc in base.items():
  pb=z.read(f'source_pdfs/{doc["filename"]}')
  assert hashlib.sha256(pb).hexdigest()==doc['sha256']
  asserts['verified_source_pdfs']=8
 facts=[json.loads(x) for x in z.read('source_grounded_diagnostic_facts.jsonl').splitlines()]
 assert len(facts)==182 and len({f['fact_id'] for f in facts})==182
 asserts['unique_facts']=182
 for f in facts:
  assert f['source_anchor_type'] in ('PDF_TEXT_EXACT_MATCH','SOURCE_VISUAL_REVIEW_LOG')
  assert 1<=f['pdf_page']<=next(doc['page_count'] for doc in base.values() if doc['sha256']==f['source_pdf_sha256'])
  asserts['fact_with_valid_page_and_source_sha']=182
 for d in objs.values():
  if d['metadata']['clinical_qa_status']=='SOURCE_GROUNDED_DIAGNOSTIC_SUBSET':
   assert len(d['clinical_evidence'])>0
   for f in d['clinical_evidence']:
    assert f['evidence_quote'] and f['pdf_page'] and f['concept']
   for k in ('definisi','diagnosis','terapi','rujukan'):
    assert 'jdih.kemkes.go.id' not in d[k]
 assert objs['hipertensi-dewasa']['definisi'].startswith('Hipertensi adalah')
 assert not objs['hipertensi-dewasa']['definisi'].startswith('Penyulit')
 assert 'daftar pustaka' not in objs['diabetes-melitus-tipe-2-dewasa']['diagnosis'].lower()
 assert objs['diabetes-melitus-pada-anak']['definisi'].startswith('Diabetes adalah kelainan metabolik kompleks')
 assert objs['sepsis']['definisi'].startswith('Sepsis merupakan respons sistemik')
 asserts['observed_wrong_field_corrections']=4
 assert objs['hipertensi-dewasa']['source_provenance']['regulatory_status']=='SUPERSEDED'
 assert objs['diabetes-melitus-tipe-2-dewasa']['source_provenance']['regulatory_status']=='SUPERSEDED'
 asserts['superseded_adult_guidelines_not_active']=2
 assert z.read('raw_original/knowledge_base_original.zip')==O.read_bytes()
 asserts['original_zip_bytes_exactly_preserved']=1
 print('ZIP_CRC PASS; entries',len(z.namelist()))
 print('QA_PASS',json.dumps(asserts,ensure_ascii=False))
 print('STATUS_COUNTS',dict(states))
 print('KEY_EXAMPLES',json.dumps({s:{'definition':objs[s]['definisi'],'facts':len(objs[s]['clinical_evidence']),'status':objs[s]['metadata']['clinical_qa_status']} for s in ['hipertensi-dewasa','diabetes-melitus-tipe-2-dewasa','diabetes-melitus-pada-anak','sepsis']},ensure_ascii=False))
