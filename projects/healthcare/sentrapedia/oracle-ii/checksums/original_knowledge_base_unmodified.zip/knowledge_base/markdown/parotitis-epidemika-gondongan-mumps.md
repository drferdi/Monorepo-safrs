---
id: 306
title: "Parotitis Epidemika (Gondongan / Mumps)"
slug: "parotitis-epidemika-gondongan-mumps"
icd_10: "B26.9"
category: "Penyakit Anak"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Parotitis Epidemika (Gondongan / Mumps) (ICD-10: B26.9)

**Kategori Medis**: Penyakit Anak  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Parotitis epidemika adalah penyakit infeksi virus menular akut yang disebabkan oleh Paramyxovirus, ditandai dengan pembengkakan dan nyeri pada satu atau kedua kelenjar saliva parotis, ditularkan melalui droplet respirasi atau kontak langsung saliva.

---

## 2. Gejala & Manifestasi Klinis
- Demam subfebris, malaise, nyeri kepala, anoreksia
- Pembengkakan kelenjar parotis di depan dan bawah telinga (unilateral lalu bilateral)
- Nyeri saat membuka mulut, mengunyah, atau menelan makanan asam
- Eritema pada orifisium duktus Stensen

---

## 3. Kriteria & Alur Diagnosis
Penegakan diagnosis klinis berdasarkan anamnesis demam yang disertai pembengkakan khas kelenjar parotis yang mengangkat daun telinga. Pemeriksaan fisik: pembengkakan teraba lunak, nyeri tekan, batas tidak tegas di angulus mandibula.

---

## 4. Tatalaksana & Terapi
1. Penanganan bersifat suportif simtomatik (penyakit swasirna dalam 7-10 hari):
   - Tirah baring selama masa demam.
   - Kompres hangat atau dingin pada area parotis yang bengkak.
   - Diet lunak dan hidrasi cukup, hindari makanan/minuman berasa asam.
   - Analgesik-antipiretik: Parasetamol 10-15 mg/kgBB/kali pada anak atau 500 mg 3-4x/hari pada dewasa; Ibuprofen 200-400 mg 3x/hari.
2. Isolasi penderita minimal 5 hari sejak pembengkakan parotis muncul.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke FKRTL bila terjadi komplikasi sistemik: orkitis/epididimitis pada laki-laki pascapubertas (testis bengkak dan sangat nyeri), ooforitis, pankreatitis akut (nyeri epigastrium hebat), atau meningoensefalitis gondongan (kaku kuduk, penurunan kesadaran).

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
