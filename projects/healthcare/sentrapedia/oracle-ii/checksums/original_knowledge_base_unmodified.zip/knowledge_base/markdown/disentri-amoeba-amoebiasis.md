---
id: 296
title: "Disentri Amoeba (Amoebiasis)"
slug: "disentri-amoeba-amoebiasis"
icd_10: "A06.0"
category: "Penyakit Infeksi"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Disentri Amoeba (Amoebiasis) (ICD-10: A06.0)

**Kategori Medis**: Penyakit Infeksi  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Disentri amuba adalah infeksi usus besar yang disebabkan oleh protozoa parasit Entamoeba histolytica, yang menginvasi mukosa dinding kolon membentuk ulkus khas berbentuk botol (flask-shaped ulcer).

---

## 2. Gejala & Manifestasi Klinis
- Diare lendir darah berbau busuk khas
- Tenesmus ringan hingga sedang
- Nyeri perut bawah / kram abdomen
- BAB berulang dengan volume tinja sedikit-sedikit
- Demam ringan (subfebris)

---

## 3. Kriteria & Alur Diagnosis
Penegakan diagnosis melalui pemeriksaan mikroskopis tinja segar: ditemukan kista berinti 4 atau trofozoit motil Entamoeba histolytica yang memfagositosis sel darah merah (eritrofagositosit).

---

## 4. Tatalaksana & Terapi
1. Rehidrasi adekuat.
2. Farmakologis Amebisid Jaringan:
   - Metronidazol: Dewasa 3 x 750 mg oral per hari selama 7-10 hari; Anak 35-50 mg/kgBB/hari dibagi 3 dosis selama 7-10 hari.
   - Alternatif: Tinidazol 1 x 2 gram oral per hari selama 3 hari.
3. Edukasi sanitasi air bersih, kebersihan mencuci tangan dengan sabun, dan memasak makanan hingga matang.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke FKRTL bila dicurigai komplikasi ekstraintestinal seperti abses hati amuba (nyeri perut kuadran kanan atas, hepatomegali nyeri, demam septik), perforasi usus, atau peritonitis amuba.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
