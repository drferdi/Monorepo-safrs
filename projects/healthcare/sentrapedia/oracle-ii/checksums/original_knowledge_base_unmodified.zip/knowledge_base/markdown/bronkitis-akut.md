---
id: 311
title: "Bronkitis Akut"
slug: "bronkitis-akut"
icd_10: "J20.9"
category: "Penyakit Paru"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Bronkitis Akut (ICD-10: J20.9)

**Kategori Medis**: Penyakit Paru  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Bronkitis akut adalah inflamasi sementara pada trakea dan bronkus besar yang ditandai dengan batuk yang berlangsung 1 hingga 3 minggu tanpa bukti pneumonia klinis atau radiologis, 90% disebabkan oleh virus respirasi.

---

## 2. Gejala & Manifestasi Klinis
- Batuk kering yang berkembang menjadi batuk berdahak mukoid/purulen
- Rasa tidak nyaman atau perih di substernal dada saat batuk
- Malaise
- Demam subfebris
- Mengi transien saat ekspirasi

---

## 3. Kriteria & Alur Diagnosis
Eksklusi pneumonia adalah kunci diagnosis (tidak ada takipnea > 24x/menit, tidak ada takikardia > 100x/menit, tidak ada ronki basah halus konsolidasi, suhu < 38°C). Pemeriksaan fisik paru: vesikuler normal atau ronki basah kasar yang menghilang setelah batuk.

---

## 4. Tatalaksana & Terapi
1. Edukasi bahwa antibiotik TIDAK diperlukan pada bronkitis akut tanpa komplikasi karena etiologi virus.
2. Terapi Simtomatik:
   - Antitusif: Dekstrometorfan 3 x 15 mg oral bila batuk kering mengganggu tidur.
   - Ekspektoran: Gliseril guaiakolat (GG) 3 x 100-200 mg atau Mukolitik (Ambroksol 3 x 30 mg oral).
   - Bronkodilator inhalasi: SABA (Salbutamol inhaler 2 semprotan prn) bila ada hiperreaktivitas bronkus/mengi.
   - Antipiretik: Parasetamol 500 mg 3-4x/hari prn.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke RS / Spesialis Paru bila batuk berlanjut > 3 minggu (penapisan TB, asma, PPOK, atau keganasan paru), timbul hemoptisis, takipnea, hipoksemia SpO2 < 92%, atau perburukan klinis pada pasien lansia dengan komorbid.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
