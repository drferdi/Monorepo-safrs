---
id: 347
title: "Pitiriasis Rosea"
slug: "pitiriasis-rosea"
icd_10: "L42"
category: "Penyakit Kulit dan Kelamin"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Pitiriasis Rosea (ICD-10: L42)

**Kategori Medis**: Penyakit Kulit dan Kelamin  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Pitiriasis rosea adalah penyakit erupsi kulit eritemoskuamosa akut yang bersifat swasirna (self-limiting), diduga berhubungan dengan reaktivasi infeksi virus Human Herpesvirus 6 dan 7 (HHV-6/7), berlangsung selama 4 hingga 10 minggu.

---

## 2. Gejala & Manifestasi Klinis
- Herald patch (mother plaque): lesi inisial berupa plak soliter oval merah muda dengan tepi kolaret skuama halus, muncul 1-2 minggu sebelum erupsi luas
- Erupsi lesi sekunder: bercak oval kemerahan lebih kecil di badan mengikuti garis lipatan kulit (Langer's lines) membentuk pola pohon cemara terbalik (Christmas tree pattern)
- Gatal ringan hingga sedang

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan berdasarkan morfologi klinis khas herald patch yang diikuti erupsi sekunder berbentuk pola pohon cemara di punggung. Kerokan KOH negatif menyingkirkan tinea korporis. VDRL/TPHA non-reaktif menyingkirkan sifilis sekunder.

---

## 4. Tatalaksana & Terapi
1. Reassurance: Edukasi bahwa penyakit ini jinak, tidak menular, dan akan sembuh tuntas secara spontan dalam 6-8 minggu tanpa meninggalkan bekas parut.
2. Terapi Simtomatik:
   - Emolien pelembap atau bedak kocok kalamin untuk meredakan gatal.
   - Antihistamin oral (Setirizin 10 mg/hari) bila gatal mengganggu tidur.
   - Kortikosteroid topikal potensi ringan-sedang (Hidrokortison 2.5% atau Mometason 0.1%) pada lesi yang sangat gatal.
   - Mandi air suam-suam kuku, hindari mandi air panas dan sabun keras.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Kulit dan Kelamin bila lesi atipikal tidak sembuh setelah > 10-12 minggu, erupsi sangat berat luas, atau dicurigai sifilis sekunder / erupsi obat (drug eruption).

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
