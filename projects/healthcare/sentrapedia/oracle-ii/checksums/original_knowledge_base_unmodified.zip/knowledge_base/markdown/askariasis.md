---
id: 299
title: "Askariasis"
slug: "askariasis"
icd_10: "B77.9"
category: "Penyakit Infeksi"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Askariasis (ICD-10: B77.9)

**Kategori Medis**: Penyakit Infeksi  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Askariasis adalah infeksi cacing usus yang disebabkan oleh cacing nematoda besar Ascaris lumbricoides, hidup di dalam lumen usus halus manusia setelah tertelannya telur infektif yang matang di tanah.

---

## 2. Gejala & Manifestasi Klinis
- Mayoritas asimtomatik pada infeksi ringan
- Rasa tidak enak di perut, kembung, mual, nafsu makan menurun
- Keluarnya cacing dewasa melalui muntah atau tinja
- Sindrom Loeffler pada migrasi larva paru: batuk kering, sesak, mengi, demam ringan
- Malnutrisi dan gangguan tumbuh kembang pada infeksi kronik anak

---

## 3. Kriteria & Alur Diagnosis
Diagnosis pasti ditegakkan dengan ditemukannya telur Ascaris lumbricoides berdinding tebal bergerigi (telur fertil/infertil) pada pemeriksaan mikroskopis feses sediaan langsung atau metode flotasi/Kato-Katz, atau visualisasi cacing dewasa utuh.

---

## 4. Tatalaksana & Terapi
Farmakologis Antelmintik Lini Pertama:
- Albendazol: 400 mg oral dosis tunggal (dewasa dan anak usia > 2 tahun; 200 mg untuk anak 1-2 tahun).
- Mebendazol: 500 mg oral dosis tunggal, atau 2 x 100 mg/hari selama 3 hari berturut-turut.
- Pirantel Pamoat: 10-11 mg/kgBB oral dosis tunggal (maksimum 1 gram).
Edukasi mencuci tangan sebelum makan, memotong kuku, memakai alas kaki, dan sanitasi jamban sehat.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Bedah / FKRTL bila terjadi komplikasi mekanik akibat bolus cacing: obstruksi mekanik usus halus (ileus obstruktif), perforasi usus, invaginasi usus, apendisitis cacing, atau migrasi cacing ke traktus biliaris/pankreas.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
