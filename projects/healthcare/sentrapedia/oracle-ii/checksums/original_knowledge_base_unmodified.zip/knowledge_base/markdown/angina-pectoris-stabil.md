---
id: 251
title: "Angina Pectoris Stabil"
slug: "angina-pectoris-stabil"
icd_10: "I20.9"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Angina Pectoris Stabil (ICD-10: I20.9)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Angina Pectoris Stabil (APS) adalah sindrom klinis penyakit jantung koroner stabil yang ditandai dengan rasa tidak nyaman atau nyeri di dada substernal (dapat menjalar ke rahang, leher, bahu, atau lengan kiri), yang dipicu oleh aktivitas fisik atau stres emosional dan mereda dalam beberapa menit dengan istirahat atau nitrat sublingual, akibat ketidakseimbangan pasokan dan kebutuhan oksigen miokard.

---

## 2. Gejala & Manifestasi Klinis
- yang telah mendapat terapi sesuai rekomendasi dengan gejala yang masih persisten dan/atau untuk peningkatan prognosis. Dengan pengecualian pada kasus stenosis subtotal pada pembuluh darah utama, gambaran angiografi saja tidak cukup untuk menentukan indikasi IKP, butuh adanya bukti iskemia. Tabel 17 memuat indikasi revaskularisasi pada pasien PJK stabil. Ada dua strategi revaskularisasi jdih.kemkes.go.id - 77 - yang dapat dipilih dalam menangani PJK stabil, yaitu Intervensi Koroner Perkutan (IKP) atau Bedah Pintas Arteri Koroner (BPAK). Tabel 17. Indikasi Revaskularisasi pada PJK Stabil Rekomendasi Kelas Lesi LM dengan stenosis >50% a I Stenosis proksimal LAD >50% a I 2 atau 3 sumbatan pembuluh darah >50%a dengan I penurunan fungsi jantung (LVEF ≤35%) Area iskemia luas (>10%) yang dideteksi oleh tes fungsional, I atau hasil FFR abnormalb Satu satunya arteri koroner yang paten dengan stenosis I >50% a Setiap stenosis koroner yang signifikana dengan adanya I angina berat atau angina ekuivalen yang tidak mendapat

---

## 3. Kriteria & Alur Diagnosis
berdasarkan pada penilaian yang digunakan untuk membuat diagnosis PJK. Stratifikasi risiko kejadian kardiovaskular harus dilakukan pada semua pasien APS menggunakan evaluasi klinis, fungsi ventrikel kiri dengan ekokardiografi saat istirahat, dan pada sebagian besar kasus, penilaian non-invasif iskemia menggunakan anatomi koroner. Walaupun nilai diagnostik uji latih EKG terbatas, adanya depresi segmen ST pada beban latih yang rendah, dikombinasikan dengan adanya gejala saat aktivitas (angina dan atau dispnea), kapasitas latihan yang rendah, ektopik ventrikel, ataupun aritmia dan respon tekanan darah yang abnormal merupakan pertanda adanya risiko jdih.kemkes.go.id - 37 - mortalitas kardiovaskular yang tinggi. Pasien dengan angina tipikal dan disfungsi sistolik dengan pola tersebut mengindikasikan bahwa PJK- nya juga berada pada risiko yang tinggi untuk mengalami mortalitas kardiovaskular. Angiografi koroner invasif untuk stratifikasi risiko hanya diperlukan pada kelompok tertentu dengan tambahan FFR (jika tersedia) jika memang tepat untuk dilakukan. penilaian risiko pada pasien dengan gagal jantung dan disfungsi ventrikel kiri, pasien.

---

## 4. Tatalaksana & Terapi
1. Terapi Farmakologis Lini Pertama (Anti-angina):
   - Beta-blocker kardioselektif (Bisoprolol 2.5-10 mg/hari atau Metoprolol 50-100 mg/hari) dan/atau Calcium Channel Blocker (CCB) dihidropiridin (Amlodipine 5-10 mg/hari) atau non-dihidropiridin (Diltiazem/Verapamil).
   - Nitrat kerja singkat: Isosorbide Dinitrate (ISDN) 5 mg sublingual saat serangan nyeri dada timbul.

2. Pencegahan Kejadian Kardiovaskular (Secondary Prevention):
   - Antiplatelet: Aspirin 75-100 mg/hari (atau Clopidogrel 75 mg/hari bila kontraindikasi/alergi aspirin).
   - Statin intensitas tinggi: Atorvastatin 20-40 mg atau Rosuvastatin 10-20 mg (target LDL < 55 mg/dL).
   - ACE-inhibitor (Ramipril/Captopril) atau ARB bila disertai hipertensi, diabetes melitus, penyakit ginjal kronik, atau disfungsi sistolik ventrikel kiri.

3. Revaskularisasi Miokard (IKP / CABG):
   - Diindikasikan jika gejala persisten trotz terapi medikamentosa optimal atau anatomi koroner berisiko tinggi (stenosis left main > 50% atau LAD proksimal > 70%).

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Fasilitas Kesehatan Rujukan Tingkat Lanjut (FKRTL) / Dokter Spesialis Jantung dan Pembuluh Darah (Sp.JP) bila:
1. Gejala angina menetap atau memburuk meskipun telah mendapat terapi medikamentosa anti-angina optimal.
2. Pasien dengan stratifikasi risiko tinggi kejadian kardiovaskular (uji latih beban positif kuat, LVEF < 50%, atau temuan iskemia luas).
3. Perubahan karakteristik nyeri dada menjadi tidak stabil (kecurigaan Sindroma Koroner Akut).
4. Evaluasi angiografi koroner invasif dan tindakan revaskularisasi miokard (IKP/CABG).

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2023
