---
id: 351
title: "Impetigo Krustosa dan Bulosa"
slug: "impetigo-krustosa-dan-bulosa"
icd_10: "L01.0"
category: "Penyakit Kulit dan Kelamin"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Impetigo Krustosa dan Bulosa (ICD-10: L01.0)

**Kategori Medis**: Penyakit Kulit dan Kelamin  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Impetigo adalah infeksi bakteri piogenik superfisial pada epidermis kulit yang sangat menular, umum terjadi pada anak. Impetigo krustosa (kontagiosa) disebabkan oleh Streptococcus pyogenes dan/atau Staphylococcus aureus; Impetigo bulosa disebabkan oleh Staphylococcus aureus penghasil toksin eksfoliatif.

---

## 2. Gejala & Manifestasi Klinis
- Impetigo krustosa: vesikel/pustul cepat pecah meninggalkan krusta tebal berwarna kuning kecokelatan seperti madu (honey-colored crust) di sekitar hidung dan mulut
- Impetigo bulosa: lepuh bula kendur berisi cairan keruh berdinding tipis di ketiak, dada, atau lipat paha yang pecah meninggalkan erosi berkolaret skuama
- Gatal ringan, anak sering menggaruk dan menularkan ke area lain (autoinokulasi)

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan secara klinis dari karakteristik krusta madu (krustosa) atau bula kendur berkolaret (bulosa). Pemeriksaan mikroskopis pewarnaan Gram kerokan dasar lesi memperlihatkan kokus Gram positif berkelompok atau berantai.

---

## 4. Tatalaksana & Terapi
1. Non-farmakologis: Krusta tebal dilunakkan dan dilepas perlahan dengan kompres terbuka larutan NaCl 0.9% atau povidon iodin encer.
2. Antibiotik Topikal (Lini Pertama untuk lesi terbatas):
   - Mupirosin salep 2% atau Asam Fusidat krim 2% dioleskan 2-3 kali sehari selama 7 hari.
3. Antibiotik Oral Sistemik (bila lesi multipel, luas, atau di asrama/sekolah):
   - Amoksisilin-Klavulanat 25-50 mg/kgBB/hari dibagi 3 dosis selama 7 hari, ATAU
   - Kloksasilin/Dikloksasilin 4 x 250-500 mg oral, ATAU Sefaleksin 25-50 mg/kgBB/hari.
   - Klindamisin 3 x 300 mg oral (pada alergi penisilin).

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke RS / Spesialis Anak/Kulit bila berkembang menjadi Ektima (infeksi menembus dermis membentuk ulkus punch-out), timbul komplikasi Staphylococcal Scalded Skin Syndrome (SSSS), atau pasca-impetigo streptokokus timbul hematuria/edema (Glomerulonefritis Pasca Streptokokus).

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
