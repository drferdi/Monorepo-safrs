---
id: 327
title: "Perdarahan Subkonjungtiva"
slug: "perdarahan-subkonjungtiva"
icd_10: "H11.3"
category: "Penyakit Mata"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Perdarahan Subkonjungtiva (ICD-10: H11.3)

**Kategori Medis**: Penyakit Mata  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Perdarahan subkonjungtiva adalah ekstravasasi darah mendadak ke dalam ruang potensial antara konjungtiva bulbi dan sklera akibat ruptur pembuluh darah mikro konjungtiva, sering dipicu manuver Valsava (batuk, bersin hebat, mengedan), trauma ringan, atau hipertensi.

---

## 2. Gejala & Manifestasi Klinis
- Bercak merah darah homogen berbatas tegas pada bagian putih mata
- Tidak ada rasa nyeri (hanya rasa sedikit mengganjal)
- Tidak ada penurunan tajam penglihatan (visus normal)
- Tidak ada kotoran/sekret mata

---

## 3. Kriteria & Alur Diagnosis
Inspeksi: bercak darah merah terang homogen menutupi sklera, tidak tampak pembuluh darah individu di bawahnya, kornea jernih, bilik mata depan tenang, visus normal. Pengukuran tekanan darah wajib dilakukan.

---

## 4. Tatalaksana & Terapi
1. Reassurance (Menenangkan pasien bahwa kondisi ini jinak dan akan diserap sempurna secara spontan dalam 1-2 minggu tanpa meninggalkan kecacatan).
2. Kompres dingin pada 24 jam pertama, dilanjutkan kompres hangat setelah 48 jam untuk mempercepat absorpsi darah.
3. Air mata buatan tetes mata 3-4 kali sehari bila ada rasa mengganjal.
4. Kontrol dan obati faktor pemicu (hipertensi, batuk kronik, konstipasi mengedan).

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Mata bila perdarahan subkonjungtiva berulang tanpa sebab jelas (perlu skrining koagulopati darah), disertai trauma tumpul bola mata berat (waspada ruptur sklera tersembunyi), atau disertai hifema.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
