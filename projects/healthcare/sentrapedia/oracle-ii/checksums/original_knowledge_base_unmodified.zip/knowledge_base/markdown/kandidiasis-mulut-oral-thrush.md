---
id: 305
title: "Kandidiasis Mulut (Oral Thrush)"
slug: "kandidiasis-mulut-oral-thrush"
icd_10: "B37.0"
category: "Penyakit Infeksi"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Kandidiasis Mulut (Oral Thrush) (ICD-10: B37.0)

**Kategori Medis**: Penyakit Infeksi  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Kandidiasis mulut adalah infeksi jamur oportunistik pada mukosa rongga mulut yang disebabkan oleh spesies Candida (terutama Candida albicans), sering terjadi pada bayi, lansia pengguna gigi tiruan, pengguna kortikosteroid inhalasi, atau status imunokompromais.

---

## 2. Gejala & Manifestasi Klinis
- Bercak putih tebal seperti dadih susu (pseudomembran) pada lidah, palatum, atau pipi bagian dalam
- Bercak mudah dikerok meninggalkan dasar mukosa merah dan berdarah
- Sensasi terbakar di mulut
- Nyeri saat menelan pada bayi menyebabkan malas menyusu

---

## 3. Kriteria & Alur Diagnosis
Diagnosis klinis dengan mengerok pseudomembran putih. Konfirmasi mikroskopis FKTP: sediaan kerokan mukosa dengan larutan KOH 10% memperlihatkan sel ragi bertunas (budding yeast) dan pseudohifa jamur.

---

## 4. Tatalaksana & Terapi
1. Nistatin suspensi oral 100.000 IU/mL: Dewasa dan anak 4 x 1-2 mL (teteskan ke dalam rongga mulut dan kumur perlahan sebelum ditelan) selama 7-14 hari (minimal 48 jam setelah gejala hilang).
2. Alternatif pada dewasa/lansia: Mikonazol gel oral 2% dioleskan 4 kali sehari.
3. Flukonazol oral 1 x 100-200 mg/hari selama 7-14 hari bila infeksi luas atau refrakter.
4. Membersihkan puting susu ibu, dot botol susu bayi, dan merendam gigi tiruan dalam larutan klorheksidin.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Penyakit Dalam / Imunologi bila kandidiasis mulut terjadi pada dewasa muda tanpa riwayat steroid/antibiotik (penapisan infeksi HIV/AIDS atau diabetes melitus tidak terkontrol) atau dicurigai ekstensi kandidiasis esofagus.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
