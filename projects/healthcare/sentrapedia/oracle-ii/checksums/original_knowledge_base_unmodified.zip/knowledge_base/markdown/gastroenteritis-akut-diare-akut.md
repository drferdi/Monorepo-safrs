---
id: 293
title: "Gastroenteritis Akut (Diare Akut)"
slug: "gastroenteritis-akut-diare-akut"
icd_10: "A09"
category: "Penyakit Pencernaan"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Gastroenteritis Akut (Diare Akut) (ICD-10: A09)

**Kategori Medis**: Penyakit Pencernaan  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Gastroenteritis akut adalah inflamasi lambung dan usus halus yang ditandai dengan buang air besar (BAB) cair dengan frekuensi 3 kali atau lebih dalam 24 jam dengan durasi berlangsung kurang dari 14 hari, umumnya disebabkan oleh infeksi virus (Rotavirus, Norovirus) atau bakteri enteropatogen.

---

## 2. Gejala & Manifestasi Klinis
- BAB cair > 3 kali sehari
- Tinja cair tanpa darah
- Mual dan muntah
- Kram perut
- Demam subfebris
- Rasa haus berlebihan
- Lemas
- Penurunan volume urin

---

## 3. Kriteria & Alur Diagnosis
Diagnosis berdasarkan anamnesis frekuensi, volume, dan karakteristik tinja serta penilaian derajat dehidrasi (tanpa dehidrasi, dehidrasi ringan-sedang, dehidrasi berat menurut kriteria WHO). Pemeriksaan fisik: kesadaran, turgor kulit, mata cekung, mukosa bibir kering, CRT, dan tanda vital. Penunjang FKTP: feses rutin (makroskopis dan mikroskopis leukosit/eritrosit/parasit).

---

## 4. Tatalaksana & Terapi
1. Rehidrasi (Pilar Utama):
   - Tanpa dehidrasi: Rencana Terapi A (Oralit 10 mL/kgBB setiap BAB cair).
   - Dehidrasi ringan-sedang: Rencana Terapi B (Oralit 75 mL/kgBB dalam 3-4 jam pertama di faskes, evaluasi ulang).
   - Dehidrasi berat: Rencana Terapi C (Cairan kristaloid Ringer Laktat IV: dewasa 100 mL/kgBB; anak sesuai bagan rehidrasi WHO).
2. Suplementasi Zinc (khusus anak): 10 mg/hari (< 6 bulan) atau 20 mg/hari (>= 6 bulan) selama 10-14 hari.
3. Medikamentosa Simtomatik: Probiotik oral, antipiretik parasetamol 500 mg prn, antispasmodik hiosin butilbromid 10 mg prn bila kram hebat. Hindari antidiare antimotilitas (loperamid) pada disentri atau diare invasif.
4. Antibiotik: Hanya bila terbukti diare invasif/bakteri (Kotrimoksazol atau Ciprofloxacin 2 x 500 mg oral 3-5 hari).

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke RS / IGD bila dehidrasi berat yang gagal dihidrasi intravena di FKTP, diare dengan syok hipovolemik, muntah persisten yang tidak memungkinkan asupan oral, anuria/gagal ginjal akut, atau diare persisten > 14 hari.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
