---
id: 339
title: "Gangguan Somatoform"
slug: "gangguan-somatoform"
icd_10: "F45.9"
category: "Penyakit Jiwa"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Gangguan Somatoform (ICD-10: F45.9)

**Kategori Medis**: Penyakit Jiwa  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Gangguan somatoform adalah kelompok gangguan psikiatrik di mana pasien mengeluhkan keluhan fisik somatik berulang (seperti nyeri dada, sesak, kembung, kesemutan) yang menimbulkan distres berat, namun tidak ditemukan kelainan organik atau patologi medis yang mendasari setelah investigasi menyeluruh.

---

## 2. Gejala & Manifestasi Klinis
- Keluhan fisik multipel yang berpindah-pindah (nyeri kepala, dada, perut, persendian)
- Pencarian konfirmasi medis berulang ke berbagai dokter (doctor shopping)
- Kekhawatiran persisten bahwa dirinya menderita penyakit fisik berbahaya
- Penolakan terhadap penjelasan dokter bahwa hasil pemeriksaan penunjang normal

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan berdasarkan kriteria PPDGJ-III: adanya keluhan fisik multipel minimal 2 tahun yang tidak dapat dijelaskan secara medis, penolakan persisten terhadap bukti medis negatif, dan hendaya fungsi psikososial.

---

## 4. Tatalaksana & Terapi
1. Pendekatan Dokter-Pasien (Kunci Keberhasilan):
   - Validasi penderitaan pasien (jangan mengatakan 'ini hanya ada di pikiran Anda').
   - Jadwalkan kunjungan kontrol teratur dengan satu dokter tetap di FKTP (menghindari doctor shopping).
   - Alihkan fokus dari keluhan fisik ke stresor emosional psikososial.
2. Psikoterapi: CBT dan teknik relaksasi.
3. Farmakologis: SSRI dosis rendah (Sertralin 25-50 mg/hari oral) bila disertai gejala kecemasan atau depresi penyerta. Hindari analgesik narkotik atau polifarmasi somatik.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Kedokteran Jiwa (Sp.KJ) bila kecemasan hipokondriakal sangat parah tidak terkendali, distres fungsi berat, atau timbul depresi berat sekunder dengan ide bunuh diri.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
