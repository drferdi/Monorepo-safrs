---
id: 310
title: "Laringitis Akut"
slug: "laringitis-akut"
icd_10: "J04.0"
category: "Penyakit THT"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Laringitis Akut (ICD-10: J04.0)

**Kategori Medis**: Penyakit THT  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Laringitis akut adalah inflamasi akut pita suara dan mukosa laring yang berlangsung kurang dari 3 minggu, umumnya disebabkan oleh infeksi virus saluran napas atas atau penggunaan suara berlebihan (vocal abuse).

---

## 2. Gejala & Manifestasi Klinis
- Suara serak (hoarseness / disfonia) hingga afonia (hilang suara)
- Sensasi gatal, kering, atau perih di tenggorokan
- Batuk kering menggonggong
- Demam ringan
- Rasa sakit saat berbicara

---

## 3. Kriteria & Alur Diagnosis
Penegakan diagnosis klinis dari riwayat suara serak akut pasca-ISPA atau vocal abuse. Pemeriksaan fisik: faring hiperemis ringan, laringoskopi indirek (bila dapat dilakukan) menunjukkan pita suara edema dan hiperemis.

---

## 4. Tatalaksana & Terapi
1. Istirahat suara total (voice rest) - jangan berbisik karena meningkatkan tegangan pita suara.
2. Inhalasi uap hangat atau humidifikasi udara.
3. Hindari iritan: asap rokok, kafein, alkohol, makanan pedas.
4. Simtomatik: Parasetamol 500 mg 3x/hari bila nyeri/demam.
5. Tidak diindikasikan antibiotik kecuali terbukti infeksi bakteri sekunder.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis THT-KL bila suara serak menetap > 2-3 minggu (evaluasi nodul pita suara, polip, atau keganasan laring), stridor inspiratorik, sesak napas, atau kecurigaan epiglotitis akut.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
