---
id: 290
title: "Retinoblastoma"
slug: "retinoblastoma"
icd_10: "C69.2"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Retinoblastoma (ICD-10: C69.2)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Retinoblastoma (RB) adalah salah satu tumor ganas pada mata yang disebabkan oleh kelainan genetik pada tumor suppressor gene (RB-1) yang berfungsi sebagai pengatur apoptosis. Kelainan ini menyebabkan proliferasi yang tidak terkontrol pada sel retina.

---

## 2. Gejala & Manifestasi Klinis
- dan gejala yang perlu diketahui dari terjadinya hipertermia maligna adalah takikardi yang tidak dapat dijelaskan, peningkatan ETCO rigiditas muskular, spasme maseter dan peningkatan suhu 2, tubuh. Jika terjadi hipertermia maligna, segera hentikan agen volatil, hentikan pembedahan secepat mungkin, hiperventilasi pasien dengan O 100% 10 LPM, berikan dantrolen 2,5 mg/kg iv. Perbaiki 2 asidosis dengan bikarbonat (1-2 mEq/kg) dan perbaiki hiperkalemia dengan insulin 0,1 U/kg + 1 ml/kg D50, CaCl 10 mg/kg atau Ca glukonas 10-15 mg/kg, dinginkan pasien dan hidrasi untuk pemeliharaan urin output. 4. Persiapan dan intraoperasi enukleasi Pada retinoblastoma, diperlukan pengambilan seluruh bagian mata. Saat dilakukan diseksi otot ekstraokular, dapat terjadi refleks okulokardiak. Traksi dari otot ekstrinsik mata atau peningkatan jdih.kemkes.go.id - 47 - tekanan pada bola mata dapat menstimulasi sinus bradikardia dan dapat membaik saat stimulus dihilangkan. Pemberian atropin 20 µg/kg saat induksi dapat mencetuskan takikardia yang dapat mengurangi efek dari refleks okulokardiak. Pemberian atropin juga sangat penting jika propofol digunakan untuk induksi atau pemeliharaan. Obat relaksasi otot juga dapat melemahkan refleks okulokardiak. Atrakurium memiliki durasi efek yang lebih pendek sehingga dapat dipertimbangkan sebagai perelaksasi otot yang tepat. Pengambilan isi dari bola mata merupakan prosedur yang menyakitkan, sehingga pemberian analgesik yang adekuat, termasuk opioid intraoperatif (fentanil) dapat dipertimbangkan. Tabel 7. Medikasi yang diberikan pada tindakan anestesi Medikasi Indikasi Sevofluran Diberikan minimal 1 konsentrasi alveolar Fentanil 1-2 mcg/kg Diberikan sebagai analgesik intra dan Asetaminofen 30-40 mg/kg pasca operasi Rokuronium 0,6 mg/kg Diberikan saat induksi Oksigen Diberikan selama prosedur dengan konsentrasi < 50% untuk mendapatkaan saturasi oksigen 98- 100%. Diberikan 100% pada tindakan kemoterapi intraarterial, dari tusukan di kulit hingga injeksi pertama kemoterapi, kemudian diturunkan Deksametason 0,5 mg/kg Diberikan jika obat kemoterapi yang diberikan 2 jenis atau lebih Oksimetazolin 0,05% satu Diberikan setelah intubasi ke nares semprotan ipsilateral ke tumor Heparin 80 U/kg Diberikan setelah kateter femoral ditempatkan Epinefrin 0,5-1 µg/kg Diberikan jika terjadi penurunan peregangan paru jdih.kemkes.go.id - 48 - Medikasi Indikasi Ondansentron 0,1 mg/kg Diberikan kepada semua pasien Metoklopramid 0,1 mg/kg sebagai agen antiemetik Neostigmin 0,05 mg/kg Diberikan untuk mengembalikan fungsi otot pasca pemberian pelumpuh otot Atropin 0,02 mg/kg untuk Merupakan agen vagolitik yang mengembalikan denyut diberikan untuk menangani jantung jika terjadi komplikasi refleks okulokardiak dan bradikardia okulorespiratorik. Dosis glikopirolat dapat ditingkatkan jika mengunakan deksomedetomidin

---

## 3. Kriteria & Alur Diagnosis
? 1. Riwayat penyakit pasien harus didapat secara lengkap melalui anamnesis, termasuk penyakit mata yang diderita sebelumnya dan riwayat penyakit keluarga serupa. Selain itu harus dilakukan pemeriksaan oftalmologi meliputi visus lengkap sesuai usia, inspeksi, pemeriksaan dengan loupe, lampu celah, dan funduskopi. (Peringkat bukti III, derajat rekomendasi D)

---

## 4. Tatalaksana & Terapi
Tujuan terapi retinoblastoma adalah eradikasi tumor untuk mempertahankan hidup pasien. Jika tujuan tersebut dapat dicapai, tujuan selanjutnya adalah menyelamatkan bola mata dan mempertahankan fungsi penglihatan. Terapi yang digunakan tergantung dari tipe retinoblastoma (intraokular atau ekstraokular) dan keterlibatan bola mata (unilateral atau bilateral). (Peringkat bukti III, derajat rekomendasi D). MENTERI KESEHATAN REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 5. Kriteria Rujukan (FKRTL)
, pencatatan, dan pelaporan kasus. D. Sasaran 1. Seluruh tenaga medis baik dokter subspesialis, dokter spesialis, dan dokter, tenaga perawat serta tenaga kesehatan lainnya, untuk diterapkan di fasilitas pelayanan kesehatan. 2. Penentu kebijakan di lingkungan fasilitas pelayanan kesehatan, institusi pendidikan, serta kelompok profesi terkait. jdih.kemkes.go.id - 8 - BAB II METODOLOGI A. Pertanyaan Klinis Utama

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2022
