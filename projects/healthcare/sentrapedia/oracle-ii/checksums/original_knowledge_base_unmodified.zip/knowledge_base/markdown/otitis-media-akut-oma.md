---
id: 317
title: "Otitis Media Akut (OMA)"
slug: "otitis-media-akut-oma"
icd_10: "H65.0"
category: "Penyakit THT"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Otitis Media Akut (OMA) (ICD-10: H65.0)

**Kategori Medis**: Penyakit THT  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Otitis media akut adalah infeksi bakteri atau virus akut pada rongga telinga tengah yang berlangsung kurang dari 3 minggu, sering didahului oleh ISPA yang memicu disfungsi tuba Eustachius, umum terjadi pada bayi dan balita.

---

## 2. Gejala & Manifestasi Klinis
- Stadium Oklusi: rasa penuh/pekak di telinga, retraksi membran timpani
- Stadium Hiperemis (Presupurasi): otalgia hebat, demam tinggi, membran timpani hiperemis edema
- Stadium Supurasi: nyeri telinga sangat hebat, gelisah, membran timpani menonjol keluar (bulging) dengan eksudat purulen
- Stadium Perforasi: keluar cairan/nanah dari telinga, demam dan nyeri mendadak mereda drastis, ruptur membran timpani
- Stadium Resolusi: sekret mengering, perforasi menutup

---

## 3. Kriteria & Alur Diagnosis
Penegakan diagnosis klinis berdasarkan anamnesis otalgia akut dan demam. Otoskopi: perubahan warna (hiperemis), posisi (bulging atau perforasi dengan pulsasi sekret purulen), dan hilangnya refleks cahaya membran timpani.

---

## 4. Tatalaksana & Terapi
1. Stadium Oklusi: Dekongestan tetes hidung (Efedrin HCl 0.5-1%) untuk membuka tuba Eustachius.
2. Stadium Hiperemis & Supurasi:
   - Antibiotik Lini Pertama: Amoksisilin 3 x 500 mg oral (dewasa) atau 80-90 mg/kgBB/hari (anak) selama 7-10 hari. Alternatif: Amoksisilin-Klavulanat atau Sefuroksim.
   - Analgesik-antipiretik: Parasetamol 10-15 mg/kgBB/kali atau Ibuprofen.
3. Stadium Perforasi: Cuci telinga dengan larutan H2O2 3% selama 3-5 hari + Ofloksasin tetes telinga 0.3% selama 7 hari + antibiotik oral adekuat.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis THT-KL bila pada stadium supurasi membran timpani bulging hebat untuk tindakan miringotomi (parasentesis), terjadi mastoiditis akut (pembengkakan retroaurikular), atau otorea persisten > 2 bulan (berkembang menjadi OMSK).

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
