---
id: 316
title: "Otitis Eksterna"
slug: "otitis-eksterna"
icd_10: "H60.9"
category: "Penyakit THT"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Otitis Eksterna (ICD-10: H60.9)

**Kategori Medis**: Penyakit THT  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Otitis eksterna adalah peradangan atau infeksi pada liang telinga luar (meatus akustikus eksternus) yang dapat bersifat difus (swimmer's ear, sering disebabkan Pseudomonas aeruginosa atau Staphylococcus aureus) atau sirkumskripta (furunkel liang telinga).

---

## 2. Gejala & Manifestasi Klinis
- Nyeri telinga hebat (otalgia) yang bertambah saat daun telinga ditarik atau tragus ditekan (tragus sign positif)
- Liang telinga bengkak dan merah
- Keluar sekret telinga (otorea) serosa atau purulen berbau
- Pendengaran menurun bila liang telinga tertutup edema/kotoran
- Gatal hebat pada liang telinga

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan dari nyeri tekan tragus atau tarikan aurikula yang khas. Otoskopi: liang telinga edema hiperemis difus atau furunkel fokal dengan sekret purulen, membran timpani intak (bila dapat divisualisasi).

---

## 4. Tatalaksana & Terapi
1. Toilet telinga (membersihkan liang telinga dari kotoran/sekret secara hati-hati).
2. Farmakologis Topikal (Lini Utama):
   - Tetes telinga kombinasi antibiotik dan steroid: Neomisin + Polimiksin B + Deksametason atau Ofloksasin tetes telinga 0.3% 3-4 tetes 2-3 kali sehari selama 7 hari.
   - Jika liang telinga sangat bengkak, pasang tampon pita telinga (ear wick) yang dibasahi tetes antibiotik.
3. Analgesik oral: Parasetamol 500 mg 3x/hari atau Ibuprofen 400 mg 3x/hari.
4. Edukasi menjaga liang telinga tetap kering, tidak berenang dan tidak mengorek telinga.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis THT-KL bila terjadi Otitis Eksterna Maligna (nekrotikans) pada pasien lansia/diabetes (nyeri hebat menjalar ke temporal, jaringan granulasi dasar liang telinga, kelumpuhan saraf fasialis) atau furunkel yang memerlukan insisi drainase.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
