---
id: 337
title: "Insomnia Primer"
slug: "insomnia-primer"
icd_10: "F51.0"
category: "Penyakit Jiwa"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Insomnia Primer (ICD-10: F51.0)

**Kategori Medis**: Penyakit Jiwa  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Insomnia primer adalah gangguan tidur yang ditandai dengan kesulitan memulai tidur (sleep onset), mempertahankan tidur (sleep maintenance), atau bangun terlalu dini dan tidak dapat tidur kembali, yang terjadi minimal 3 malam per minggu selama minimal 1 bulan, menimbulkan distres dan gangguan fungsi di siang hari, tanpa disebabkan oleh gangguan medis/psikiatri lain.

---

## 2. Gejala & Manifestasi Klinis
- Sulit tidur meskipun tubuh lelah
- Sering terbangun di malam hari dan sulit tidur kembali
- Bangun terlalu pagi
- Rasa lelah, mengantuk, dan sulit konsentrasi di siang hari
- Kecemasan terkait waktu tidur

---

## 3. Kriteria & Alur Diagnosis
Penegakan diagnosis klinis dari riwayat pola tidur melalui buku harian tidur (sleep diary). Menyingkirkan sleep apnea (mendengkur keras tercekik), sindrom kaki gelisah (restless legs syndrome), dan depresi/ansietas mayor.

---

## 4. Tatalaksana & Terapi
1. Terapi Perilaku Kognitif untuk Insomnia (CBT-I) & Sleep Hygiene (Lini Pertama Pilihan):
   - Jadwal tidur dan bangun yang tetap setiap hari (termasuk akhir pekan).
   - Gunakan tempat tidur HANYA untuk tidur dan hubungan seksual (stimulus control).
   - Hindari layar gadget, kafein, alkohol, dan makan berat 4-6 jam sebelum tidur.
   - Olahraga teratur di pagi/siang hari, bukan menjelang tidur.
2. Farmakologis Jangka Pendek (Hanya bila CBT-I belum efektif, batasi < 2-4 minggu):
   - Non-benzodiazepin (Z-drugs): Zolpidem 5-10 mg oral sebelum tidur.
   - Alternatif sedatif non-adiktif: Amitriptilin 12.5-25 mg oral malam hari bila disertai kecemasan/nyeri kronik.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Kedokteran Jiwa (Sp.KJ) bila insomnia kronik menetap > 3 bulan refrakter terapi primer, dicurigai komorbiditas depresi mayor dengan ide bunuh diri, atau ketergantungan obat hipnotik-sedatif.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
