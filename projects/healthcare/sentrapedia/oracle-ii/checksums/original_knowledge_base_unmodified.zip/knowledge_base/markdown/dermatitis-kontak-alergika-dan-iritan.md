---
id: 341
title: "Dermatitis Kontak Alergika dan Iritan"
slug: "dermatitis-kontak-alergika-dan-iritan"
icd_10: "L23.9"
category: "Penyakit Kulit dan Kelamin"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Dermatitis Kontak Alergika dan Iritan (ICD-10: L23.9)

**Kategori Medis**: Penyakit Kulit dan Kelamin  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Dermatitis kontak adalah reaksi inflamasi kulit yang timbul akibat kontak dengan substansi eksternal. Dermatitis Kontak Iritan (DKI, 80%) diakibatkan oleh kerusakan fisik/kimiawi sawar kulit tanpa sensitisasi imunologis; Dermatitis Kontak Alergika (DKA) merupakan reaksi hipersensitivitas tipe IV (cell-mediated) terhadap alergen spesifik (nikel, lateks, pewarna rambut).

---

## 2. Gejala & Manifestasi Klinis
- DKI: rasa pedih, terbakar, eritema, fisura, kulit kering bersisik setelah kontak dengan deterjen/zat kimia
- DKA: gatal hebat yang dominan, eritema berbatas tegas sesuai bentuk kontak, vesikel, bula, eksudasi
- Lokasi predileksi: tangan, pergelangan tangan (jam tangan), daun telinga (anting imitasi), dahi/leher

---

## 3. Kriteria & Alur Diagnosis
Penegakan diagnosis klinis dari anamnesis riwayat pekerjaan, hobi, dan kontak zat kimia/logam. Pemeriksaan fisik: morfologi lesi sesuai bentuk benda kontak. Konfirmasi DKA: uji tempel (patch test) setelah fase akut sembuh.

---

## 4. Tatalaksana & Terapi
1. Identifikasi dan penghentian kontak total dengan substansi pemicu (penggunaan sarung tangan pelindung).
2. Terapi Topikal:
   - Kompres terbuka larutan NaCl 0.9% pada lesi basah/eksudatif selama 15 menit 3 kali sehari.
   - Kortikosteroid Topikal: Betametason dipropionat 0.05% atau Mometason furoat 0.1% krim dioleskan 1-2 kali sehari selama 1-2 minggu pada lesi kering/papular.
   - Emolien pelembap untuk memulihkan barier kulit.
3. Antihistamin oral bila gatal mengganggu tidur.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Kulit dan Kelamin (Sp.DV) bila lesi luas melibatkan > 20% luas permukaan tubuh, terjadi eritroderma, atau memerlukan patch test untuk identifikasi alergen profesional/industri.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
