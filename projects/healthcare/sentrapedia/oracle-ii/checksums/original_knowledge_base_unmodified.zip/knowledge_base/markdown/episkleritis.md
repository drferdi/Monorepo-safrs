---
id: 330
title: "Episkleritis"
slug: "episkleritis"
icd_10: "H15.1"
category: "Penyakit Mata"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Episkleritis (ICD-10: H15.1)

**Kategori Medis**: Penyakit Mata  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Episkleritis adalah inflamasi jinak akut yang mengenai jaringan episklera vaskular antara konjungtiva dan sklera, bersifat swasirna (self-limiting), sering idiopatik atau berhubungan dengan penyakit autoimun sistemik ringan.

---

## 2. Gejala & Manifestasi Klinis
- Mata merah sektoral (terlokalisasi pada satu kuadran) atau difus
- Rasa pegal atau tidak nyaman ringan pada mata (bukan nyeri hebat)
- Tidak ada penurunan penglihatan (visus normal)
- Tidak ada sekret purulen (mata berair ringan)

---

## 3. Kriteria & Alur Diagnosis
Pemeriksaan fisik: injeksi vaskular episklera berbatas tegas (sektoral), pembuluh darah dapat digerakkan di atas sklera. Tes Fenilefrin 2.5%: teteskan fenilefrin, pembuluh darah episklera akan mengalami vasokonstriksi dan memucat dalam 10-15 menit (membedakan dari skleritis yang TIDAK memucat).

---

## 4. Tatalaksana & Terapi
1. Mayoritas kasus sembuh spontan dalam 1-2 minggu tanpa terapi khusus.
2. Terapi suportif: kompres dingin dan air mata buatan 4 kali sehari.
3. Medikamentosa:
   - OAINS oral: Ibuprofen 3 x 400 mg/hari oral selama 5-7 hari bila ada nyeri pegal.
   - Tetes mata kortikosteroid ringan (Fluorometolon 0.1%) 3-4 kali sehari jangka pendek pada kasus nodular yang mengganggu.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Mata bila nyeri mata sangat hebat yang membangunkan tidur menjalar ke pelipis (kecurigaan skleritis), mata merah tidak memucat dengan fenilefrin, atau episkleritis sering kambuh berulang.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
