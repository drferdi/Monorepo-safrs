---
id: 282
title: "Sindroma Koroner Akut"
slug: "sindroma-koroner-akut"
icd_10: "I20-I24"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Sindroma Koroner Akut (ICD-10: I20-I24)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
SKA merupakan bagian dari spektrum penyakit jantung koroner yang dicirikan oleh berkurangnya secara mendadak aliran darah ke otot jantung (miokard) yang dikarenakan oleh gangguan di pembuluh darah koroner. Sebagian besar SKA adalah manifestasi akut dari plak ateroma pembuluh darah koroner yang pecah. Hal ini berkaitan dengan perubahan komposisi plak dan penipisan lapisan fibrosa yang menutupi plak tersebut sehingga akan diikuti oleh proses agregasi trombosit dan aktivasi jalur koagulasi. Terbentuklah trombus yang kaya trombosit (white thrombus). Trombus ini akan menyumbat lumen pembuluh darah koroner, baik secara total maupun parsial, atau menjadi mikroemboli yang menyumbat pembuluh koroner yang lebih distal. Selain itu terjadi pelepasan zat vasoaktif yang menyebabkan vasokonstriksi sehingga memperberat gangguan aliran darah koroner. Berkurangnya aliran darah koroner menyebabkan iskemia miokardium. Pasokan oksigen yang berhenti selama kurang-lebih 20 menit menyebabkan miokardium mengalami nekrosis (infark miokard). Infark miokard tidak selalu disebabkan oleh oklusi total pembuluh darah koroner. Obstruksi subtotal yang disertai vasokonstriksi yang dinamis dapat menyebabkan terjadinya iskemia dan nekrosis jaringan miokard. Akibat dari iskemia, selain nekrosis, adalah gangguan kontraktilitas miokardium karena proses hibernating dan stunning (setelah iskemia hilang), distritmia dan remodeling ventrikel (perubahan bentuk, ukuran dan fungsi ventrikel). Sebagian pasien SKA tidak mengalami koyak plak seperti diterangkan di atas. Mereka mengalami SKA karena obstruksi dinamis akibat spasme lokal dari arteri koronaria epikardial (Angina Prinzmetal). Penyempitan arteri koronaria, tanpa spasme maupun trombus, dapat diakibatkan oleh progresi plak atau restenosis setelah intervensi koroner perkutan (IKP). Beberapa faktor ekstrinsik, seperti demam, anemia, tirotoksikosis, hipotensi, - 11 - takikardia, dapat menjadi pencetus terjadinya SKA pada pasien yang telah mempunyai plak aterosklerosis.

---

## 2. Gejala & Manifestasi Klinis
- menandakan sistolik atau denyut iskemia yang sudah jantung dengan lama peningkatan beban - Tidak didapatkan - Infark atau prosedur depresi secara klinis invasive dengan komplikasi syok kardiogenik dana tau edema paru. Iskemik persisten setelah

---

## 3. Kriteria & Alur Diagnosis
Pasien dengan kardiomiopati hipertrofik atau penyakit katup jantung (stenosis dan regurgitasi katup aorta) dapat mengeluh nyeri dada disertai perubahan EKG dan peningkatan marka jantung menyerupai yang terjadi pada pasien NSTEMI. Miokarditis dan perikarditis dapat menimbulkan keluhan nyeri dada, perubahan EKG, peningkatan marka jantung, dan gangguan gerak dinding jantung menyerupai NSTEMI. Stroke dapat disertai dengan perubahan EKG, peningkatan marka jantung, dan gangguan gerak dinding jantung. Diagnosis banding non kardiak yang mengancam jiwa dan selalu harus disingkirkan adalah emboli paru dan diseksi aorta. - 55 - Tabel 8. Tingkat peluang SKA segmen ST non elevasi KEMUNGKINAN KEMUNGKINAN KEMUNGKINAN BESAR SEDANG KECIL Salah satu dari: Salah satu dari: Salah satu dari: Anamnesis Nyeri dada atau Nyeri dada atau di Nyeri dada tidak lengan kiri yang lengan kiri khas angina berulang Pria, usia >70 tahun Memounyai riwayat Diabetes mellitus OJK, termasuk inflark miokard Pemeriksaan Regurgitasi mitral, Penyakit vascular Nyeri dada timbul fisik hipotensi, ekstra kardiak setoap dilakukan diaphoresis, edema palpasi paru, atau ronkhi EKG Depresi segmen ST Gelombang Q yang Gelombang T ≥1 mm atau inversi menetap mendatar atau gelombang T yang Depresi segmen ST inversi <1 mm di baru (atau 0,5-1 mm atau inversi sadapan dengan dianggap baru) di gelombang T >1 mm gelombang R yang beberapa sadapan dominan prekordial Marka jantung Kadar troponin I/T Normal Normal atau CKMB meningkat (Dikutip dari Anderson JL, et al. J Am Coll Cardiol 2007;50:e1-157)3. 3. Stratifikasi risiko Beberapa cara stratifikasi risiko telah dikembangkan dan divalidasi untuk SKA. Beberapa stratifikasi risiko yang digunakan adalah Thrombolysis In Myocardial Infarction (TIMI), dan Global Registry of Acute Coronary Events (GRACE), sedangkan Can Rapid risk stratification of Unstable angina patients Suppress ADverse outcomes with Early implementation of the ACC/AHA guidelines (CRUSADE) digunakan untuk menstratifikasi risiko terjadinya perdarahan. Stratifikasi perdarahan penting untuk menentukan pilihan penggunaan antitrombotik. Tujuan stratifikasi risiko adalah untuk - 56 - menentukan strategi penanganan selanjutnya (konservatif atau intervensi segera) bagi seorang dengan NSTEMI. Stratifikasi risiko TIMI ditentukan oleh jumlah skor dari 7 variabel yang masing- masing setara dengan 1 poin. Variabel tersebut antara lain adalah usia ≥65 tahun, ≥3 faktor risiko, stenosis koroner ≥50%, deviasi segmen ST pada EKG, terdapat 2 kali keluhan angina dalam 24 jam yang telah lalu, peningkatan marka jantung, dan penggunaan asipirin dalam 7 hari terakhir. Dari semua variabel yang ada, stenosis koroner ≥50% merupakan variabel yang sangat mungkin tidak terdeteksi. Jumlah skor 0-2: risiko rendah (risiko kejadian kardiovaskular <8,3%); skor 3-4 : risiko menengah (risiko kejadian kardiovaskular <19,9%); dan skor 5-7 : risiko tinggi (risiko kejadian kardiovaskular hingga 41%). Stratifikasi TIMI telah divalidasi untuk prediksi kematian 30 hari dan 1 tahun pada berbagai spektrum SKA termasuk APTS/NSTEMI. Tabel 9. Skor TIMI untuk APTS dan NSTEMI Parameter Nilai Usia > 65 tahun 1 Lebih dari 3 faktor risiko* 1 Angiogram koroner sebelumnya menunjukkan 1 stenosis >50% Penggunaan aspirin dalam 7 hari terakhir 1 Setidaknya 2 episode nyeri saat istirahat dalam 24 1 jam terakhir Deviasi ST > 1 mm saat tiba 1 Peningkatan marka jantung (Troponin) 1 Faktor risiko: hipertensi, DM, merokok, riwayat dalam keluarga, dislipidemia Tabel 10. Stratifikasi risiko berdasarkan skor TIMI Skor TIMI Risiko Risiko Kejadian Kedua 0-2 Rendah <8,3 % 3-4 Menengah <19,9% 5-7 Tinggi ≤41% - 57 - Klasifikasi GRACE (Tabel 11) mencantumkan beberapa variabel yaitu usia, kelas Killip, tekanan darah sistolik, deviasi segmen ST, cardiac arrest saat tiba di ruang gawat darurat, kreatinin serum, marka jantung yang positif dan frekuensi denyut jantung.

---

## 4. Tatalaksana & Terapi
terapi invasive - Ditemukan depresi signifikan secara klinis NYHA kelas I NYHA kelas II NYHA kelas III-IV - Klasifikasi resiko dipilih - Klasifikasi resiko - Klasifikasi resiko bila didapatkan semua sedang dipilih bila tinggi dipilih bila faktor dalam kategori ini pasien tidak dapat didapatkan salah memenuhi satu faktor resiko

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk SEGERA (CITO ambulans berfasilitas monitor EKG dan resusitasi) ke RS dengan fasilitas Pusat Pelayanan Jantung Terpadu / Catheterization Laboratory (Cath Lab) untuk tindakan Primary Percutaneous Coronary Intervention (PCI) dengan target door-to-balloon < 90 menit pada STEMI, atau strategi invasif dini pada NSTEMI/UAP risiko tinggi.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2019
