---
id: 309
title: "Faringitis Akut"
slug: "faringitis-akut"
icd_10: "J02.9"
category: "Penyakit THT"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Faringitis Akut (ICD-10: J02.9)

**Kategori Medis**: Penyakit THT  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Faringitis akut adalah peradangan akut mukosa faring yang dapat disebabkan oleh infeksi virus (Adenovirus, Rhinovirus, Epstein-Barr) atau bakteri (paling sering Streptococcus beta-hemolyticus grup A / GABHS).

---

## 2. Gejala & Manifestasi Klinis
- Nyeri tenggorokan mendadak
- Nyeri saat menelan (odinofagia)
- Demam
- Malaise
- Batuk (lebih sering pada virus)
- Faring hiperemis, edema uvula, eksudat folikular pada dinding posterior faring
- Limfadenopati servikal anterior yang nyeri

---

## 3. Kriteria & Alur Diagnosis
Menggunakan Skor Centor / McIsaac untuk membedakan etiologi bakteri GABHS dari virus:
- Kriteria: Suhu > 38°C (1 poin), Tidak ada batuk (1 poin), Limfadenopati servikal anterior nyeri (1 poin), Eksudat tonsil/faring (1 poin), Usia 3-14 tahun (1 poin).
- Skor 4-5 sangat mencurigakan infeksi Streptococcus grup A dan membutuhkan antibiotik.

---

## 4. Tatalaksana & Terapi
1. Faringitis Viral (Skor Centor 0-2): Terapi simtomatik parasetamol/ibuprofen, kumur air garam hangat atau obat kumur antiseptik, istirahat dan hidrasi cairan cukup.
2. Faringitis Bakterial GABHS (Skor Centor >= 3):
   - Amoksisilin: Dewasa 3 x 500 mg oral atau 1 x 1000 mg selama 10 hari; Anak 50 mg/kgBB/hari dibagi 3 dosis selama 10 hari.
   - Alternatif (alergi penisilin): Eritromisin 4 x 250-500 mg selama 10 hari atau Azitromisin 1 x 500 mg hari 1, 1 x 250 mg hari 2-5.
   - Benzatin Penisilin G: Dosis tunggal 1.2 juta IU IM (dewasa) atau 600.000 IU IM (anak < 27 kg).

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Dokter Spesialis THT-KL bila terdapat komplikasi abses peritonsilar (trismus, deviasi uvula), abses retrofaringeal, stridor atau distres jalan napas, atau tanda demam rematik akut pasca-infeksi.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
