---
id: 183
title: "Kedokteran Jiwa"
slug: "kedokteran-jiwa"
icd_10: "F00-F99"
category: "Penyakit Jiwa"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Kedokteran Jiwa (ICD-10: F00-F99)

**Kategori Medis**: Penyakit Jiwa  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Pelayanan kesehatan jiwa dan tata laksana gangguan psikiatrik klinis (mencakup gangguan psikotik, afektif, ansietas, dan neurokognitif) berdasarkan PNPK Psikiatri untuk memulihkan fungsi psikososial dan menstabilkan neurotransmisi pasien secara komprehensif.

---

## 2. Gejala & Manifestasi Klinis
- Harus disadari sebagai pikiran, bayangan, atau impuls diri sendiri; b. Sedikitnya ada 1 pikiran atau tindakan yang tidak berhasil dilawan, meskipun ada lainnya yang tidak lagi dilawan oleh penderita. c. Pikiran atau kompulsi tersebut bukan merupakan yang memberi kepuasan atau kesenangan (sekedar perasaan lega dari ketegangan atau anxietas, tidak dianggap sebagai kesenangan seperti dimaksud di atas); d. Gagasan, bayangan pikiran atau impuls tersebut harus merupakan pengeluaran pengulangan yang tidak menyenangkan (unpleasantly repetitive).

---

## 3. Kriteria & Alur Diagnosis
Pedoman Penggolongan dan Diagnosis Gangguan Jiwa di Indonesia (PPDGJ) III. Cetakan Pertama. 1993 2) Kaplan dan Sadock. Comprehensive textbook of Psychiatry 7th ed. Lippincott William & Wilkins (2000): 1500-1501. MENTERI KESEHATAN REPUBLIK INDONESIA, ttd NILA FARID MOELOEK

---

## 4. Tatalaksana & Terapi
Tujuan terapi menurunkan atau menghilangkan reaksi kecemasan pasien terhadap trauma yg berkaitan dengan stimulus, terdiri atas: 1) Edukasi tentang reaksi umum terhadap trauma 2) Latihan relaksasi 3) Terapi Kognitif Perilaku 4) Eye Movement Desensitation Reprocessing (EMDR) 5) Prolonged Exposure (PE) 6. Daftar Pustaka 1) Direktorat Jenderal Pelayanan Medik Departemen Kesehatan.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Dokter Spesialis Kedokteran Jiwa (Sp.KJ) / Psikiater atau RS Jiwa bila terdapat gaduh gelisah motorik, risiko tinggi bunuh diri/menyakiti orang lain, psikotik refrakter, atau komorbiditas napza berat.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2015
