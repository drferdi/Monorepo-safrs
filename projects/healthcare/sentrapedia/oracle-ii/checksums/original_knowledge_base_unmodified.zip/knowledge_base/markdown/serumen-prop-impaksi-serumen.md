---
id: 318
title: "Serumen Prop (Impaksi Serumen)"
slug: "serumen-prop-impaksi-serumen"
icd_10: "H61.2"
category: "Penyakit THT"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Serumen Prop (Impaksi Serumen) (ICD-10: H61.2)

**Kategori Medis**: Penyakit THT  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Serumen prop adalah penumpukan dan pemadatan massa serumen (kotoran telinga) di liang telinga yang menyumbat kanalis akustikus eksternus, sering diperburuk oleh kebiasaan membersihkan telinga menggunakan cotton bud.

---

## 2. Gejala & Manifestasi Klinis
- Penurunan pendengaran konduktif
- Telinga terasa tersumbat/penuh (terutama setelah kemasukan air/mandi)
- Tinnitus (berdenging)
- Rasa gatal atau nyeri tumpul di liang telinga

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan dari pemeriksaan otoskopi liang telinga: terlihat gumpalan massa serumen berwarna kuning kecokelatan hingga hitam pekat yang menyumbat seluruh atau sebagian lumen liang telinga.

---

## 4. Tatalaksana & Terapi
1. Evakuasi Serumen:
   - Serumen lunak: dikeluarkan langsung dengan sendok serumen (cerumen hook) atau kuretase hati-hati.
   - Serumen keras padat: tetesi pelunak serumen (Karbogliserin / Gliserin 10% atau tetes telinga Natrium Dokusat 0.5%) 3 x 2-3 tetes sehari selama 3-5 hari sebelum evakuasi.
   - Irigasi liang telinga dengan air hangat suam-suam kuku (suhu tubuh ~37°C) menggunakan spuit irigasi ke arah posterosuperior liang telinga (KONTRAINDIKASI irigasi bila ada riwayat perforasi membran timpani).

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis THT-KL bila serumen sangat keras melekat erat pada dinding kanalis yang gagal dievakuasi, pasien tidak kooperatif, atau dicurigai perforasi membran timpani bersamaan.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
