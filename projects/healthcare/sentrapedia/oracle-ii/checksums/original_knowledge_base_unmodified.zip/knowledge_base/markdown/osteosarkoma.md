---
id: 280
title: "Osteosarkoma"
slug: "osteosarkoma"
icd_10: "C40-C41"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Osteosarkoma (ICD-10: C40-C41)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Osteosarkoma adalah keganasan tulang primer tersering pada anak dan dewasa muda, berasal dari sel stroma mesenkim primitif yang memproduksi matriks tulang imatur (osteoid), dengan predileksi terbanyak pada metafisis tulang panjang di sekitar sendi lutut.

---

## 2. Gejala & Manifestasi Klinis
- : a 1. Berkurangnya kekuatan otot s 2. Fatigue 3. Anoreksia a 4. Indeks massa bebas lemak rendah r 5. Laboratorium abnormal: a. Peningkatan petanda inflamasi(IL-6 >4 pg/dL, CRP >5 k mg/L ) a b. Anemia (Hb < 12 g/dL) c. Hipoalbuminemia (<3,2 g/dL) n kriteria diagnosis tersebut, dapat dijelaskan beberapa hal berikut - 28 - ini : 1) Fatigue diartikan sebagai kelelahan fisik ataupun mental dan ketidakmampuan melakukan aktivitas fisik dengan intensitas dan performase sebaik sebelumnya. 2) Anoreksia diartikan sebagai asupan makanan yang kurang baik, ditunjukkan dengan asupan energi kurang dari 20 kkal/kg BB/hari atau kurang dari 70% dari asupan biasanya atau hilangnya selera makan pasien. 3) Indeks massa bebas lemak rendah menunjukkan penurunan massa otot, diketahui dari : a) Hasil pengukuran lingkar lengan atas (LLA) kurang dari persentil 10 menurut umur dan jenis kelamin, atau b) Bila memungkinkan, dilakukan pengukuran indeks otot skeletal dengan dual-energy x-ray absorptiometry 2 (DEXA), diperoleh hasil pada laki-laki <7,25 kg/m dan 2 perempuan <5,45 kg/m . 3. Tata laksana nutrisi umum Sindrom kakeksia membutuhkan tata laksana multi-dimensi yang melibatkan pemberian nutrisi optimal, farmakologi, dan aktifitas fisik. Pemberian nutrisi optimal pada pasien kakeksia perlu dilakukan secara individual sesuai dengan kondisi pasien. a. Kebutuhan nutrisi umum: 1) Kebutuhan energi Idealnya, perhitungan kebutuhan energi pada pasien kanker ditentukan dengan kalori metri indirek. Namun, apabila tidak tersedia, penentuan kebutuhan energi pada pasien kanker dapat dilakukan dengan formula standar, misalnya rumus Harris Benedict yang ditambahkan dengan faktor stres dan aktivitas,

---

## 3. Kriteria & Alur Diagnosis
Algoritme diagnosis dan tata laksana MENTERI KESEHATAN REPUBLIK INDONESIA, ttd NILA FARID MOELOEK

---

## 4. Tatalaksana & Terapi
Penyintas kanker perlu mendapat edukasi dan terapi gizi serta preskripsi gizi. Para penyintas disarankan memiliki BB ideal dan menerapkan pola makan yang sehat, tinggi buah, sayur dan biji-bijian, serta rendah lemak, daging merah, dan alkohol. Para penyintas kanker juga dianjurkan untuk melakukan aktivitas fisik sesuai kemampuan masing-masing. Rekomendasi tingkat A • Penyintas kanker sebaiknya memiliki BB ideal dan menerapkan pola makan yang sehat, tinggi buah, sayur, dan biji-bijian, serta rendah lemak, daging merah, dan alkohol. • Direkomendasikan bagi para penyintas kanker untuk terus melakukan aktivitas fisik sesuai kemampuan secara teratur dan menghindari sedentari - 39 -

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk CITO ke Pusat Kanker Terpadu / Divisi Onkologi Ortopedi RS Rujukan Tipe A untuk konfirmasi biopsi terbuka, staging metastatik, kemoterapi neoadjuvan multimodalitas, dan limb salvage surgery.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2019
