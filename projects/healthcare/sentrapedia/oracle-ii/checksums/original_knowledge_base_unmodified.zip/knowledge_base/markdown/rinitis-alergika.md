---
id: 313
title: "Rinitis Alergika"
slug: "rinitis-alergika"
icd_10: "J30.4"
category: "Penyakit THT"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Rinitis Alergika (ICD-10: J30.4)

**Kategori Medis**: Penyakit THT  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Rinitis alergika adalah kelainan inflamasi mukosa hidung yang diperantarai oleh reaksi hipersensitivitas tipe I (IgE-mediated) setelah paparan alergen inhalan (tungau debu rumah, serbuk sari, bulu hewan peliharaan).

---

## 2. Gejala & Manifestasi Klinis
- Bersin-bersin berulang (paroksismal > 5 kali berurutan)
- Rinorea cair encer bening
- Hidung tersumbat
- Gatal pada hidung, palatum, dan mata
- Allergic shiners (lingkaran hitam bawah mata)
- Allergic salute dan allergic crease (garis horizontal dorsum hidung)

---

## 3. Kriteria & Alur Diagnosis
Anamnesis riwayat atopi pribadi atau keluarga. Pemeriksaan rinoskopi anterior: mukosa konka inferior edema, basah, berwarna pucat atau kebiruan (livid) dengan sekret serosa jernih berlimpah.

---

## 4. Tatalaksana & Terapi
1. Penghindaran alergen pencetus (pencegahan primer terpenting: cuci seprai air panas, bersihkan AC, kurangi karpet/boneka).
2. Farmakologis Lini Pertama:
   - Antihistamin Oral Generasi ke-2 (Non-sedatif): Setirizin 1 x 10 mg/hari, Loratadin 1 x 10 mg/hari, atau Feksofenadin 1 x 120-180 mg/hari.
   - Kortikosteroid Intranasal (Paling efektif untuk hidung tersumbat): Flutikason furoat/propionat atau Mometason furoat semprot hidung 1-2 semprotan per lubang hidung 1 kali sehari.
   - Cuci hidung dengan cairan NaCl fisiologis 0.9% 1-2 kali sehari.
   - Dekongestan oral pseudoefedrin maksimal 3-5 hari bila sumbatan sangat berat.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis THT-KL bila terdapat deviasi septum berat, polip hidung, rinosinusitis kronik komorbiditas, atau tidak responsif terhadap kortikosteroid topikal dan antihistamin optimal setelah 4 minggu.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
