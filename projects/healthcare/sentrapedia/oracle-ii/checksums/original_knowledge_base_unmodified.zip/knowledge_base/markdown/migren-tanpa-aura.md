---
id: 334
title: "Migren Tanpa Aura"
slug: "migren-tanpa-aura"
icd_10: "G43.0"
category: "Penyakit Saraf"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Migren Tanpa Aura (ICD-10: G43.0)

**Kategori Medis**: Penyakit Saraf  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Migren tanpa aura adalah nyeri kepala primer neurovaskular berulang dengan serangan berdurasi 4 hingga 72 jam, khas unilateral, berdenyut, intensitas sedang-berat, diperberat oleh aktivitas fisik rutin, dan disertai mual, fotofobia, serta fonofobia.

---

## 2. Gejala & Manifestasi Klinis
- Nyeri kepala unilateral berdenyut (pulsating)
- Intensitas sedang hingga berat (mengganggu aktivitas)
- Diperberat oleh aktivitas fisik rutin (berjalan atau naik tangga)
- Mual dan/atau muntah
- Fotofobia (silau cahaya) dan fonofobia (sensitif suara bising)
- Pencetus: kurang tidur, stres, telat makan, keju/cokelat, menstruasi

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan berdasarkan kriteria ICHD-3: minimal 5 episode serangan yang memenuhi kriteria durasi 4-72 jam, memiliki minimal 2 karakteristik (unilateral, berdenyut, intensitas sedang-berat, diperberat aktivitas rutin), dan minimal 1 gejala penyerta (mual/muntah atau fotofobia + fonofobia).

---

## 4. Tatalaksana & Terapi
1. Terapi Abortif Akut (Diberikan seawal mungkin saat serangan):
   - Lini Pertama (Serangan Ringan-Sedang): Parasetamol 1000 mg oral, Ibuprofen 400-800 mg oral, atau Asam Mefenamat 500 mg.
   - Lini Kedua (Serangan Sedang-Berat): Triptan (Sumatriptan 50-100 mg oral) ATAU Ergotamin tartrat 1 mg + Kafein 100 mg oral saat awal serangan (maks 6 tablet per serangan).
   - Antiemetik: Domperidone 10 mg oral atau Metoklopramid 10 mg oral bila mual dominan.
2. Terapi Preventif (bila serangan >= 4 hari/bulan atau disabilitas berat):
   - Propranolol 2 x 20-40 mg/hari, Topiramat 25-50 mg/hari, atau Flunarizin 5-10 mg/hari malam hari.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Saraf bila status migrainosus (serangan berlangsung > 72 jam tanpa jeda), dicurigai migren dengan komplikasi neurologis fokal (migren basilar, migren hemiplegik), atau refrakter terhadap terapi profilaksis.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
