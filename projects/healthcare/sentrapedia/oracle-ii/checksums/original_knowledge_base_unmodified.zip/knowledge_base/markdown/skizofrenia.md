---
id: 272
title: "Skizofrenia"
slug: "skizofrenia"
icd_10: "F20"
category: "Penyakit Jiwa"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Skizofrenia (ICD-10: F20)

**Kategori Medis**: Penyakit Jiwa  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
definisi skizofrenia yang resisten terhadap pengobatan pada uji klinis dan dalam praktik. Rekomendasi dari The Treatment Response and Resistance in Psychosis (TRRIP) yaitu gejala yang menetap setidaknya berdurasi 12 minggu, gejala setidaknya N memiliki tingkat keparahan sedang, dan terkait dengan A setidaknya gangguan fungsional sedang sebagaimana ditentukan T oleh skala penilaian yang divalidasi (misalnya, PANSS, BPRS, A atau SANS dan SAPS untuk gejala dan skor <60 pada SOFAS H sebagai ukuran fungsi). Jika percobaan pengobatan prospektif E minimal 6 minggu pada dosis adekuat tidak menyebabkan pengurangan gejala lebih dari S20%, ini memberikan bukti tambahan tentang resistensi pEengobatan. Harus dicatat apakah gejala persisten termasukK gejala positif, negatif, atau kognitif karena respons terhadap domain gejala ini mungkin berbeda. N Dalam hal pengobatan yang adekuat, TRRIP merekomendasikan A bahwa harus dilakukan setidaknya uji coba dengan dua obat I antipsikotik yang berbeda, setidaknya 6 minggu pada rentang R dosis terapeutik obat untuk masing-masing dan dengan E kepatuhan setidaknya 80% dari dosis yang ditentukan. Dosis T terapeutik obat didefinisikan sebagai titik tengah (midpoint) N rentang target untuk pengobatan akut skizofrenia menurut label E produk produsen atau setara dengan 600 mg klorpromazin per M hari. Kriteria konsensus mencakup setidaknya satu dari berikut: E pemeriksaan level darah antipsikotik untuk menilai kepatuhan, K perolehan informasi kepatuhan setidaknya dari 2 sumber (misal hitung tablet, kardeks pengobatan, laporan pasien/pelaku rawat), serta perolehan informasi tentang respon pengobatan sebelumnya dari laporan pasien/pelaku rawat dan sumber lainnya. Untuk tujuan klinis, definisi umumnya adalah bahwa gejala pasien tidak menunjukkan respons atau berespons parsial dan suboptimal terhadap uji coba dua obat antipsikotik minimal 6 minggu masing-masing dengan dosis obat yang adekuat, dan penggunaan obat dari kelas yang berbeda (misal, antipsikotik jdih.kemkes.go.id - 192 - generasi kedua vs. antipsikotik generasi pertama). Jika tidak ada perbaikan yang signifikan setelah beberapa minggu pengobatan (misalnya,<20% perbaikan gejala), kemungkinan terjadinya perubahan substansial (misalnya,>50% perbaikan gejala) adalah kecil dan uji coba obat dengan waktu lebih lama mungkin tidak diperlukan. Harus dicatat bahwa uji coba pengobatan tidak dapat dianggap adekuat jika durasi atau dosis obat menjadi terpotong N dikarenakan tolerabilitas yang buruk atau jika dibatasi oleh A kepatuhan yang buruk. Beberapa ahli menyarankan uji coba T antipsikotik LAI sebelum menentukan pasien mengalami A resistensi pengobatan. H a) Inisiasi Pengobatan Dengan Klozapin E Setelah pasien diidentifikasi sebagai skizofrenia yang resisten terhadap pengobataSn, dokter harus melibatkan pasien dalam diskusi Etentang pengobatan klozapin. Percobaan klozapin teKpat pada individu yang menunjukkan respons terhadap pengobatan (yaitu setidaknya 20% N pengurangan gejala) namun masih memiliki gejala atau A gangguan fungsi yang signifikan. Klozapin sering kurang I digunakan (underuse) dan banyak pasien memperoleh R manfaat jika pengobatan ini dipertimbangkan lebih awal. E Diskusi tentang klozapin harus menekankan prinsip T pengambilan keputusan bersama; melibatkan anggota N keluarga atau orang lain yang mendukung pengobatan E dalam diskusi seringkali bermanfaat. Dari sudut pandang M pasien, mereka menghargai upaya untuk membantu mereka E untuk dapat berpikir lebih jernih dan menghentikan K halusinasi atau waham, saat memutuskan tentang perubahan pengobatan. Sebagian besar pasien yang menerima klozapin memandangnya secara positif. Misalnya, satu survei besar terhadap individu dengan skizofrenia atau gangguan skizoafektif yang menggunakan obat antipsikotik menemukan bahwa sebagian besar dari mereka yang menggunakan klozapin mematuhi pengobatan dan menganggapnya bermanfaat, sedangkan hanya sekitar 5% yang merasa tidak membantu. Sebaliknya, sebagian besar obat antipsikotik lainnya dipandang kurang positif. Meski jdih.kemkes.go.id - 193 - demikian, penting untuk tetap mengidentifikasi kekhawatiran pasien tentang klozapin dan mengatasinya sejauh mungkin. Misalnya, pasien mungkin mengungkapkan kekhawatiran tentang keharusan melakukan pemeriksaan darah untuk pemantauan atau hambatan logistik seperti akses ke transportasi. Mereka mungkin bersedia untuk mempertimbangkan klozapin jika N hambatan logistik dapat diatasi atau jika diberi informasi A bahwa persyaratan pemantauan darah akan menjadi lebih T jarang dari waktu ke waktu. Kekhawatiran tentang efek A samping lain, seperti penambahan berat badan atau H mengantuk, juga dapat menyebabkan keengganan untuk E beralih ke klozapin. Akan sangat membantu untuk melakukan diskusi terbuka tSentang efek samping ini dan rencana yang jelas untuEk pemantauan saat pengobatan berlangsung. KelompKok dukungan sebaya (peer-support group) yang memilik i pengalaman keseharian tentang cara N mengatasi efek samping dapat membantu pasien A membangun strategi koping yang baik tentang efek samping. I Dokter mungkin juga memiliki kekhawatiran tentang R klozapin yang dapat menjadi penghalang pengobatan. E Misalnya, banyak dokter memiliki pengalaman terbatas T dalam menggunakan klozapin dan terkadang N mengungkapkan kekhawatiran tentang beban dokumen E pemantauan darah, kepatuhan pasien dengan pemantauan, M dan efek samping. Banyak dokter overestimasi kemungkinan

---

## 2. Gejala & Manifestasi Klinis
- , identifikasi gejala N negatif sekunder akibat depresi, gejala positif, dan efek samping obat. A Pengobatan mengikuti pedoman yang tersedia untuk masing-masing I penyebab. R E C. Intervensi Psikososial T

---

## 3. Kriteria & Alur Diagnosis
orang dengan skizofrenia yang memiliki masalah diagnosis atau A pengobatan. H E MSENTERI KESEHATAN EREPUBLIK INDONESIA, K ttd. N A BUDI G. SADIKIN I R E T N E M E K jdih.kemkes.go.id

---

## 4. Tatalaksana & Terapi
. 10. Pemberian TKL di fase akut (TKL-indeks) dikombinasikan dengan obat antipsikotik ketika respon klinis yang cepat merupakan prioritas yang mendesak. 11. Pasien skizofrenia dengan halusinasi auditorik resisten pengobatan N dan gejala negatif menetap diberikan tambahan terapi rTMS. A

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke FKRTL / Dokter Spesialis Kedokteran Jiwa (Sp.KJ) apabila:
1. Perilaku gaduh gelisah motorik, agresivitas, atau risiko mencederai diri sendiri/orang lain (kegawatdaruratan psikiatri).
2. Episode pertama psikotik untuk konfirmasi diagnosis komprehensif.
3. Tidak ada respons klinis memadai setelah 6-8 minggu terapi antipsikotik dosis optimal atau timbul efek samping ekstrapiramidal berat (distonia akut, diskinesia tardif, sindrom neuroleptik maligna).
4. Pasien dengan komorbiditas penyalahgunaan napza atau penyakit medis umum berat.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK UNKNOWN
