---
id: 182
title: "Penyakit Hirschprung"
slug: "penyakit-hirschprung"
icd_10: "Q43.1"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Penyakit Hirschprung (ICD-10: Q43.1)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Penyakit Hirschsprung adalah suatu kelainan bawaan berupa tidak adanya ganglion pada usus besar, mulai dari sfingter ani interna ke arah proksimal, termasuk rektum, dengan gejala klinis berupa gangguan pasase usus. Embriologi dan Etiologi Tabung neural terbentuk dan bermigrasi ke arah craniocaudal dan mencapai rektum pada minggu ke-12. Plexus mientericus aurbach terbentuk lebih dahulu diikuti dengan terbentuknya plexus submukosa meissner’s. Beberapa kondisi abnormal pada proses penurunan neural tube menuju distal rektum diantaranya terjadi perubahan matrix protein ekstraseluler, interaksi intra sel yang abnormal (tidak adanya molekul adhesi sel neural) dan tidak adanya faktor neurotropik menyebabkan terjadinya kondisi aganglionik kolon.

---

## 2. Gejala & Manifestasi Klinis
- Penyangkalan PNPK Penyakit Hirschsprung ini memang membicarakan semua permasalahan dalam penanganan penyakit hirschsprung mulai dari prevensi sampai terapi, tetapi tidak dimaksudkan sebagai suatu buku teks. PNPK Penyakit Hirschsprung ini juga hanya membicarakan hal-hal umum dari semua permasalahan penanganan penyakit hirschsprung, untuk mengetahui lebih dalam dan detail dapat ditelusuri melalui daftar rujukan yang ada. C. Tujuan Umum dan Tujuan Khusus 1. Tujuan Umum Tenaga medis mampu memahami dan mengerti tentang patogenesis, diagnosis, penatalaksanaan penyakit hirschsprung sesuai dengan kompetensinya. 2. Tujuan Khusus a. Mampu menjelaskan patologi dan patogenesis penyakit hirschsprung.

---

## 3. Kriteria & Alur Diagnosis
Clinical Impacts of Delayed Diagnosis of Hirschsprung Disease in Newborn Infants.Pediatrics and Neonatology, 53(2):133-137. Lee, S., 2009, Hirschsprung disease, pediatric surgery, department of surgery, Kaiser permente, Los Angles medical center. http://emedicine.medscape.com/article/178493, Accessed: May 2014. More, K, Rao, S., McMichael, J., Minutillo, C. 2014Growth and Developmental Outcomes of Infants with Hirschsprung Disease Presenting in the Neonatal Period: A Retrospective Study. Journal of Pediatrics,165(1):73-77. Mosley JG, Shoaib A., 2000, Operative versus conservative management of adhesional intestinal obstruction. Mowat D. R. Et al, 1998, Hirschsprung disease, microcephaly, mental retardation, and characteristic facial features: delineation of a new syndrome and identification of a locus at chromosome 2q22-q23. Müller-Lissner SA1, Kamm MA, Scarpignato C, Wald A., 2005, Myths and Misconceptions about Chronic Constipation. American Journal of Gastroenterology, 100(1):232-42. Murthi GV, Raine PA (2003) Preoperative enterocolitis is associated with poorer long-term bowel function after Soave-Boley endorectal pull-through for Hirschsprung’s disease. J Pediatric Surg 2003 38:69–72. Neville,H.L.,2014,PediatricHirschsprungDisease.http://emedicine.medscape.co m/article/929733-overview Accessed: July 3, 2014. O’Donovan A. N. Et al, 1996, Diagnosis of hirschsprung’s disease. Osifo, O.D., Okolo, J.C.,2009, Neonatal intestinal obstruction in Benin, Nigeria. African Journal of Paediatric Surgery, 6(2):98-101. Prato A. P. Et al, 2013, A prospective observational study of associated anomalies in hirschsprung’s disease. Parisi, M.A., 2002, Hirschsprung Disease Overview. In: Pagon RA, Adam MP, Ardinger HH, Bird TD, Dolan CR, Fong CT, Smith RJH, Stephens K, editors. GeneReviews [Internet]. Seattle (WA): University of Washington. Accessed: July 3, 2014. -30- Puri, P., Höllwarth, M.E, 2006, Pediatric Surgery, Springer-Verlag Berlin Heidelberg.p275-288. Puri, P., and Shinkai, T., 2004, Pathogenesis of Hirschsprung's disease and its variants: recent progress.Seminars in Pediatric Surgery, 13(1):18- 24. Reyna, T.M. 1994. Familial Hirschsprung's disease: study of a Texas cohort.Pediatrics, 94(3):347-349. Robert, M., Arensman, Daniel, A., 2000, Pediatric Surgery.Northwestern University Chicago, Illinois, U.S.A. Rochadi.2012. Outcome comparison among posterior sagittal neurectomy for Hirschsprung’s disease and endorectal pull-through.PhD (dissertation). Yogyakarta: Universitas Gadjah Mada. Ryan ET, Ecker JL, Christakis NA, Folkman J., 1992, Hischsprung's disease: Associated abnormalities and demography. Journal of Pediatric Surgery, 27(1):76-81. Sagar PM1, MacFie J, Sedman P, May J, Mancey-Jones B, Johnstone D. 1995. Intestinal obstruction promotes gut translocation of bacteria. Diseases of the Colon and Rectum, 38(6):640-644. S. B. Williams, J. Greenspon, H. A. Young, B. A. Orkin, 2005, Small bowel obstruction: conservative vs. Surgical management. Sauvat, F., 2007, Diagnosis of Constipation in Children, Vol: 65(2):63-71 Sharif K1, Beath SV, Kelly DA, McKiernan P, van Mourik I, Mirza D,et al., 2003, New Perspective for the Management of Near-Total or Total Intestinal Aganglionosis in Infants.Journal of Pediatric Surgery, 38(1):25-28. Srivastava P., Upadhyaya V., Gangopadhyaya A., Hasan Z., Upadhyaya A., Kumar V., 2013, Comparison of two techniques for single-stage treatment of hirschprung disease in neonates. Swenson, O.,2002, Hirschsprung’s Disease: A Review. Pediatrics, 109(5):914- 918. Taha MOA, Mohamed OA, Abdala AAE, 2014, Hirschsprung disease: Factor Affecting the outcome at the National Ribat University Hospital, Khartoum, Sudan 2007-2011. Sudan JMS, 9(1):27-30. Teitelbaum DH, Cilley RE, Sherman NJ, Bliss D, Uitvlugt ND, Renaud EJ,et al. 2000. A decade experience withthe primary pull-through for Hirschsprung disease in thenewborn period: A multi-center analysis of outcomes. Annals of Surgery, 232(3):372-380. -31- Teitelbaum, D.H., Qualman, S.J., Caniano, D.A. 1988. Hirschsprung's disease Identification of risk factor for enterocolitis. Annals of Surgery, 207(3):240-244. Thapar, N., 2009, New frontiers in the treatment of Hirschsprung disease. Journal of Pediatric Gastroenterology and Nutrition, 48 Suppl 2:S92-4. Tobias N, Mason D, Lutkenhoff M, Stoops M, Ferguson D., 2008 Management Principles of Organic Causes of Childhood Constipation. Journal of Pediatric Health Care, 22(1):12-23. Tran VQ, Lam KT, Truong DQ, dkk. 2016, Diagnostic value of rectal suction biopsies using calretinin immunohistochemical staining in Hirschsprung’s disease. 51:2005-2009 Vijay K, Anindya C, Bhanu P, Mohan M, Rao PL.2005, Adhesive Small Bowel Obstruction (ASBO) in Children–Role of Conservative Management. Medical Journalof Malaysia, 60(1):81-84. Wartiovaara, K., Salo, M., Sariola, H., 1998, Hirschsprung 's disease genes and thedevelopment of the enteric nervous system. AnnMed 30:66-74. Yadav L, Kini U,Das K, Mohanty S, Puttegowda D. 2014, Calretinin immunohistochemistry versus improvised rapid acetylcholinesterase histochemistry in the evaluation of colorectal biopsies for Hirschsprung’s Disease. Indian Journal of Pathology and Microbiology, 57(3):369-375 Ziad F, Katchy KC, Al Ramadan S, Alexander S, Kumar S., 2006, Clinicopathological features in 102 cases of Hirschsprung disease,Annals ofSaudiMedicine, 26(3):200-204. MENTERI KESEHATAN REPUBLIK INDONESIA, ttd NILA FARID MOELOEK

---

## 4. Tatalaksana & Terapi
Level I : Metaanalisis dari Randomized Clinical Trial (RCT)); penelitian RCT Level II : Metaanalisis dari kohort; penilitian kohort Level III : Metanalisis kasus kontrol, penelitian kasus kontrol Level IV : Serial kasus, laporan kasus Level V : Opini/pengalaman ahli tanpa telaah kritis

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk segera ke Dokter Spesialis Bedah Anak di RS rujukan untuk evaluasi dekompresi rektal, biopsi hisap rektal konfirmasi aganglionosis, dan tindakan pembedahan definitif (pull-through procedure).

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2017
