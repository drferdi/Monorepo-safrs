---
id: 350
title: "Miliaria (Biang Keringat)"
slug: "miliaria-biang-keringat"
icd_10: "L74.3"
category: "Penyakit Kulit dan Kelamin"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Miliaria (Biang Keringat) (ICD-10: L74.3)

**Kategori Medis**: Penyakit Kulit dan Kelamin  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Miliaria (keringat buntet / biang keringat) adalah kelainan kulit yang timbul akibat retensi dan sumbatan saluran kelenjar keringat ekrin di lingkungan panas dan lembap. Tipe kristalina: sumbatan di stratum korneum; Tipe rubra: sumbatan di epidermis tengah dengan inflamasi.

---

## 2. Gejala & Manifestasi Klinis
- Miliaria kristalina: vesikel jernih kecil superfisial seperti tetesan embun tanpa eritema, tidak gatal, mudah pecah
- Miliaria rubra: papul dan vesikel merah kecil gatal menusuk dan pedih pada area tertutup pakaian/lipatan tubuh
- Banyak berkeringat
- Umum pada bayi, balita, atau orang yang tirah baring lama

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan dari inspeksi klinis lesi papulovesikel mikro di area oklusi keringat (leher, dada, punggung, lipatan ketiak/paha) pada cuaca panas lembap.

---

## 4. Tatalaksana & Terapi
1. Modifikasi Lingkungan (Pilar Utama Penanganan):
   - Menjaga sirkulasi udara sejuk dan ventilasi baik (gunakan AC/kipas angin).
   - Memakai pakaian tipis, longgar, menyerap keringat berbahan katun.
   - Mandi air dingin dan segera keringkan tubuh.
2. Farmakologis Topikal:
   - Bedak kocok kalamin (Caladine) atau bedak salisil 1-2% dioleskan pada area lesi.
   - Krim Hidrokortison 1% tipis jangka pendek (2-3 hari) bila miliaria rubra sangat meradang dan gatal.
   - Antihistamin oral bila gatal mengganggu tidur bayi/anak.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Kulit bila timbul komplikasi infeksi bakteri sekunder luas (miliaria pustulosa / impetiginisasi) yang membutuhkan antibiotik sistemik atau tidak membaik dengan tata laksana primer.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
