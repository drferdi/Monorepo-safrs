---
id: 269
title: "Osteoartritis"
slug: "osteoartritis"
icd_10: "M15-M19"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Osteoartritis (ICD-10: M15-M19)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
A Osteoartritis (OA) adalah penyakit degeneratif kronis atau H jangka panjang dengan etiologi multifaktorial yang ditandai dengan E hilangnya tulang rawan artikular, hipertrofi tulang pada margin, sklerosis subkondral dan berbagai peSrubahan biokimia dan morfologi pada membran sinovial daEn kapsul sendi. Perubahan patologis pada tahap akhir osteKoartritis termasuk pelunakan, ulserasi, dan disintegrasi fokal da ri kartilago artikular; peradangan N sinovial juga dapat terjadi. Gejala klinis yang khas adalah rasa A sakit, terutama setelah aktivitas dan beban berat yang I berkepanjangan, sedangkan kekakuan dialami setelah sendi tidak R digerakkan secara aktif. E Penyakit ini bukan penyakit tunggal tetapi merupakan akibat T akhir dari berbagai gangguan sebagai kegagalan sendi. Itu juga N dikenal sebagai artritis degeneratif, yang biasanya memengaruhi E tangan, kaki, tulang belakang, dan beban berat yang besar sendi, M seperti pinggul dan lutut. Osteoartritis lebih sering terjadi pada Esendi panggul dan lutut, tetapi jarang terjadi pada pergelangan Kkaki. Perubahan dalam respon kondrosit terhadap berbagai sitokin dapat menjadi alasannya, sebagai contoh kondrosit lutut mengekspresikan reseptor IL-1 (Interleukin-1) yang lebih banyak dibandingkan pada pergelangan kaki. Sebagian besar kasus osteoartritis tidak memiliki penyebab yang diketahui dan dirujuk sebagai osteoartritis primer. Osteoartritis primer sebagian besar terkait dengan penuaan. Osteoartritis primer bisa digolongkan lagi secara lokal, umum atau sebagai osteoartritis erosif. Osteoartritis sekunder disebabkan oleh penyakit atau kondisi lain. Osteoartritis adalah penyakit jdih.kemkes.go.id - 1 2 - reumatologi paling umum kedua dan merupakan penyakit sendi paling sering dengan prevalensi 22% hingga 39% di India. Penyakit ini paling banyak menyebabkan kecacatan lokomotor pada populasi tua. Oleh karena itu, osteoartritis merupakan penyebab utama morbiditas dan kecacatan, serta beban ekonomi yang signifikan pada pasien dan sumber daya perawatan kesehatan.

---

## 2. Gejala & Manifestasi Klinis
- dan parsial avaskular nekrosis pada talus. (Sedang) 83. Drain sebaiknya tidak digunakan pada TKA karena tidak ada perbedaan N komplikasi atau hasil yang signifikan. (Sedang) A 84. Bukti melaporkan bahwa tidak ada perbedaan antara patellar resurfacing T dan non-patellar resurfacing pada TKA. (Kuat Positif) A 85. Blokade saraf perifer TKA menyebabkan penurunan nyeri pascaoperasi dan H mengurangi kebutuhan opioid tanpa perbedaan komplikasi atau hasil. (Kuat E Positif) S 86. Infiltrasi periartikular yang digunakanE dalam TKA menyebabkan penurunan nyeri pascaoperasi dan kebutuhan opioid. (Kuat Positif) K 87. Bukti melaporkan bahwa tidak ada perbedaan hasil, fungsi, nyeri, atau N transfusi darah antara penggunaan tourniquet dengan tidak menggunakan A tourniquet. (Kuat Positif) I R 88. Asam traneksamat direkomendasikan digunakan pada pasien yang tidak ada kontrainEdikasi karena dapat mengurangi kehilangan darah pascaoperaTsi, pengumpulan drainase pascaoperasi, dan mengurangi kebutuNhan transfusi pascaoperasi TKA. (Kuat Positif) E 89. Asam traneksamat intravena atau topikal dapat digunakan untuk pasien M yang menjalani THA sebagai bagian dari upaya mengurangi kehilangan darah. (Sedang) E K90. Peningkatan risiko komplikasi mungkin terjadi pada pasien obesitas (IMT ≥40), khususnya infeksi pada lokasi operasi. (Kuat Positif) 91. Pasien obesitas dapat mencapai hasil luaran klinis yang lebih memuaskan, tetapi, tingkat kepuasan dan rasa sakit setelah THA tidak berbeda bermakna. (Sedang) 92. Pasien obesitas dengan osteoartritis panggul, mengalami peningkatan insiden komplikasi setelah THA. (Terbatas) 93. Direkomendasikan untuk mengontrol glukosa perioperatif (<126mg/dl) setelah TKA pada pasien dengan HbA1c <6,5 karena hiperglikemia dapat jdih.kemkes.go.id - 111 - menyebabkan luaran pascaoperasi yang kurang baik dan tingkat komplikasi lebih tinggi. (Kuat Positif) 94. Penghentian merokok direkomendasikan dilakukan sebelum menjalani TKA. (Konsensus) 95. Pasien yang merokok mempunyai peningkatan risiko komplikasi setelah THA. (Terbatas) N 96. Jenis kelamin pasien tidak berkaitan dengan luaran klinis pascaoperasi TSA. A (Kuat Negatif) T 97. Terdapat bukti ilmiah yang kuat yang menunjukkan bahwa pasien A dengan osteoartritis sendi glenohumeral yang memiliki lebih banyak H komorbiditas mengalami komplikasi awal pasca artroplasti yang lebih banyak. (Kuat Positif) E S E K N A I R E T N E M E K jdih.kemkes.go.id - 112 - BAB V KESIMPULAN Osteoartritis adalah penyakit kronis jangka panjang yang ditandai dengan rusaknya tulang rawan di persendian yang menyebabkan gesekan antar tulang dan berakibat pada kekakuan, rasa sakit, dan gangguan gerak. Penyakit ini merupakan penyebab kecacatan yang paling umum pada orang dewasa tua. N Pada tahun 2010, Global Burden of Disease Study melaporkan bahwa beban A gangguan muskuloskeletal jauh lebih besar daripada yang diperkirakan dalam T penilaian sebelumnya. Osteoartritis dapat menyerang semua tulang rawan di A sekujur tubuh, termasuk tulang belakang. Tungkai bawah, dari panggul hingga H pergelangan kaki, paling sering terkena karena menahan berat tubuh, sehingga penting untuk menjaga berat badan tetap ideal. E Tidak semua keluhan nyeri lutut pada usiaS lanjut merupakan osteoartritis. Untuk memastikan diagnosis, dokter akaEn melakukan evaluasi menyeluruh terhadap riwayat penyakit, cedera, operasi, dan pengobatan yang pernah K dijalani pasien. Jika diperlukan, pemeriksaan radiologi seperti X-ray pada lutut N atau pinggul dilakukan untuk menilai kondisi tulang secara lebih rinci dan memastikan adanya kerusakaAn tulang rawan. Tujuan dari tata laksana adalah mengurangi nyeri sendi, kekIakuan sendi, serta meningkatkan mobilitas sendi. R Penatalaksanaan osteoartritis menggunakan kombinasi pendekatan E farmakologi dan non farmakologi. Fokus penanganan mencakup pencegahan, T diagnosis dini dan penatalaksanaan osteoartritis (dini, osteoartritis eksaserbasi N akut, jangka panjang dan tahap lanjut). E

---

## 3. Kriteria & Alur Diagnosis
Rekomendasi ini dihasilkan dari pendekatan diagnosis osteoartritis dan M tata laksana farmakaologis maupun non-farmakologis. Tindakan operatif osteoartritis dipertimbangkan sebagai pilihan terakhir tata laksana setelah E berbagai evaluasi modalitas pengobatan tanpa operasi dilakukan. K MENTERI KESEHATAN REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 4. Tatalaksana & Terapi
pasien dengan gejala osteoartritis lutut. (Terbatas) jdih.kemkes.go.id - 108 - 54. Osteotomi tibialis proksimal dapat dipertimbangkan untuk memperbaiki nyeri dan fungsi pada pasien dengan osteoartritis lutut unikompartemen. (Terbatas) 55. Arthroscopic Partial Meniscectomy (APM) dapat digunakan untuk tata laksana robekan meniskus pada pasien dengan osteoartritis ringan hingga sedang yang gagal dalam terapi farmakologi dan non-farmakologi. (Sedang) N 56. Tindakan pembedahan dekompresi dilakukan untuk memperbaiki luaran A pada pasien dengan gejala stenosis spinal sedang ke berat. (Inkonklusif) T 57. Tindakan dekompresi dapat dipertimbangkan pada pasien berusia 75 tahun A atau lebih dengan stenosis tulang belakang lumbal. (Terbatas) H 58. Pada pasien dengan stenosis lumbar dengan nyeri punggung, nyeri kaki, E atau klaudikasio, tindakan dekompresi dan fusi menunjukkan luaran klinis S yang baik. (Sedang) E 59. Arthroscopic debridement dapat dilakukan pada OA ankle. (Sedang) K

---

## 5. Kriteria Rujukan (FKRTL)
Indikasi rujukan pasien osteoartritis ke dokter dengan kompetensi di M3. bidang orthopedi, yaitu: E a) Pasien osteoartritis dengan gejala klinis yang berat (nyeri, kaku K sendi, sendi sulit digerakkan, dan penurunan fungsi) sehingga mengganggu aktivitas sehari-hari dan memengaruhi kualitas hidup pasien b) Pasien osteoartritis dengan gejala yang menetap dan progresif

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK UNKNOWN
