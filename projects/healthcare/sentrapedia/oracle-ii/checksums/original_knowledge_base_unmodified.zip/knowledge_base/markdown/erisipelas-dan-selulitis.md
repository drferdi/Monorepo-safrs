---
id: 353
title: "Erisipelas dan Selulitis"
slug: "erisipelas-dan-selulitis"
icd_10: "L03.9"
category: "Penyakit Kulit dan Kelamin"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Erisipelas dan Selulitis (ICD-10: L03.9)

**Kategori Medis**: Penyakit Kulit dan Kelamin  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Infeksi bakteri akut pada kulit. Erisipelas adalah infeksi superfisial dermis atas dan pembuluh limfatik (paling sering Streptococcus pyogenes) dengan batas lesi sangat tegas dan meninggi; Selulitis adalah infeksi supuratif difus pada dermis dalam dan jaringan subkutan (Streptococcus pyogenes atau Staphylococcus aureus) dengan batas lesi tidak tegas.

---

## 2. Gejala & Manifestasi Klinis
- Plak eritematosa merah cerah, edema, hangat, dan sangat nyeri pada ekstremitas (tungkai bawah) atau wajah
- Erisipelas: tepi lesi meninggi dengan batas tegas tegas nyata dari kulit normal
- Selulitis: pembengkakan difus dengan batas tidak tegas yang meluas cepat
- Demam tinggi mendadak, menggigil, malaise
- Limfadenitis regional dan pembesaran kelenjar getah bening

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan dari inspeksi klinis tanda kardinal radang akut (rubor, calor, dolor, tumor) dengan batas tegas (erisipelas) atau tidak tegas (selulitis). Batas lesi ditandai dengan spidol permanen untuk memantau progresi perluasan lesi.

---

## 4. Tatalaksana & Terapi
1. Non-farmakologis: Elevasi tungkai yang terkena lebih tinggi dari jantung untuk mengurangi edema; tirah baring; kompres dingin/terbuka larutan fisiologis.
2. Antibiotik Sistemik Oral (Kasus Ringan Tanpa Gejala Sistemik Berat):
   - Amoksisilin-Klavulanat 3 x 625 mg oral, atau Kloksasilin 4 x 500 mg oral, atau Sefadroksil 2 x 500 mg oral selama 10-14 hari.
   - Klindamisin 3-4 x 300 mg oral (pada alergi penisilin).
3. Kasus Sedang-Berat: Antibiotik intravena (Seftriakson 1-2 g/hari IV atau Ampisilin-Sulbaktam 1.5 g/6 jam IV).
4. Analgesik antipiretik parasetamol 500 mg 3x/hari.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk CITO ke RS bila terdapat tanda selulitis fasial/periorbita, kecurigaan Fasiitis Nekrotikans (nyeri hebat melampaui temuan klinis, krepitasi subkutan, bula hemoragik, anestesi fokal), atau selulitis pada pasien immunocompromised/sepsis.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
