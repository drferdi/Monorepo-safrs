---
id: 354
title: "Varisela (Cacar Air)"
slug: "varisela-cacar-air"
icd_10: "B01.9"
category: "Penyakit Infeksi"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Varisela (Cacar Air) (ICD-10: B01.9)

**Kategori Medis**: Penyakit Infeksi  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Varisela (cacar air / chickenpox) adalah infeksi primer akut yang sangat menular yang disebabkan oleh Varicella-Zoster Virus (VZV), ditandai dengan erupsi vesikular generalisata polimorfik yang menyebar secara sentrifugal.

---

## 2. Gejala & Manifestasi Klinis
- Fase prodromal: demam subfebris, malaise, anoreksia, nyeri kepala 1-2 hari
- Erupsi kulit polimorfik simultan: makula eritematosa berkembang cepat menjadi papul, vesikel berdinding tipis seperti tetesan embun di atas kelopak mawar (dew drops on a rose petal), pustul, dan krusta
- Gatal hebat
- Penyebaran sentrifugal: lesi mulai dari badan lalu menyebar ke wajah, kulit kepala, dan ekstremitas

---

## 3. Kriteria & Alur Diagnosis
Penegakan diagnosis klinis dari lesi vesikel polimorfik simultan dalam berbagai stadium perkembangan (makula, papul, vesikel, krusta hadir bersamaan). Tzanck test kerokan dasar vesikel memperlihatkan sel datia berinti banyak (multinucleated giant cells).

---

## 4. Tatalaksana & Terapi
1. Terapi Simtomatik Suportif:
   - Tirah baring, isolasi mandiri hingga seluruh vesikel mengering menjadi krusta.
   - Losion Kalamin topikal untuk meredakan gatal pada vesikel yang belum pecah.
   - Antihistamin oral (Setirizin/Klorfeniramin) pereda gatal.
   - Antipiretik Parasetamol (KONTRAINDIKASI Aspirin karena risiko Sindrom Reye; hindari Ibuprofen karena risiko infeksi sekunder jaringan lunak invasif).
2. Antiviral Spesifik (Dimulai dalam < 24-48 jam sejak timbul ruam pada usia > 12 tahun, dewasa, atau komplikasi):
   - Asiklovir: Dewasa 5 x 800 mg oral per hari selama 7 hari; Anak 4 x 20 mg/kgBB/kali (maks 800 mg) selama 5 hari.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke RS bila terjadi komplikasi varisela pada orang dewasa/kehamilan: pneumonia varisela (batuk, sesak napas), ensefalitis varisela (kejang, ataksia serebelar, penurunan kesadaran), atau infeksi bakteri sekunder invasif berat.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
