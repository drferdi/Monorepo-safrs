---
id: 315
title: "Epistaksis"
slug: "epistaksis"
icd_10: "R04.0"
category: "Penyakit THT"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Epistaksis (ICD-10: R04.0)

**Kategori Medis**: Penyakit THT  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Epistaksis adalah perdarahan akut dari rongga hidung yang paling sering berasal dari pleksus Kiesselbach di septum anterior (epistaksis anterior, 90%) atau arteri sfenopalatina di posterior (epistaksis posterior, sering pada lansia/hipertensi).

---

## 2. Gejala & Manifestasi Klinis
- Keluarnya darah segar dari salah satu atau kedua lubang hidung
- Darah tertelan mengalir ke tenggorokan (post-nasal drip darah)
- Riwayat mengorek hidung, trauma wajah, udara kering, atau hipertensi

---

## 3. Kriteria & Alur Diagnosis
Penegakan diagnosis sumber perdarahan dengan rinoskopi anterior pasca evakuasi bekuan darah menggunakan lampu kepala. Pengukuran tekanan darah dan tanda vital wajib dilakukan.

---

## 4. Tatalaksana & Terapi
1. Penanganan Segera Metode Trotter:
   - Pasien duduk tegak condong ke depan (jangan menengadah agar darah tidak tertelan/teraspirasi).
   - Menekan cuping hidung selama 10-15 menit sambil bernapas melalui mulut.
2. Jika Perdarahan Berlanjut:
   - Pasang tampon anterior kapas yang dibasahi vasokonstriktor (Adrenalin 1:10.000 atau Oksimetazolin) + Lidokain 2% selama 10-15 menit.
   - Kauterisasi kimiawi lidi kapas Perak Nitrat (AgNO3) 20-30% pada titik perdarahan yang teridentifikasi.
   - Jika masih berdarah: pasang tampon hidung anterior rol kasa vaselin-antibiotik selama 2 x 24 jam.
3. Kontrol tekanan darah bila ada krisis hipertensi.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk CITO ke IGD RS / Spesialis THT bila perdarahan berasal dari posterior yang memerlukan tampon Bellocq (tampon posterior), perdarahan masif refrakter, hemodinamik tidak stabil, atau dicurigai gangguan koagulopati/keganasan nasofaring.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
