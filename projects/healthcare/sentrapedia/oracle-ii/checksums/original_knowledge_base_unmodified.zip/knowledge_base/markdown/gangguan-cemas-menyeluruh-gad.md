---
id: 338
title: "Gangguan Cemas Menyeluruh (GAD)"
slug: "gangguan-cemas-menyeluruh-gad"
icd_10: "F41.1"
category: "Penyakit Jiwa"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Gangguan Cemas Menyeluruh (GAD) (ICD-10: F41.1)

**Kategori Medis**: Penyakit Jiwa  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Gangguan Cemas Menyeluruh (Generalized Anxiety Disorder / GAD) adalah gangguan kecemasan yang ditandai oleh kekhawatiran dan ansietas berlebihan yang pervasif dan tidak realistis mengenai berbagai peristiwa kehidupan sehari-hari, berlangsung hampir setiap hari selama minimal 6 bulan, disertai gejala ketegangan motorik dan hiperaktivitas otonom.

---

## 2. Gejala & Manifestasi Klinis
- Kekhawatiran kronis yang sulit dikendalikan
- Gelisah, tegang, atau merasa terpojok (on edge)
- Mudah lelah dan sulit berkonsentrasi
- Ketegangan otot (pegal pada leher, bahu, punggung)
- Gangguan tidur (sulit tidur nyenyak)
- Gejala otonom: palpitasi jantung, berkeringat dingin, mulut kering, pusing, gangguan lambung

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan berdasarkan kriteria PPDGJ-III / DSM-5: kecemasan dan kekhawatiran berlebihan hampir setiap hari selama minimal 6 bulan tentang berbagai aktivitas, disertai minimal 3 dari 6 gejala (kegelisahan, mudah lelah, konsentrasi buruk, iritabilitas, ketegangan otot, gangguan tidur).

---

## 4. Tatalaksana & Terapi
1. Psikoterapi: Cognitive Behavioral Therapy (CBT), latihan relaksasi pernapasan diafragma (deep breathing), dan mindfulness.
2. Farmakologis Lini Pertama:
   - Golongan SSRI: Sertralin 1 x 25-50 mg/hari oral atau Fluoksetin 1 x 20 mg/hari oral (efek terapi optimal muncul setelah 2-4 minggu).
   - Benzodiazepin jangka sangat pendek (maks 2-4 minggu) untuk mengatasi kecemasan akut: Diazepam 2-5 mg 1-2x/hari oral atau Alprazolam 0.25-0.5 mg oral prn.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Kedokteran Jiwa (Sp.KJ) bila terdapat komorbiditas depresi berat dengan risiko bunuh diri, serangan panik berat, riwayat penyalahgunaan zat, atau gejala refrakter setelah 8-12 minggu terapi SSRI optimal.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
