---
id: 295
title: "Disentri Basiler (Shigellosis)"
slug: "disentri-basiler-shigellosis"
icd_10: "A03.9"
category: "Penyakit Infeksi"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Disentri Basiler (Shigellosis) (ICD-10: A03.9)

**Kategori Medis**: Penyakit Infeksi  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Disentri basiler adalah infeksi invasif usus besar yang disebabkan oleh bakteri genus Shigella (S. dysenteriae, S. flexneri, S. sonnei, S. boydii), ditandai dengan peradangan mukosa kolon, ulserasi, dan eksudat inflamasi.

---

## 2. Gejala & Manifestasi Klinis
- Diare dengan tinja berlendir dan bercampur darah
- Tenesmus (rasa mengedan dan nyeri saat BAB)
- Kram perut hebat
- Demam tinggi mendadak
- Mual dan muntah
- Anoreksia

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan berdasarkan anamnesis sindrom disentri (diare lendir darah + tenesmus + demam). Pemeriksaan feses mikroskopis langsung menunjukkan eritrosit banyak, leukosit PMN melimpah (> 10-15 per LPB), dan makrofag, tanpa ditemukan trofozoit amuba.

---

## 4. Tatalaksana & Terapi
1. Rehidrasi oralit atau cairan IV sesuai derajat dehidrasi.
2. Antibiotik Lini Pertama:
   - Siprofloksasin 2 x 500 mg oral selama 3-5 hari (dewasa).
   - Azitromisin 1 x 500 mg oral pada hari 1, dilanjutkan 1 x 250 mg hari 2-5 (pilihan anak dan ibu hamil).
   - Seftriakson 50-100 mg/kgBB/hari IV selama 3-5 hari pada kasus berat/rawat inap.
3. Antipiretik parasetamol bila demam. KONTRAINDIKASI obat antimotilitas usus (loperamid/diphenoxylate) karena memperparah invasi toksin dan memicu megakolon toksik.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke RS bila terjadi komplikasi megakolon toksik, perforasi usus, prolaps rekti, sindrom hemolitik uremik (HUS), dehidrasi berat tidak teratasi, atau malnutrisi berat pada balita.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
