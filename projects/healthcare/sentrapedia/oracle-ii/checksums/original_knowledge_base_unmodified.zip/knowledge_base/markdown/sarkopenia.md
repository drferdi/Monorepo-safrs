---
id: 159
title: "Sarkopenia"
slug: "sarkopenia"
icd_10: "M62.84"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Sarkopenia (ICD-10: M62.84)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
didefinisikan sebagai penurunan masa otot disertai penurunan kekuatan E otot dan/atau performa fisik. Sarkopenia ditandai dengan inaktivitas fisik, perubahan cara berjalan, dan penurunaSn kekuatan fisik. Adapun gangguan fungsi yang mungkin timbul akEibat Sarkopenia mencakup: 1. Ganguan mobilisasi. K 2. Gangguan aktivitas sehari-hari. N 3. Gangguan keseimbangan. A 4. Gangguan kapasitas fungsional. I 5. Gangguan postur. R 6. Gangguan koordinasi. E T

---

## 2. Gejala & Manifestasi Klinis
_Manifestasi klinis tertera pada kriteria diagnostik._

---

## 3. Kriteria & Alur Diagnosis
Anamnesis dalam menegakkan diagnosis sarkopenia menggunakan N kuesioner SARC-F. B. A Pemeriksaan fisik dalam mendiagnosa sarkopenia meliputi tiga komponen T utama yaitu kekuatan otot (uji kekuatan genggam tangan), massa otot C. A (LILA dan lingkar betis) dan performa fisik (SPPB, UDB-5, dan uji H kecepatan jalan 6 meter). E Pemeriksaan penunjang yang dapat dilakukan untuk menegakkan S diagnosa sarkopenia diantaranya adalah Dual-energy X-ray D. Absorptiometry (DXA) dan Bioelectric ImpEedance Analysis (BIA). Tata laksana pasien dengan sarkopKenia dapat dilakukan dengan latihan fisik (berbasis ketahanan, aerobik , dan campuran) dan asupan nutrisi E. N (suplementasi protein, leusin). A Dalam mengelola pasien dengan sarkopenia di fasilitas pelayanan I kesehatan tingkat pertama, rujukan ke fasilitas kesehatan yang lebih F. R tinggi dapat dilakukan sebagai upaya konfirmasi diagnostik. E T N MENTERI KESEHATAN E REPUBLIK INDONESIA, M E ttd. K BUDI G. SADIKIN jdih.kemkes.go.id

---

## 4. Tatalaksana & Terapi
untuk terapi sarkopenia pada lansia. Peringkat bukti II, derajat rekomendasi B. K. Lansia dengan sarkopenia harus didorong untuk berpartisipasi dalam latihan tahanan (resistance training) untuk meningkatkan kekuatan otot dan kinerja fisik. Peringkat bukti I, derajat rekomendasi A. jdih.kemkes.go.id - 32 - BAB V SIMPULAN Sarkopenia adalah pengurangan massa dan kekuatan otot dengan atau tanpa performa fisik yang risikonya semakin tinggi seiring dengan proses A. penuaan.

---

## 5. Kriteria Rujukan (FKRTL)
Pada prinsipnya rujukan pasien sarkopenia dari fasilitas pelayanan kesehatan tingkat pertama ke fasilitas pelayanan kesehatan tingkat lanjut adalah suatu rujukan diagnostik. Pada saat pasien yang dicurigai sarkopenia datang ke fasilitas N pelayanan kesehatan tingkat pertama dapat dilakukan A pemeriksaan lingkar betis atau pengkajian sarkopenia dengan menggunakan SARC-F/SARC-CalF. Apabila Tpemeriksaan A mendukung ke arah sarkopenia maka dapat dilanjutkan dengan pengkajian kekuatan otot atau performa fHisik sederhana seperti uji duduk berdiri-5 kali (UDB-5) atau SEhort Physical Performance Battery (SPPB). Apabila hasilnya adalah possible sarkopenia S maka pasien dianjurkan untuk melakukan perubahan gaya E hidup yang mencakup diet dan olahraga, yang kemudian dirujuk K ke fasilitas pelayanan kesehatan tingkat lanjut untuk konfirmasi N diagnosis menggunakan modalitas yang lebih lengkap. Bagan rujukan dapat dilihAat pada Gambar 1 Alur Rujukan. I R E T N E M E K jdih.kemkes.go.id N A T A H E S E K N A I R E T N E M E K Gambar 1. Alur Diagnostik dan Rujukan Penanganan Sarkopenia jdih.kemkes.go.id BAB IV RANGKUMAN PERINGKAT BUKTI DERAJAT REKOMENDASI A. Semua lansia usia diatas 65 tahun dilakukan deteksi dini sarkopenia dengan SARC-F. Peringkat bukti II, derajat rekomendasi B. B. Pemeriksaan fisik yang dapat dilakukan meliputi pemeriksan lingkar betis, uji kekuatan genggam tangan, uji duduk berdiri-5 kali (UDB-5), kecepatan jalan 6 meter, SPPB. Peringkat bukti II, derajat rekomendNasi B. C. Pemeriksaan penunjang yang dapat dilakukan dalam mendiagnosa A sarkopenia diantaranya Dual-energy X-ray Absorptiometry (DXA). Jika T DXA tidak tersedia, maka dapat menggunakan Bioelectric Impedance A Analysis (BIA). Peringkat bukti II, derajat rekomendasi B. H

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2024
