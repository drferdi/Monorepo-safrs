---
id: 274
title: "Tatalaksana Ulkus Kornea Bakteri"
slug: "tatalaksana-ulkus-kornea-bakteri"
icd_10: "H16.0"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Tatalaksana Ulkus Kornea Bakteri (ICD-10: H16.0)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Ulkus Kornea adalah keadaan patologik kornea yang ditandai oleh adanya infiltrat supuratif disertai defek kornea, diskontinuitas jaringan kornea yang dapat terjadi dari epitel sampai stroma. Ulkus kornea merupakan hilangnya sebagian permukaan kornea akibat N kematian jaringan kornea. Ulkus kornea yang luas memerlukan A penanganan yang tepat dan cepat untuk mencegah perluasan ulkus T dan timbulnya komplikasi seperti descemetocele, perforasi, A endoftalmitis. H

---

## 2. Gejala & Manifestasi Klinis
- terkait pengenalan secara dini gejala dan tanda klinis perlu diupayMakan, sehingga diagnosis dan tatalaksana secara dini dan tepat dapat diberikan sesuai standar, untuk mencegah komplikasi yang lebih berat. E Terakhir, sistem pencatatan dan pelaporan kasus secara terintegrasi perlu K dilakukan untuk pemantauan serta pengambilan kebijakan yang berbasis data. jdih.kemkes.go.id - 41 - Pedoman Nasional Pelayanan Klinis ini dibuat dengan tujuan sebagai pedoman penanganan ulkus kornea bakteri berdasarkan evidence-based medicine (EBM) yang kuat. MENTERI KESEHATAN REPUBLIK INDONESIA, N A ttd. T A BUDI G. SADIKIN H E S E K N A I R E T N E M E K jdih.kemkes.go.id

---

## 3. Kriteria & Alur Diagnosis
AIOS Guidelines for Diagnosis and Management of Microbial 7 III E Keratitis M Cochrane Library: Topical Corticosteroid as Adjunctive Therapy for 8 I++ Bacterial Keratitis (Review) E Joint Ophthalmology and Microbiology Microbial Keratitis K9 III Guidelines WHO: Guidelines for the Management of Corneal Ulcer at Primary, 10 Secondary & Tertiary Care Health Facilities in the South-East Asia II++ Region Guidelines for the Management of Suspected Microbial Keratitis in 11 III Settings with Limited Laboratory Facilities The Asia Cornea Society Infectious Keratitis Study: A Prospective 12 II+ Multicentre Study of Infectious Keratitis in Asia jdih.kemkes.go.id - 39 - Comparison of Combined Fortified Antibiotics and Monotherapy 13 II++ Fluoroquinolone in the Treatment of Bacterial Keratitis Liesegag TJ, Skuta GL, Canton LB. Basic and Clinical Science Course. External Eye Disease. Section 8. San Francisco: The 14 IV foundation of the American Academy of Ophthalmology; 2019- 2020 Duane Ophthalmology, Edward A. Jaeger, William Tasman, 15 IV Lippincott Williams & Wilkins, 2013; Chapter 18, p.21. N Alex Lap-King, et al. Predisposing Factor, Microbial Characteristic, A 16 and Clinical Outcome of Microbial Keratitis. Journal of Ophthalmol II+ T 2015, p. 9. A Paediatric infectious keratitis: a case series of 107 children H presenting to a tertiary referral centre. Julia Dutra Rossetto, Kara 17 III E M Cavuoto1, Carla J Osigian, Ta Chen (Peter) Chang, et al. Br J Ophthalmol. 2017; p.101. S The Asia Cornea Society Infectious KeratitEis Study: A Prospective Multicentre Study of Infectious Keratitis in Asia. Wei-Boon Khor, K 18 Venkatesh N. Prajna, Prashant Garg, Richard L. Abbott, Donald II++ Tiang-Hwee Tan. Am J OphthaNlmol. 2018. Volume 195, p. 161- 170. A Karakteristik Klinis, Etiologis, dan Faktor Risiko Pasien Ulkus I R Kornea di RSCM. Lukman Edwar, Ratna Sitompul, Made 19 Susiyanti, Rina EL. D. Nora, Yulia Aziza, Ulifna A. Sifyana, Ranita A. Carolina, Nafisa Shihab. (unpublished) T Hospital –based epidemiology, risk factor and microbiological N diagnosis of bacterial corneal ulcer. Ashok Kumar Narsani, Shafi E 20 Muhammad Jatoi, Mahesh Kumar Lohana, Syed Asher Dabir, II+ M Siddiqa Gul, Mahtab alam Khanzada. Int J Ophthalmol. 2009. Vol 2 No 4. E Clinical Characteristics of Bacterial Corneal Ulcer at Kariadi K 21 Hospital Semarang. Seia Mahanani, Winarto, Dina Novita, Iva Puspitasari. (unpublished). 2020 Bacterial keratitis: perspective on epidemiology, clinico- pathogenesis, diagnosis and treatment. Al-Mujaini, A., Al-Kharusi, 22 IV N., Thakral, A., & Wali, U. K. (2009). Sultan Qaboos University medical journal, 9(2), 184–195. Clinical evaluation of non-healing bacterial corneal ulcer: in 23 present scenario. Jain, B., & Shrivastawa, M. (2014). Journal of III Evolution of Medical and Dental Sciences, 2014. 3(53) jdih.kemkes.go.id - 40 - BAB V SIMPULAN Ulkus kornea adalah keadaan patologik kornea yang ditandai adanya infiltrat supuratif disertai defek kornea, diskontinuitas jaringan kornea yang dapat terjadi dari epitel sampai stroma kornea. Ulkus kornea dibedakan menjadi N infeksi (bakteri, jamur, virus, protozoa) dan non-infeksi. Ulkus kornea infeksi A paling sering disebabkan oleh bakteri. Diagnosis ulkus kornea bakteri T ditegakkan melalui anamnesis, pemeriksaan slit lamp, serta pemeriksaan A mikrobiologi (pewarnaan dan kultur). Tatalaksana di FPKTP meliputi edukasi dan terapi empiris dengan antibiotika topikal spektrum lHuas, dan harus segera dirujuk ke FPKTL. Pada FPKTL, pemeriksaan mikrEobiologi dilakukan sesuai ketersediaan fasilitas yang ada dan diberikan teraSpi kombinasi fortified antibiotic topikal atau monoterapi golongan kuinolon. Tindakan operatif dilakukan jika E

---

## 4. Tatalaksana & Terapi
penyakit terus berlanjut atau tidak responsif terhadap terapi medikamentosa K maksimal atau jika terjadi pembentukan descemetocele atau perforasi. N Dalam upaya promotif dan preventif terhadap kasus ulkus kornea bakteri dilakukan sosialisasi pengenalaAn faktor risiko dan pencegahan cedera mata/ kornea, misalnya pada pengguIna lensa kontak dan penggunaan pelindung mata R pada pekerjaan yang berisiko. Sarana diagnostik perlu dilengkapi guna E menunjang akurasi penegakan diagnosis, dalam hal ini pendekatan T multidisiplin bersama dengan bagian terkait seperti Mikrobiologi sangat N diperlukan. Peningkatan kemampuan tenaga kesehatan melalui pelatihan E

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk SEGERA ke Dokter Spesialis Mata (Sp.M) untuk pemeriksaan kerokan kornea (pewarnaan Gram dan kultur sensitivitas jamur/bakteri) dan pemberian antibiotik topikal terfortifikasi (fortified antibiotics).

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK UNKNOWN
