---
id: 294
title: "Demam Tifoid"
slug: "demam-tifoid"
icd_10: "A01.0"
category: "Penyakit Infeksi"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Demam Tifoid (ICD-10: A01.0)

**Kategori Medis**: Penyakit Infeksi  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Demam tifoid adalah penyakit infeksi sistemik akut yang disebabkan oleh bakteri Salmonella enterica serovar Typhi (Salmonella typhi), ditularkan secara fekal-oral melalui makanan atau minuman yang terkontaminasi.

---

## 2. Gejala & Manifestasi Klinis
- Demam remiten meningkat bertahap (step-ladder pattern) terutama sore-malam hari > 7 hari
- Nyeri kepala frontal
- Lidah kotor dengan tepi hiperemis dan tremor (typhoid tongue)
- Konstipasi pada dewasa atau diare pada anak
- Meteorismus (perut kembung)
- Bradikardia relatif
- Hepatomegali / splenomegali
- Apatis / tifoid ensefalopati pada kasus berat

---

## 3. Kriteria & Alur Diagnosis
Penegakan diagnosis berdasarkan gejala demam klinis > 1 minggu dengan typhoid tongue dan bradikardia relatif. Pemeriksaan penunjang FKTP: Darah rutin (leukopenia atau normositosis, limfositosis relatif, aneosinofilia), Uji serologi Tubex-TF (skor >= 4 positif infeksi aktif) atau Widal (titer O dan/atau H >= 1/160 atau peningkatan 4 kali lipat pada konvalesen), baku emas kultur Salmonella (darah minggu I-II; feses minggu II-III).

---

## 4. Tatalaksana & Terapi
1. Tirah baring (bed rest) dan diet lunak rendah serat tinggi kalori-protein.
2. Farmakologis Lini Pertama:
   - Kloramfenikol: Dewasa 4 x 500 mg oral selama 14 hari (atau sampai 7 hari bebas demam).
   - Tiamfenikol: 4 x 500 mg oral selama 10-14 hari.
   - Siprofloksasin: 2 x 500 mg oral selama 7-10 hari (lini pertama dewasa non-hamil).
   - Seftriakson: 2-4 gram IV per hari dalam 1-2 dosis selama 5-7 hari (pilihan pada komplikasi/resistensi/ibu hamil).
   - Amoksisilin 3-4 x 1000 mg oral atau Kotrimoksazol 2 x 960 mg oral selama 14 hari (alternatif aman pada kehamilan).

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke RS / Spesialis Penyakit Dalam bila terdapat komplikasi intestinal (perdarahan saluran cerna, perforasi usus ditandai peritonitis akut) atau ekstra-intestinal (ensefalopati tifoid, miokarditis, syok septik), muntah persisten, atau demam persisten setelah 5 hari antibiotik lini pertama.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
