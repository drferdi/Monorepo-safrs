---
id: 328
title: "Benda Asing Konjungtiva"
slug: "benda-asing-konjungtiva"
icd_10: "T15.1"
category: "Penyakit Mata"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Benda Asing Konjungtiva (ICD-10: T15.1)

**Kategori Medis**: Penyakit Mata  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Benda asing konjungtiva adalah adanya partikel eksternal (debu, serpihan pasir, serangga, gram logam) yang menempel atau terperangkap pada permukaan konjungtiva bulbi, forniks, atau konjungtiva tarsal.

---

## 2. Gejala & Manifestasi Klinis
- Rasa mengganjal hebat mendadak pada mata
- Mata berair (lakrimasi berlebih)
- Mata merah dan fotofobia ringan
- Nyeri saat berkedip (terutama bila benda asing menempel di konjungtiva tarsal superior)

---

## 3. Kriteria & Alur Diagnosis
Pemeriksaan mata luar dengan slit lamp atau loupe dan senter: inspeksi konjungtiva bulbi dan wajib melakukan eversi kelopak mata atas untuk mengevaluasi sulkus subtarsalis. Tes fluoresin untuk memastikan tidak ada erosi kornea.

---

## 4. Tatalaksana & Terapi
1. Anestesi topikal: Pantokain 0.5% atau Tetrakain 0.5% 1-2 tetes pada mata yang terkena.
2. Ekstraksi Benda Asing:
   - Irigasi lembut menggunakan larutan NaCl 0.9% steril, atau
   - Angkat benda asing secara hati-hati menggunakan lidi kapas steril basah atau jarum suntik 25G steril dari arah tepi.
3. Medikamentosa Pasca-ekstraksi:
   - Kloramfenikol 1% salep mata atau tetes mata antibiotik profilaksis 3-4 kali sehari selama 3-5 hari.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Mata bila benda asing tertanam dalam pada stroma sklera/kornea, benda asing logam dengan cincin karat (rust ring), benda asing intraokular tembus, atau timbul infeksi sekunder keratitis.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
