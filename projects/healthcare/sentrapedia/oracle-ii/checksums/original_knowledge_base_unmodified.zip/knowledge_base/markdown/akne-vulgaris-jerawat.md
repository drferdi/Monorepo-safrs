---
id: 348
title: "Akne Vulgaris (Jerawat)"
slug: "akne-vulgaris-jerawat"
icd_10: "L70.0"
category: "Penyakit Kulit dan Kelamin"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Akne Vulgaris (Jerawat) (ICD-10: L70.0)

**Kategori Medis**: Penyakit Kulit dan Kelamin  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Akne vulgaris adalah penyakit inflamasi kronik unit pilosebasea yang multifaktorial (hiperkeratinisasi folikel, hiperproduksi sebum androgenik, kolonisasi bakteri Cutibacterium acnes, dan respons inflamasi), umum timbul pada masa pubertas.

---

## 2. Gejala & Manifestasi Klinis
- Komedo terbuka (blackhead) dan komedo tertutup (whitehead)
- Papul dan pustul inflamasi eritematosa
- Nodul dan kista nyeri pada akne derajat berat
- Jaringan parut pasca-akne (skar atrofi/hipertrofi) dan hiperpigmentasi pasca-inflamasi (HPI)
- Predileksi: wajah, dada, punggung atas

---

## 3. Kriteria & Alur Diagnosis
Penegakan diagnosis klinis berdasarkan inspeksi lesi polimorfik komedo, papul, dan pustul pada area kaya kelenjar sebasea. Penentuan derajat keparahan (ringan: komedo dominan; sedang: papul/pustul multipel; berat: nodul/kista luas).

---

## 4. Tatalaksana & Terapi
1. Akne Ringan (Komedonal/Papular Ringan):
   - Retinoid topikal (Adapalen gel 0.1% atau Tretinoin krim 0.025-0.05%) dioleskan tipis malam hari.
   - Benzoil Peroksida (BPO) gel 2.5-5% dioleskan pagi/siang hari.
2. Akne Sedang (Papulopustular):
   - Kombinasi Retinoid topikal + BPO + Antibiotik topikal (Klindamisin gel 1%).
   - Antibiotik Oral Sistemik (bila lesi inflamasi luas): Doksisiklin 1 x 50-100 mg/hari oral selama 6-12 minggu.
3. Edukasi: membersihkan wajah 2 kali sehari dengan sabun pembersih lembut, tidak memencet jerawat, dan menggunakan tabir surya non-komedogenik.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Kulit dan Kelamin bila Akne Konglobata / Akne Fulminans (akne kistik nodular berat dengan ulserasi), skar hipertrofik/keloid masif, atau memerlukan terapi Isotretinoin oral.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
