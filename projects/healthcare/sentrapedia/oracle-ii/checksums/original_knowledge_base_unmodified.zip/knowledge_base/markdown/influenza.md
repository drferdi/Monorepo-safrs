---
id: 307
title: "Influenza"
slug: "influenza"
icd_10: "J11.1"
category: "Penyakit Paru"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Influenza (ICD-10: J11.1)

**Kategori Medis**: Penyakit Paru  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Influenza adalah infeksi saluran pernapasan akut menular yang disebabkan oleh virus Influenza tipe A atau B, ditandai dengan awitan gejala sistemik mendadak seperti demam tinggi, mialgia, dan batuk kering.

---

## 2. Gejala & Manifestasi Klinis
- Demam mendadak tinggi (> 38°C) menggigil
- Nyeri otot dan sendi (mialgia difus hebat)
- Sakit kepala retroorbital
- Batuk kering
- Sakit tenggorokan
- Rinorea (hidung berair)
- Kelelahan ekstrem (fatigue)

---

## 3. Kriteria & Alur Diagnosis
Diagnosis klinis berdasarkan pola awitan mendadak trias demam tinggi + mialgia + gejala respiratorik saat musim penularan. Penunjang: Rapid Influenza Diagnostic Test (RIDT) swab nasofaring bila tersedia.

---

## 4. Tatalaksana & Terapi
1. Suportif (Pasien Tanpa Faktor Risiko):
   - Istirahat tirah baring, hidrasi cairan hangat cukup.
   - Antipiretik/analgesik: Parasetamol 500-1000 mg 3-4x/hari atau Ibuprofen 400 mg 3x/hari.
   - Dekongestan oral (pseudoefedrin) bila hidung tersumbat berat.
2. Antiviral Spesifik (Oseltamivir):
   - Diberikan dalam < 48 jam sejak onset pada populasi risiko tinggi komplikasi (lansia > 65 tahun, ibu hamil, anak < 2 tahun, komorbiditas kronik, imunokompromais):
   - Oseltamivir 2 x 75 mg oral per hari selama 5 hari.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke RS bila timbul tanda bahaya respirasi: sesak napas, takipnea, saturasi O2 < 92%, nyeri dada pleuritik, hemoptisis, penurunan kesadaran, atau kecurigaan komplikasi pneumonia influenza berat.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
