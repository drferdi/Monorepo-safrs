---
id: 271
title: "Leukemia Limfoblastik Akut Pada Anak"
slug: "leukemia-limfoblastik-akut-pada-anak"
icd_10: "C91.0"
category: "Penyakit Anak"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Leukemia Limfoblastik Akut Pada Anak (ICD-10: C91.0)

**Kategori Medis**: Penyakit Anak  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Neurokognisi dapat didefinisikan sebagai kemampuan T proses kognitif yang terkait dengan mekanisme spesifik pada A otak. Diestimasikan bahwa lebih dari setengah dari anak-anak H yang terkena kanker dapat mengalami gangguan kognitif. Anak-anak dengan tumor saraf pusEat dan LLA adalah yang memiliki risiko tertinggi unStuk mengalami gangguan neurokognisi. Selain disebabkEan oleh keterlibatan sistem saraf pusat yang secara langsung dapat terjadi pada LLA, terdapat K

---

## 2. Gejala & Manifestasi Klinis
- atau apabila terdapat gejala toksisitas obat setelah pemberian thiopurine. Pemeriksaan dilakukan menggunakan metode amplifikasi PCR. Alel non fungsional yang sering ditemukan pada TPMT adalah *2, *3A, *3A, *3C, dan *4. Pada 3 - 14% pasien membawa genotipe TMPT heterozigot dimana terdapat 1 alel fungsional dan 1 alel non fungsional. Sedangkan 0,03% - 0.5% dari pasien memiliki genotipe TPMT homozigot dimana terdapat 2 alel non fungsional. Mielosupresi berat setelah pemberian terapi jdih.kemkes.go.id - 125 - thiopurine dengan dosis standar terjadi 100% pada pasien dengan genotipe homozigot dan 30 - 60% pada pasien dengan genotipe heterozigot sehingga penyesuaian dosis perlu diberikan. Insidensi genotipe TPMT heterozigot pada Asia Tenggara lebih rendah yaitu sebanyak 1.2 - 2%. Sebanyak 25% dari Asia dan Amerika membawa alel NUDT15 non fungsional. N A 6) Manajemen Anestesi untuk Prosedur Invasif pada LLA T Manajemen anestesi sangat penting dalam mendukung A pelaksanaan prosedur invasif pada LLA anak, seperti aspirasi dan H biopsi sumsum tulang, pungsi lumbal, serta pendampingan radioterapi. Anestesi atau sedasi diperluEkan untuk memastikan kenyamanan pasien, meminimalkaSn trauma psikologis, dan mendukung keberhasilan proseduEr. Aspirasi dan biopsi sumsum tulang, terutama yang pertama kali, sebaiknya dilakukan dengan K sedasi dalam atau anestesi umum, tanpa memandang usia. N Meskipun terdapat anak yang dapat menjalani prosedur tanpa sedasi, pendekatanA ini harus bersifat individual dan tetap menggunakan anesItesi lokal (1% lidokain buffered). Pungsi lumbal, R yang sering dilakukan selama fase awal pengobatan, juga E memerlukan sedasi dalam atau anestesi umum, terlebih bila T dikombinasikan dengan tindakan lain. N Jenis sedasi yang digunakan dibagi ke dalam beberapa kategori. E Sedasi minimal (ansiolisis) diberikan untuk mengurangi kecemasan M dan dicapai dengan obat seperti diazepam atau lorazepam. Sedasi sedang, yang menggunakan kombinasi midazolam, fentanil, atau E ketamin, memberikan efek sedatif dan analgesik yang aman untuk K prosedur nyeri dan dapat diberikan di luar ruang operasi selama terdapat monitoring yang memadai. Untuk prosedur yang memerlukan imobilisasi penuh atau bersifat sangat nyeri, sedasi dalam atau anestesi umum digunakan, dengan propofol sebagai salah satu obat yang paling sering dipilih karena onset cepat dan durasi singkat. Kombinasi propofol dengan fentanil atau ketamin (ketofol) dapat meningkatkan kualitas sedasi dan menurunkan risiko efek samping. Sebelum pelaksanaan anestesi atau sedasi, diperlukan evaluasi jdih.kemkes.go.id - 126 - klinis menyeluruh terhadap kondisi pasien. Pemeriksaan meliputi status hematologi (hemoglobin, leukosit, trombosit), koagulasi, elektrolit, serta adanya komorbid seperti gangguan jantung atau paru. Penilaian risiko anestesi dilakukan melalui pemeriksaan pra- anestesi, termasuk riwayat alergi, kesulitan jalan napas, dan status imunosupresi. Pasien harus menjalani puasa sesuai rekomendasi standar, yaitu minimal enam jam untuk makanan padat, empat jam N untuk ASI, dan dua jam untuk cairan jernih, meskipun beberapa A konsensus terbaru mengizinkan cairan jernih hingga satu jam T sebelum prosedur untuk meningkatkan kenyamanan anak. Jika A diperlukan, transfusi darah atau trombosit dapat diberikan sesuai H kondisi klinis dan ambang nilai aman, dengan mempertimbangkan keamanan hemodinamik dan risiko perdaErahan. Tindakan sedasi dan anestesi umSumnya dilakukan di ruang rawat inap, mengingat kebutuhaEn monitoring dan kemungkinan observasi pasca-tindakan. Namun, apabila tersedia ruang tindakan K rawat jalan yang dilengkapi sistem monitoring dan tenaga terlatih, N serta untuk menghindari keterlambatan tindakan akibat antrean di rawat inap, proseduAr dapat dilaksanakan di rawat jalan. Hal ini penting karena peInundaan tindakan dapat berdampak negatif R terhadap keberhasilan pengobatan anak dengan LLA. E b. Tatalaksana Nonfarmakologis T 1) Tatalaksana Nutrisi N Tatalaksana nutrisi pada penyakit leukemia anak menjadi E penting dan bertujuan untuk mencegah dan mengendalikan M malnutrisi atau defisit nutrisi yang mempengaruhi respon terapi, mendukung kesehatan pasien, kualitas hidup secara keseluruhan E dan kesintasan pasien. Kesintasan pasien LLA meningkat dalam 50 K tahun terakhir dari 10% menjadi 90%. Namun, terdapat kondisi akibat terapi kanker yang harus diwaspadai terutama adanya 35% penyintas yang menderita hipertrigliseridemia, dan 60% mengalami massa tulang rendah.

---

## 3. Kriteria & Alur Diagnosis
tingkat pertama untuk dapat melSakukan diagnosis awal dan merujuk ke fasilitas pelayanan kEesehatan yang lebih tinggi untuk dilakukan diagnosis dan tata laksana segera. K N MENTERI KESEHATAN A REPUBLIK INDONESIA, I R ttd. E T BUDI G. SADIKIN N E M E K jdih.kemkes.go.id

---

## 4. Tatalaksana & Terapi
, direkomendasikan A untuk tetap melakukan pengawasan rutin untuk menilai status H penyakit. 13. Penanganan LLA dimulai dari fasilitaEs pelayanan kesehatan

---

## 5. Kriteria Rujukan (FKRTL)
Koordinasi dua arah yang sistematis antara rumah sakit rujukan

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK UNKNOWN
