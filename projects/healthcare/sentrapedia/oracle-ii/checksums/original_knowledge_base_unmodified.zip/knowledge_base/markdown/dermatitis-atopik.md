---
id: 340
title: "Dermatitis Atopik"
slug: "dermatitis-atopik"
icd_10: "L20.9"
category: "Penyakit Kulit dan Kelamin"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Dermatitis Atopik (ICD-10: L20.9)

**Kategori Medis**: Penyakit Kulit dan Kelamin  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Dermatitis atopik (eksim atopik) adalah penyakit inflamasi kulit kronik residif yang sangat gatal, ditandai dengan disfungsi sawar kulit (kerusakan barier filaggrin) dan sensitisasi imunologis, sering berhubungan dengan riwayat atopi pribadi atau keluarga (asma, rinitis alergi).

---

## 2. Gejala & Manifestasi Klinis
- Pruritus hebat (gatal adalah gejala kardinal)
- Lesi kulit eritema, papul, vesikel, eksudasi/krusta pada fase infantil (pipi dan ekstensor)
- Plak likenifikasi likenoid kering di fosa antekubiti dan poplitea pada fase anak dan dewasa
- Kulit kering difus (xerosis kutis)
- Dennie-Morgan fold (garis lipatan bawah mata)

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan berdasarkan Kriteria Hanifin dan Rajka (minimal 3 kriteria mayor: pruritus, morfologi dan distribusi khas, dermatitis kronik residif, riwayat atopi; ditambah minimal 3 kriteria minor).

---

## 4. Tatalaksana & Terapi
1. Pemulihan Sawar Kulit (Pilar Utama):
   - Pelembap (emolien/moisturizer seperti ceramide atau vaselin album) dioleskan tebal segera setelah mandi (rule of 3 minutes) minimal 2-3 kali sehari.
   - Mandi air suam-suam kuku dengan sabun ber-pH netral tanpa pewangi.
2. Farmakologis Anti-inflamasi Topikal (Saat Flare/Kambuh):
   - Kortikosteroid Topikal: Hidrokortison krim 1-2.5% untuk wajah dan lipatan anak; Mometason furoat 0.1% atau Betametason valerat 0.1% krim untuk badan dan ekstremitas selama 1-2 minggu.
   - Calcineurin inhibitor topikal (Takrolimus 0.03-0.1%) sebagai alternatif aman jangka panjang pada area wajah.
3. Antihistamin oral generasi ke-1 (Klorfeniramin/Hidroksizin) malam hari untuk efek sedatif pereda siklus gatal-garuk.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Dermatologi dan Venereologi (Sp.DV) bila dermatitis atopik luas resisten terapi topikal lini pertama, timbul komplikasi infeksi sekunder berat seperti eksema herpetikum (infeksi virus HSV luas), atau memerlukan fototerapi/terapi sistemik biologik.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
