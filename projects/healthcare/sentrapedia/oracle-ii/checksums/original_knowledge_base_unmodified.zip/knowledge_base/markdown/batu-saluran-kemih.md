---
id: 263
title: "Batu Saluran Kemih"
slug: "batu-saluran-kemih"
icd_10: "N20-N23"
category: "Penyakit Ginjal dan Saluran Kemih"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Batu Saluran Kemih (ICD-10: N20-N23)

**Kategori Medis**: Penyakit Ginjal dan Saluran Kemih  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Pada anak, terdapat terminologi khusus terkait dengan BSK, yaitu urolitiasis (didapatkan adanya batu dalam saluran kemih) dan nefrokalsinosis (deposisi kalsium secara menyeluruh di parenkim ginjal, terutama di area medulla ginjal). jdih.kemkes.go.id - 59 -

---

## 2. Gejala & Manifestasi Klinis
- pasien dewasa dengan gejala sugestif menetap dari batu buli-buli bila tidak ditemukan pada pemeriksaan USG Gunakan FPA untuk orang dewasa dengan batu buli- Lemah buli yang dikonfirmasi untuk memandu pilihan pengobatan dan tindak lanjut Semua pasien dengan batu buli-buli dapat diperiksa Lemah dan diselidiki penyebab pembentukan batu buli- bulinya, antara lain: • Uroflowmetri dan residu paska berkemih; • Dipstik urin, pH, ± biakan; • Penilaian metabolik dan analisis batu (lihat bagian 3.3.2.3 dan 4.1 dari European Association of Urology (EAU) guideline on urolithiasis untuk rincian lebih lanjut). Pada pasien tertentu, pertimbangkan: • Pencitraan saluran atas (pada pasien dengan riwayat urolitiasis atau nyeri pinggang); • Sisto-uretroskopi atau uretrogram. Tawarkan kemolitolisis oral untuk batu buli-buli Lemah asam urat yang radiolusen atau diketahui pada orang dewasa. Tawarkan orang dewasa dengan batu buli-buli Kuat vesikolitotripsi transuretra jika memungkinkan. Lakukan vesikolitotripsi transuretra dengan Lemah instrumen aliran kontinu pada orang dewasa (misalnya, nephroscope atau resectoscope) jika memungkinkan. Tawarkan kepada orang dewasa vesikolitotripsi Kuat perkutan di mana vesikolitotripsi transuretra tidak jdih.kemkes.go.id - 57 - Tingkat Rekomendasi Kekuatan memungkinkan atau tidak dianjurkan. Sarankan sistolitotomi terbuka sebagai pilihan untuk Lemah batu buli-buli yang sangat besar pada dewasa dan anak-anak Tawarkan kepada anak-anak dengan batu buli-buli Lemah vesikolitotripsi transuretra jika memungkinkan. Tawarkan kepada anak-anak vesikolitotripsi perkutan Lemah di mana vesikolitotripsi transuretra tidak mungkin atau berhubungan dengan risiko tinggi striktur uretra (misalnya, anak kecil, rekonstruksi uretra sebelumnya, dan cedera tulang belakang). Operasi terbuka, laparoskopi, dan SWL adalah Lemah alternatif tata laksana bila tata laksana endoskopi tidak dianjurkan pada orang dewasa dan anak-anak. Pilih prosedur “tubeless” (tanpa memasang kateter Lemah atau drain) untuk anak-anak dengan batu buli-buli primer dan tanpa infeksi, pembedahan, atau disfungsi buli-buli sebelumnya di mana sistolitotomi terbuka diindikasikan. Lakukan prosedur untuk batu dan BOO yang Kuat mendasarinya secara bersamaan pada orang dewasa dengan batu buli-buli sekunder untuk BOO, jika memungkinkan. Tindak lanjut pencitraan untuk setiap pasien Lemah dibedakan karena kurangnya bukti. Faktor-faktor yang mempengaruhi tindak lanjut termasuk • Apakah predisposisi fungsional yang mendasari pembentukan batu dapat diobati (misalnya, transurethral resection of the prostate). • Risiko metabolic.

---

## 3. Kriteria & Alur Diagnosis
Penegakan diagnosis BSK pada anak dilakukan melalui gambaran klinis, penggalian riwayat kelainan bawaan ginjal dan saluran kemih, prematuritas, diet (terutama yang mengandung oksalat, purin, kalsium, fosfat, garam, minuman kola, teh, susu dan minuman energi), gangguan pendengaran, dan penyakit BSK di keluarga (pada 40% kasus). Pemeriksaan jdih.kemkes.go.id - 60 - fisik yang menunjukkan adanya gangguan pertumbuhan, gambaran dismorfik atau tanda Rickets dapat menunjukkan adanya kelainan bawaan atau metabolik yang terkait nefrokalsinosis atau BSK. Kelainan metabolik terjadi pada 42-84% anak dengan BSK sehingga pemeriksaan evaluasi metabolik lengkap perlu dilakukan pada tiap anak dengan BSK, yaitu pemeriksaan biokimia urine 24 (dua puluh empat) jam (rasio kalsium/kreatinin urine, rasio kalsium/sitrat urine, oksalat urine 24 (dua puluh empat) jam, kalsium urine 24 (dua puluh empat) jam, asam urat urine 24 (dua puluh empat) jam) e. Tata laksana BSK anak 1) Konservatif (observasi) Penanganan BSK pada anak dapat berupa tala laksana konservatif, secara non-farmakologis dan farmakologis, serta tata laksana dengan pembedahan. Penatalaksanaan non-farmakologis mencakup melakukan diet sesuai dengan angka kecukupan gizi, terutama terkait dengan asupan cairan, natrium, kalsium, dan fosfor. Meskipun belum ada data yang jelas mengenai peran diet terhadap kejadian BSK pada anak, beberapa penelitian menunjukkan bahwa anak dengan BSK mengkonsumsi jumlah air yang lebih rendah dan kadar natrium lebih tinggi dibanding yang dianjurkan. Rekomendasi angka kecukupan gizi pada anak tercakup dalam Tabel 32. Tabel 32. Tabel kecukupan gizi pada anak Kelompok Air Kalsium Fosfor Natrium umur (mL) (mg) (mg) (mg) Bayi/anak 0 - 5 bulan 700 200 100 120 6 - 11 900 270 275 370 bulan 1 - 3 tahun 1.150 650 460 800 4 - 6 tahun 1.450 1.000 500 900 7 - 9 tahun 1.650 1.000 500 1.000 Laki-laki 10 - 12 1.850 1.200 1.250 1.300 jdih.kemkes.go.id - 61 - Kelompok Air Kalsium Fosfor Natrium umur (mL) (mg) (mg) (mg) tahun 13 - 15 2.100 1.200 1.250 1.500 tahun 16 - 18 2.300 1.200 1.250 1.700 tahun Perempuan 10 - 12 1.850 1.200 1.250 1.400 tahun 13 - 15 2.100 1.200 1.250 1.500 tahun 16 - 18 2.150 1.200 1.250 1.600 tahun Terapi konservatif non-farmakologis berupa expectant management ini digunakan untuk batu ginjal kaliks inferior, tunggal, dan tidak menyebabkan keluhan apapun, terutama pada pasien dengan batu selain struvit dan sistin berukuran < 7 mm, tanpa kelainan anatomi.

---

## 4. Tatalaksana & Terapi
medikamentosa. 4. Pengulangan analisis batu bila tersedia sampel baru, terutama bila respon terapi tidak adekuat. 5. Monitor pasien dengan batu struvit untuk kemungkinan reinfeksi bakteri dan penyusunan strategi pencegahan. jdih.kemkes.go.id - 68 - 6. Pemeriksaan radiologis (FPA, USG ginjal, CT-scan dosis rendah) follow-up rutin untuk menilai perkembangan ukuran batu maupun pembentukan batu baru. 7. Pada anak, dilakukan pemeriksaan USG ginjal dilakukan setelah 6 (enam) bulan, kemudian setiap tahun setelah pengangkatan BSK atau ekspulsi. jdih.kemkes.go.id - 69 - BAB IV SIMPULAN PNPK Batu Saluran Kemih merupakan pedoman yang memuat mulai dari anamnesis, pemeriksaan fisik, pemeriksaan penunjang, tata laksana umum dan spesifik (batu ginjal, batu ureter, batu buli-buli, batu residu, batu pada kehamilan, batu pada anak) baik secara konservatif, farmakologis, intervensi aktif yang minimal invasif, maupun operasi terbuka, hingga edukasi, prognosis, dan follow-up. PNPK ini dibuat dengan harapan dapat dijadikan sebagai acuan dalam penyusunan Panduan Praktik Klinis (PPK) dan atau clinical pathway yang disesuaikan dengan kondisi masing-masing fasilitas kesehatan. Sesuai dengan perkembangan dan kemajuan ilmu urologi di masa yang akan mendatang, perbaikan dan pemutakhiran akan terus dilakukan. MENTERI KESEHATAN REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Urologi / FKRTL apabila batu berukuran > 5 mm, nyeri kolik refrakter dengan analgesik primer, terdapat tanda urosepsis, hidronefrosis sedang-berat, atau anuria/gagal ginjal akut.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2022
