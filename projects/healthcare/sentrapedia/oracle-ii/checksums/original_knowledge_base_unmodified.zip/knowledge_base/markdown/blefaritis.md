---
id: 324
title: "Blefaritis"
slug: "blefaritis"
icd_10: "H01.0"
category: "Penyakit Mata"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Blefaritis (ICD-10: H01.0)

**Kategori Medis**: Penyakit Mata  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Blefaritis adalah peradangan kronik pada margo (tepi) kelopak mata. Blefaritis anterior melibatkan pangkal bulu mata (etiologi stafilokokus atau seboroik); blefaritis posterior melibatkan disfungsi kelenjar Meibom (MGD).

---

## 2. Gejala & Manifestasi Klinis
- Tepi kelopak mata merah, bengkak, dan gatal
- Keropeng/krusta kering seperti ketombe di pangkal bulu mata
- Sensasi terbakar dan mengganjal di mata
- Bulu mata rontok (madarosis) atau tumbuh ke dalam (trikiasis) pada kasus kronik

---

## 3. Kriteria & Alur Diagnosis
Pemeriksaan mata luar dengan slit lamp atau kaca pembesar/senter: eritema margo palpebra, krusta berminyak atau berkolom di dasar silia, teleangiektasis margo palpebra, orifisium kelenjar Meibom tersumbat busa.

---

## 4. Tatalaksana & Terapi
1. Kebersihan Kelopak Mata (Pilar Terapi Utama):
   - Kompres hangat 5-10 menit melunakkan sekret kelenjar.
   - Membersihkan tepi kelopak mata (eyelid scrub) menggunakan kain kasa/cotton bud yang dibasahi sampo bayi encer 1-2 kali sehari.
2. Farmakologis:
   - Salep mata antibiotik: Eritromisin 0.5% atau Kloramfenikol 1% dioleskan pada margo palpebra sebelum tidur selama 2-4 minggu.
   - Air mata buatan (artificial tears) untuk mengatasi mata kering penyerta.
   - Doksisiklin oral 1 x 50-100 mg/hari selama 4-8 minggu pada blefaritis posterior/MGD refrakter pada dewasa.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Mata bila timbul komplikasi keratitis marginal, trikiasis luas, ulkus kornea, kalazion multipel berulang, atau kecurigaan keganasan margo palpebra.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
