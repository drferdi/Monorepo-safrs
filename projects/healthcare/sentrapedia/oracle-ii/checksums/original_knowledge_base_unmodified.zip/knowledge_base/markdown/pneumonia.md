---
id: 211
title: "Pneumonia"
slug: "pneumonia"
icd_10: "J18"
category: "Penyakit Paru"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Pneumonia (ICD-10: J18)

**Kategori Medis**: Penyakit Paru  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
mikrobiologi. Respons klinis terlihat setelah 48 – 72 jam pertama pengobatan sehingga dianjurkan tidak merubah jenis antibiotik dalam kurun waktu tersebut kecuali terjadi perburukan yang nyata. Setelah ada hasil biakan darah atau bahan saluran napas bawah maka pemberian antibiotik empiris mungkin memerlukan modifikasi. Apabila hasil pengobatan telah memuaskan maka penggantian antibiotik tidak akan mengubah mortalitas tetapi bermanfaat bagi strategi deeskalasi. Bila hasil pengobatan tidak memuaskan maka modifikasi mutlak diperlukan sesuai hasil biakan dan kepekaan bakteri. Respons jdih.kemkes.go.id - 67 - klinis berhubungan dengan faktor pasien (seperti usia dan komorbid), faktor bakteri (seperti pola resisten, virulensi dan keadaan lain). Hasil biakan kuantitatif yang didapat dari bahan saluran napas

---

## 2. Gejala & Manifestasi Klinis
- E c. Dapat minum obat oral. M d. Fungsi gastrointestinal normal. E Pasien dapat menjalani perawatan rawat jalan apabila memenuhi K kriteria klinis stabil meliputi : a. Suhu < 37,80C. b. Frekuensi nadi < 125 x/menit. c. Frekuensi napas < 24 x/menit. d. Tekanan darah sistolik > 90 mmHg. e. Saturasi oksigen arteri > 90 % atau PO > 60 mmHg atau kembali 2 ke PO dasar pada pasien dengan riwayat hipoksemia kronik 2 jdih.kemkes.go.id - 40 - Tabel 10. Pilihan Antibiotik untuk Terapi Sulih pada Pneumonia Komunitas Obat oral yang dianjurkan Pilihan lain Golongan obat Antibiotik Bioavailabilitias Antibiotik Bioavailabilitias % % Fluorokuinolon Fluorokuinolon G2 Siprofloksasin Siprofloksasin 70-80 Fluorokuinolon G3 > 88 Levofloksasin Levofloksasin 99 N> 88 β-laktam+makrolid A β-laktam Ampisilin 30-55 Amoksisilin variabel T Ampisilin Penisilin V 74 – 92 A Amoksisilin/ 70 – 80 klavHulanat 74 - 92 Sefuroksim Sefuroksim 37-52 Sefaklor > 90 E Sefprozil > 95 S Sefadroksil > 90 EAmoksisilin/ 74 – 92 K klavulanat Fluorokuinolon G2 ≥ 88 N atau G3 TMP/SMZ > 90 A Fluorokuinolon G3 I Seftriakson S R efuroksim 37-52 ≥ 88 Sefotaksim Sefiksim 40 – 60 E Sefodoksim 50 T Seftibutin 70 – 90 N seftazidim, Sefuroksim 37 – 52 Fluorokuinolon G4 ≥ 88 E imipenem, M atau Piperasilin/ E Tazobaktam K Makrolid Eritromisin Eritromisin variabel Klaritromisin - 50 Azitromisin Azitromisin ~ 37 Fluorokuinolon G3 ≥ 88 Doksisiklin 60 - 90 Tetrasiklin Doksisiklin Doksisiklin 60 – 90 Makrolid Variabel Fluorokuinolon G3 > 88 Linkomisin Klindamisin Klindamisin 90 Metronidazol + β- Variabel laktam ≥ 88 jdih.kemkes.go.id - 41 - Sulfonamid Fluorokuinolon G4 TMP/SMZ TMP/SMZ 70 – 100 Variabel β-laktam ≥ 88 fluorokuinolon G2 Dikutip dari McEvoy GK et al. 6. Lama pengobatan Antibiotik (IV dan atau oral) umumnya diberikan selama toNtal 5-7 hari pada pasien pneumonia komunitas ringan-sedang tanpa Akomplikasi yang menunjukan perbaikan klinis. Tanda-tanda perbaikan klinis T adalah sebagai berikut: A a. Tidak memerlukan suplemen oksigen (kecuali untuk penyakit H dasarnya). E b. Tidak terdapat lebih dari satu tanda ketidakstabilan klinis seperti: S 1) Frekuensi nadi > 100 x/menit. E 2) Frekuensi napas > 24 x/menit. K 3) Tekanan darah sistolik ≤ 90 mmHg. Pemberian antibiotik dapat diNperpanjang (10-21 hari) bila:

---

## 3. Kriteria & Alur Diagnosis
/VAP adalah pada pemeriksaan radiologi A didapatkan opasitas/konsolidasi/infiltrat baru atau progresif (dapat I berupa kavitas dan pneumatocele) ditambah dengan 2 dari kriteria: R suhu tubuh > 38oC, sekret purulent, ronki atau suara napas E bronkial, leukositosis (leukosit >12.000/µL) atau leukopenia (leukosit T <4000/µL), dan saturasi memburuk (rekomendasi kuat, kualitas N bukti sedang). E 3. Idealnya rumah sakit membuat dan mendiseminasikan antibiogram, M jika memungkinkan ada antibiogram yang spesifik pada populasi Eperawatan intensif (rekomendasi kuat, kualitas bukti rendah). K4. Pengobatan empiris berdasarkan distribusi patogen lokal penyebab HAP atau VAP, sedapat mungkin menggunakan antibiotik spektrum sempit dengan mempertimbangkan faktor risiko dan klinis pasien agar dapat mencapai target dengan tepat dan mengurangi pemakaian antibiotik yang berlebihan (rekomendasi kuat, kualitas bukti rendah). 5. Pertimbangkan deeskalasi setelah diperoleh hasil biakan dan uji kepekaan dari spesimen yang berasal dari saluran napas bawah dan bila terdapat perbaikan respons klinis (rekomendasi kuat, kualitas bukti tinggi). jdih.kemkes.go.id - 72 - 6. Pada pasien terduga VAP, direkomendasikan antibiotik yang mencakup S. aureus, P. aeruginosa dan batang Gram negatif lainnya (rekomendasi kuat, kualitas bukti rendah). 7. Pemilihan antibiotik empiris pasien HAP dengan aktivitas terhadap P. aeruginosa dan bakteri Gram negatif lainnya termasuk Klebsiella pneumoniae dan Acinetobacter baumanii (rekomendasi kuat, kualitas bukti rendah). N

---

## 4. Tatalaksana & Terapi
A mikrobiologi dan hasil kepekaan bakteri terhadap antibiotik. T Pemilihan antibiotik pada HAP/VAP secara definitif (rekomendasi A kuat, kualitas bukti moderate). H 9. Durasi pemberian antibiotik untuk HAP/VAP adalah 7 hari. Durasi E ini diperpendek atau diperpanjang tergantung perbaikan klinis, hasil parameter laboratorium (rekomendasi kSuat, kualitas bukti rendah). E K MENTERI KESEHATAN N REPUBLIK INDONESIA, A I ttd. R E BUDI G. SADIKIN T N E M E K jdih.kemkes.go.id

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Rumah Sakit / FKRTL apabila memenuhi kriteria skor CURB-65 >= 2 (Confusion, Ureum > 7 mmol/L, Frekuensi napas >= 30x/menit, Tekanan darah S < 90 atau D <= 60 mmHg, Usia >= 65 tahun), saturasi oksigen perifer SpO2 < 92%, efusi pleura signifikan, kecurigaan syok septik, atau terdapat komorbiditas multipel berat tidak terkontrol.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK UNKNOWN
