---
id: 302
title: "Taeniasis"
slug: "taeniasis"
icd_10: "B68.9"
category: "Penyakit Infeksi"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Taeniasis (ICD-10: B68.9)

**Kategori Medis**: Penyakit Infeksi  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Taeniasis adalah infeksi usus oleh cacing pita Taenia saginata (cacing pita sapi) atau Taenia solium (cacing pita babi) akibat konsumsi daging mentah/setengah matang yang mengandung larva sistiserkus.

---

## 2. Gejala & Manifestasi Klinis
- Keluarnya segmen proglotid putih pipih bergerak aktif melalui anus atau ditemukan di pakaian dalam
- Gangguan pencernaan ringan: perut kembung, mual, penurunan berat badan
- Rasa lapar berlebihan atau anoreksia

---

## 3. Kriteria & Alur Diagnosis
Ditemukannya proglotid motil pada tinja atau pakaian dalam atau telur cacing pita bulat berdinding tebal bergaris radial pada pemeriksaan feses mikroskopis.

---

## 4. Tatalaksana & Terapi
1. Prazikuantel: 5-10 mg/kgBB oral dosis tunggal (lini pertama pilihan).
2. Alternatif: Albendazol 400 mg oral per hari selama 3 hari berturut-turut.
3. Edukasi memasak daging sapi dan babi hingga matang sempurna (suhu inti > 65°C).

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk CITO ke Spesialis Saraf / RS bila dicurigai koinfeksi Sistiserkosis / Neurosistiserkosis (akibat menelan telur Taenia solium): kejang onset baru, sakit kepala hebat, hidrosefalus, atau defisit neurologis fokal.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
