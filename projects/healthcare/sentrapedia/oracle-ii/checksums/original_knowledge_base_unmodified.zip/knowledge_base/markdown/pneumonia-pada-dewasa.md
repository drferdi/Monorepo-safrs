---
id: 249
title: "Pneumonia Pada Dewasa"
slug: "pneumonia-pada-dewasa"
icd_10: "J18"
category: "Penyakit Paru"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Pneumonia Pada Dewasa (ICD-10: J18)

**Kategori Medis**: Penyakit Paru  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Respons terhadap terapi dapat didefinisikan secara klinis maupun mikrobiologi. Respons klinis terlihat setelah 48 – 72 jam pertama pengobatan sehingga dianjurkan tidak merubah jenis antibiotik dalam kurun waktu tersebut kecuali terjadi perburukan yang nyata. Setelah ada hasil biakan darah atau bahan saluran napas bawah maka pemberian antibiotik empirik mungkin memerlukan modifikasi. Apabila hasil pengobatan telah memuaskan maka penggantian antibiotik tidak akan mengubah mortalitas tetapi bermanfaat bagi strategi deeskalasi. Bila hasil pengobatan tidak memuaskan maka modifikasi mutlak diperlukan sesuai hasil biakan dan kepekaan bakteri. Respons klinis berhubungan dengan faktor pasien (seperti usia dan komorbid), faktor bakteri (seperti pola resisten, virulensi dan keadaan lain). jdih.kemkes.go.id - 60 - Hasil biakan kuantitatif yang didapat dari bahan saluran napas

---

## 2. Gejala & Manifestasi Klinis
- di luar paru Sering Lebih jarang Apusan Gram Flora normal atau spesifik Kokus Gram (+) atau (-) Radiologis Patchy atau normal Konsolidasi lobar Laboratorium Leukosit normal kadang rendah Lebih tinggi Gangguan fungsi hati Sering Jarang Dikutip dari Mangunnegoro H. Antibiotik masih tetap merupakan pengobatan utama pada pneumonia termasuk pneumonia atipikal. Antibiotik terpilih pada pneumonia atipikal yang disebabkan oleh M. Pneumoniae, C. Pneumoniae dan Legionella spp. adalah golongan: Makrolid: azitromisin, klaritromisin. Fluorokuinolon respirasi: levofloksasin, moksifloksasin. I. Tata laksana rehabilitasi medik pada pasien pneumonia 1. Asesmen fungsional Spesialis Kedokteran Fisik dan Rehabilitasi (Sp.KFR) perlu melakukan asesmen terkait status fungsional pada pasien dengan pneumonia pada perawatan akut dan pasca-perawatan akut, di rawat jalan, rawat inap maupun di ICU, untuk menentukan program terapi. Gangguan fungsional yang mungkin terjadi dan asesmen yang perlu dilakukan mencakup: a. Asesmen kemampuan batuk: peak cough flow, refleks batuk. b. Asesmen kemampuan pengembangan paru dan fleksibilitas rongga dada: single breath count test/chest expansion dan lingkup gerak leher dan bahu. jdih.kemkes.go.id - 40 - c. Asesmen gangguan fungsi kardiorespirasi berupa uji kebugaran kardiorespirasi, uji jalan 6 menit, uji sepeda incremental, dan sit to stand test 30 seconds. d. Asesmen gangguan fungsi muskuloskeletal yang terdiri dari uji lingkup gerak sendi terkait postur batang tubuh, MRC muscle strength untuk menilai ICU-aquired weakness. e. Asesmen Aktivitas Kehidupan Sehari-hari (AKS) : Barthel Index, Functional Independence Measure, ICU Mobilty Scale. f. Asesmen vokasional (apabila diperlukan). g. Asesmen menelan dan produksi suara (sesuai indikasi). 2. Tata laksana rehabilitasi medik

---

## 3. Kriteria & Alur Diagnosis
/VAP adalah pada pemeriksaan radiologi didapatkan opasitas/konsolidasi/infiltrat baru atau progresif (dapat berupa kavitas dan pneumotocele) ditambah dengan 2 dari kriteria: suhu tubuh > 38oC, sekret purulent, ronki atau suara napas bronkial, leukositosis (leukosit >12.000/µL) atau leukopenia (leukosit <4000/µL), dan Saturasi memburuk (rekomendasi kuat, kualitas bukti sedang). 3. Idealnya rumah sakit membuat dan mendiseminasikan antibiogram, jika memungkinkan ada antibiogram yang spesifik pada populasi perawatan intensif (rekomendasi kuat, kualitas bukti rendah). 4. Pengobatan empirik berdasarkan distribusi patogen lokal penyebab HAP atau VAP, sedapat mungkin menggunakan antibiotik spektrum sempit dengan mempertimbangkan faktor risiko dan klinis pasien agar dapat mencapai target dengan tepat dan mengurangi pemakaian antibiotik yang berlebihan (rekomendasi kuat, kualitas bukti rendah). 5. Pertimbangkan deeskalasi setelah diperoleh hasil biakan dan uji kepekaan dari spesimen yang berasal dari saluran napas bawah dan bila terdapat perbaikan respons klinis (rekomendasi kuat, kualitas bukti tinggi). jdih.kemkes.go.id - 65 - 6. Pada pasien terduga VAP, direkomendasikan antibiotik yang mencakup S. Aureus, P. Aeruginosa dan batang Gram negatif lainnya (rekomendasi kuat, kualitas bukti rendah). 7. Pemilihan antibiotik empiris pasien HAP dengan aktivitas terhadap P. Aeruginosa dan bakteri Gram negatif lainnya termasuk Klebsiella pneumoniae dan Acinetobacter baumanii (rekomendasi kuat, kualitas bukti rendah).

---

## 4. Tatalaksana & Terapi
mikrobiologi dan hasil kepekaan bakteri terhadap antibiotik. Pemilihan antibiotik pada HAP/VAP secara definitif (rekomendasi kuat, kualitas bukti moderate). 9. Durasi pemberian antibiotik untuk HAP/VAP adalah 7 hari. Durasi ini diperpendek atau diperpanjang tergantung perbaikan klinis, hasil parameter laboratorium (rekomendasi kuat, kualitas bukti rendah). MENTERI KESEHATAN REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Rumah Sakit / FKRTL apabila memenuhi kriteria skor CURB-65 >= 2 (Confusion, Ureum > 7 mmol/L, Frekuensi napas >= 30x/menit, Tekanan darah S < 90 atau D <= 60 mmHg, Usia >= 65 tahun), saturasi oksigen perifer SpO2 < 92%, efusi pleura signifikan, kecurigaan syok septik, atau terdapat komorbiditas multipel berat tidak terkontrol.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2023
