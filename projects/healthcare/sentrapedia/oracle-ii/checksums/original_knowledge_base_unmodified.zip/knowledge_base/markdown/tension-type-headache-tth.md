---
id: 333
title: "Tension-Type Headache (TTH)"
slug: "tension-type-headache-tth"
icd_10: "G44.2"
category: "Penyakit Saraf"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Tension-Type Headache (TTH) (ICD-10: G44.2)

**Kategori Medis**: Penyakit Saraf  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Tension-Type Headache (nyeri kepala tegang) adalah bentuk nyeri kepala primer tersering, ditandai dengan nyeri kepala bilateral seperti diikat tali kencang atau ditekan beban berat di dahi/oksipital, berhubungan erat dengan stres psikologis, kelelahan, dan ketegangan otot perikranial.

---

## 2. Gejala & Manifestasi Klinis
- Nyeri kepala bilateral tumpul menekan atau mengikat (tight band-like)
- Intensitas ringan hingga sedang
- Nyeri tidak berdenyut dan tidak diperberat aktivitas fisik rutin (berjalan/naik tangga)
- Nyeri tekan pada otot perikranial (trapezius, leher, oksipital)
- Tidak disertai mual atau muntah hebat (bisa fotofobia ATAU fonofobia ringan, tidak keduanya)

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan berdasarkan kriteria diagnostik ICHD-3: minimal 10 episode nyeri kepala dengan karakteristik bilateral menekan, intensitas ringan-sedang, durasi 30 menit hingga 7 hari, tanpa mual/muntah, dan tidak diperberat aktivitas fisik.

---

## 4. Tatalaksana & Terapi
1. Terapi Abortif / Akut Lini Pertama:
   - Parasetamol 1000 mg oral per kali (maks 4000 mg/hari).
   - Ibuprofen 400 mg oral per kali atau Naproksen 500 mg oral.
   - Kombinasi analgesik + kafein oral.
2. Terapi Preventif (pada TTH kronik > 15 hari/bulan):
   - Amitriptilin 10-25 mg oral malam hari sebelum tidur, titrasi bertahap hingga 50-75 mg/hari.
3. Non-farmakologis: Manajemen stres, perbaikan postur tubuh kerja, teknik relaksasi otot, akupresur leher.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Saraf bila nyeri kepala tidak responsif terhadap terapi lini pertama, frekuensi semakin meningkat progresif, atau dicurigai red flags nyeri kepala (SNOOP: Systemic symptoms, Neurologic deficit, Onset mendadak thunderclap, Older age > 50 tahun, Positional).

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
