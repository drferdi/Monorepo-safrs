---
id: 250
title: "Glaukoma"
slug: "glaukoma"
icd_10: "H40-H42"
category: "Penyakit Mata"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Glaukoma (ICD-10: H40-H42)

**Kategori Medis**: Penyakit Mata  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Glaukoma adalah kelompok neuropati optik kronik progresif yang ditandai oleh atrofi papil saraf optik (ekskavasio glaukomatosa) dan penyempitan lapang pandang yang khas, yang umumnya (namun tidak selalu) berkaitan dengan peningkatan tekanan intraokular (TIO).

---

## 2. Gejala & Manifestasi Klinis
- yang lebih besar adalah gejala awal yang paling sering ditemukan jdih.kemkes.go.id - 115 - dan biasanya kedua tanda ini muncul pada 2 tahun pertama kehidupan jika tekanan intraokular terus meningkat. Buphthalmos adalah istilah yang digunakan untuk menggambarkan pembesaran mata bayi yang tidak biasa akibat peningkatan tekanan intraokular. Trias klasik yang sering ditemukan berupa epifora, fotofobia dan blefarospasme merupakan akibat terjadinya edema kornea yang berhubungan dengan rusaknya membran descemet yang disebut Haab striae. Kerusakan membran descemet ini biasanya terjadi dalam 2 tahun pertama kehidupan. Pada kondisi dimana tidak terjadi atrofi saraf optik, cupping dapat berkurang secara signifikan dengan diturunkannya tekanan intraokular dan akan membesar kembali jika tekanan intraokular tidak terkontrol. Atrofi saraf optik akibat peningkatan tekanan intraokular kronik dan berat bersifat irreversible. Untuk anak yang lebih tua usianya, biasanya datang dengan keluhan penurunan visus atau kondisi dimana mungkin terjadi glaukoma sekunder. Meskipun kelainan papil saraf optik bukan indikator pasti terjadinya glaukoma, tanda ini akan mendorong dilakukannya pemeriksaan yang menyeluruh. Hilangnya visus pada bayi dan anak-anak yang menderita glaukoma terjadi akibat perubahan patologik pada kornea dan kerusakan saraf optik. Selain itu, bisa juga terjadi akibat adanya gangguan refraksi.

---

## 3. Kriteria & Alur Diagnosis
glaukoma anak yang didiagnosis dan diterapi pada bulan pertama hingga tahun pertama kelahiran. b. Trabekulotomi dan Trabekulektomi Sama halnya dengan goniotomi, tingkat kesuksesan tindakan ini dilaporkan sekitar 70- 90% selama 2-9 tahun periode follow up setelah tindakan. Trabekulotomi mempunyai beberapa keuntungan dibandingkan goniotomi. Diantaranya trabekulotomi dapat dilakukan meski kornea tidak jernih (cloudy), terdapat ruptur dinding dalam kanal Schlem dan bila anyaman trabekulartidak dalam anatomi normal. Tidak memerlukan instrumen khusus, dilakukan sebagai operasi kecil (microsurgical) tanpa penggunaan lensa goniotomi. Menurut Mandal (2011) keberhasilan operasi trabekulotomi bergantung pada tipe kelainan sudut glaukoma pediatrik, bukan pada beratnya glaukoma ataupun ukuran diameter kornea. Dibandingkan dengan goniotomi yang dapat menurunkan TIO 64-77%, prosedur trabekulotomi dapat menurunkan TIO hingga 90%. Prosedur trabekulektomi lebih disukai bagi sebagian besar dokter spesialis mata, karena teknik ini lebih mudah dibandingkan goniotomi dan trabekulotomi. Akan tetapi, banyak peneliti tidak menyarankan untuk digunakan sebagai pilihan pertama (first-line procedure) dalam penanganan glaukoma pediatrik akibat angka komplikasi yang tinggi dan angka keberhasilan yang rendah. Akhirnya dikembangkan prosedur jdih.kemkes.go.id - 117 - gabungan trebekulotomi dan trabekulektomi. Dimana setelah dilakukan prosedur trabekulotomi, dilanjutkan dengan trabekulektomi.

---

## 4. Tatalaksana & Terapi
Pada kasus-kasus yang resisten ataupun tidak dapat dilakukan operasi, siklodestruksi menggunakan Nd:YAG laser, diode laser atau cyclocryotherapy dapat dijadikan pilihan dalam penanganan glaukoma pada anak. Teknik-teknik ini akan mengurangi produksi cairan akuos oleh prosesus siliaris. Angka keberhasilan cyclocryotherapy (processus siliar dibekukan melalui skera) sekitar 33% dengan tingkat komplikasi yang tinggi. Cyclocryotherapy ini perlu dilakukan secara berkala. Resiko ptisis dan kebutaan dapat mencapai 10%. Laser transkleral sikloablasi dengan Nd:YAG atau diode laser, mempunyai resiko komplikasi yang lebih kecil. Keberhasilan jangka pendek sekitar 50%. Hal ini juga memerlukan proses yang berulang, bukan hanya sekali terapi. jdih.kemkes.go.id - 119 - D. Obat Anti Glaukoma Tabel 4. Obat Anti Glaukoma jdih.kemkes.go.id - 120 - jdih.kemkes.go.id - 121 - jdih.kemkes.go.id - 122 - jdih.kemkes.go.id - 123 - E. Indikasi Rawat Inap Pada Penderita Glaukoma Penderita glaukoma dilakukan rawat inap dengan indikasi sebagai berikut: 1. Penderita glaukoma akut. 2. Operasi dengan anestesi umum. 3. Terdapat komplikasi intaoperasi yang membutuhkan pemantauan, misalnya perdarahan intraokular, glaukoma maligna, atau gangguan sistemik saat operasi atau perioperatif. 4. Penderita dengan rasa nyeri pasca operasi kategori VAS >4. Rekomendasi tatalaksana glaukoma sudut tertutup berdasarkan tingkat fasilitas pelayanan kesehatan Layanan Layanan Layanan Primer Sekunder Tersier Medikamentosa V V V Laser iridotomi / iridektomi V V Phacoemulsifikasi V V Trabekulektomi V V Phaco + Trabekulektomi V Phaco pasca trabekulektomi V Glaukoma implan V Rekomendasi tatalaksana glaukoma sudut terbuka berdasarkan tingkat fasilitas pelayanan kesehatan Layanan Layanan Layanan Primer Sekunder Tersier Medikamentosa V V V Laser trabekuloplasti V Phacoemulsifikasi V V Trabekulektomi V V Phaco + Trabekulektomi V Phaco pasca trabekulektomi V Glaukoma implant V jdih.kemkes.go.id - 124 - BAB VI PENUTUP Glaukoma adalah kelainan pada saraf mata yang ditandai dengan neuropati optik disertai hilangnya lapang pandang yang khas dengan peningkatan tekanan intraokular sebagai faktor risiko utama. Saat ini glaukoma menduduki urutan kedua penyebab kebutaan terbanyak di Indonesia dan dunia. Penyusunan Pedoman Nasional Pelayanan Kedokteran (PNPK) Tata Laksana Glaukoma ini diharapkan dapat memberikan panduan bagi fasilitas pelayanan kesehatan untuk menyusun Panduan Praktik Klinis (PPK) maupun Standar Prosedur Operasional (SPO). Penyusunan PPK maupun SPO harus sesuai dengan PNPK Tata Laksana Glaukoma ini dengan disesuaikan dengan kondisi di fasilitas pelayanan kesehatan. Selain itu, PNPK Tata Laksana Glaukoma dapat menjadi rekomendasi bagi tenaga medis baik dokter maupun dokter spesialis mata dalam menegakkan diagnosis dan penatalaksanaan kasus-kasus glaukoma. MENTERI KESEHATAN REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk SEGERA ke Dokter Spesialis Mata (Sp.M) pada dugaan glaukoma akut sudut tertutup (kegawatdaruratan mata) pasca-pemberian medikamentosa penurun TIO darurat. Rujuk elektif untuk evaluasi perimetri, gonioskopi, dan pertimbangan trabekulektomi/laser.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2023
