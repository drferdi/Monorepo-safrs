---
id: 322
title: "Hordeolum (Bintitan)"
slug: "hordeolum-bintitan"
icd_10: "H00.0"
category: "Penyakit Mata"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Hordeolum (Bintitan) (ICD-10: H00.0)

**Kategori Medis**: Penyakit Mata  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Hordeolum adalah infeksi supuratif akut fokal pada kelenjar di kelopak mata, paling sering disebabkan oleh bakteri Staphylococcus aureus. Hordeolum internum mengenai kelenjar Meibom; hordeolum eksternum mengenai kelenjar Zeiss atau Moll.

---

## 2. Gejala & Manifestasi Klinis
- Bintil kemerahan yang nyeri pada kelopak mata
- Nyeri berdenyut saat kelopak mata disentuh atau berkedip
- Edema dan eritema fokal palpebra
- Titik nanah kuning (pointing) di pangkal bulu mata atau konjungtiva tarsal

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan secara inspeksi dan palpasi kelopak mata: benjolan fokal eritematosa yang nyeri tekan akut pada margo palpebra (eksternum) atau pada konjungtiva tarsal saat kelopak dieversi (internum).

---

## 4. Tatalaksana & Terapi
1. Kompres hangat pada kelopak mata selama 10-15 menit 3-4 kali sehari (mempercepat lisis bekuan sebum dan drainase spontan).
2. Antibiotik Salep Mata:
   - Kloramfenikol 1% salep mata atau Oksitetrasiklin 1% salep mata dioleskan 3 kali sehari pada lesi selama 5-7 hari.
3. Analgesik oral: Parasetamol 500 mg prn bila nyeri.
4. Jangan memencet atau menusuk benjolan sendiri.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Mata bila lesi besar tidak mengalami resolusi setelah 1-2 minggu (membutuhkan insisi drainase), berkembang menjadi selulitis preseptal palpebra, atau lesi mengeras menjadi kalazion kronik.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
