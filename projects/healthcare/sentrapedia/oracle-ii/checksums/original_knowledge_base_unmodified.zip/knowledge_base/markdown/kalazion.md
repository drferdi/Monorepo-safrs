---
id: 323
title: "Kalazion"
slug: "kalazion"
icd_10: "H00.1"
category: "Penyakit Mata"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Kalazion (ICD-10: H00.1)

**Kategori Medis**: Penyakit Mata  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Kalazion adalah peradangan granulomatosa kronik non-infeksius pada kelenjar Meibom yang tersumbat, menyebabkan retensi lipid (lipogranuloma), sering berkembang dari hordeolum internum yang tidak sembuh sempurna.

---

## 2. Gejala & Manifestasi Klinis
- Benjolan keras tidak nyeri pada kelopak mata
- Tidak ada tanda radang akut (tidak merah, tidak nyeri tekan)
- Benjolan membesar lambat selama berminggu-minggu/bulan
- Dapat menimbulkan astigmatisma ringan bila benjolan besar menekan kornea

---

## 3. Kriteria & Alur Diagnosis
Inspeksi dan palpasi: nodul keras berbatas tegas, terfiksir pada lempeng tarsus, tanpa rasa nyeri tekan. Eversi palpebra memperlihatkan lesi berwarna merah keabuan atau kekuningan di konjungtiva tarsal.

---

## 4. Tatalaksana & Terapi
1. Konservatif (Lesi Dini/Kecil):
   - Kompres hangat 10-15 menit 3-4 kali sehari diikuti pemijatan lembut ke arah tepi kelopak mata.
   - Menjaga kebersihan margo palpebra dengan sampo bayi encer (eyelid hygiene).
2. Medikamentosa: Salep mata antibiotik-steroid kombinasi bila ada inflamasi sekitar.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Mata bila kalazion berukuran besar menetap > 4-6 minggu untuk tindakan bedah insisi dan kuretase kalazion dari sisi konjungtiva tarsal, atau bila berulang pada lansia (waspada karsinoma kelenjar sebasea).

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
