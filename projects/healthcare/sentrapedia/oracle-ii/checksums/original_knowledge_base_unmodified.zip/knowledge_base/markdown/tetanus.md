---
id: 332
title: "Tetanus"
slug: "tetanus"
icd_10: "A35"
category: "Penyakit Infeksi"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Tetanus (ICD-10: A35)

**Kategori Medis**: Penyakit Infeksi  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Tetanus adalah penyakit infeksi akut sistem saraf yang disebabkan oleh eksotoksin tetanospasmin dari bakteri anaerob Clostridium tetani yang masuk melalui luka tercemar tanah/karat, ditandai dengan rigiditas otot dan spasme paroksismal tanpa gangguan sensorik.

---

## 2. Gejala & Manifestasi Klinis
- Trismus (kejang otot pengunyah / rahang terkunci)
- Risus sardonicus (senyum seringai khas akibat spasme otot fasial)
- Kaku kuduk dan opistotonus (punggung melengkung kaku ke belakang)
- Perut teraba keras seperti papan (defans muskular volunteer)
- Spasme paroksismal nyeri yang dipicu rangsang suara, sentuhan, atau cahaya

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan murni secara klinis dari riwayat luka tercemar dan trias trismus + risus sardonicus + spasme refleksif. Spatula test positif (penyentuhan dinding posterior faring memicu spasme otot masseter menggigit spatula).

---

## 4. Tatalaksana & Terapi
1. Netralisasi Toksin Bebas Segera:
   - Human Tetanus Immunoglobulin (HTIG) 3.000-6.000 IU IM dosis tunggal, ATAU Anti-Tetanus Serum (ATS) 100.000 IU (setengah IM, setengah IV) didahului skin test.
2. Eradikasi Kuman Sumber Toksin:
   - Metronidazol 3 x 500 mg IV selama 7-10 hari (lini pertama pilihan), ATAU Penisilin Prokain 1.2-2.4 juta IU/hari IM.
   - Debridemen bedah luka kotor setelah antitoksin diberikan.
3. Pengendalian Spasme & Kejang:
   - Diazepam infus titrasi 100-300 mg/hari dalam larutan dekstrosa atau bolus IV 10 mg setiap 3-4 jam.
4. Imunisasi Tetanus Toksoid (TT) pada sisi tubuh berbeda.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk SEGERA (CITO ambulans dengan monitor) ke ICU Rumah Sakit Rujukan untuk perawatan isolasi ruang gelap/tenang dan kesiapan intubasi trakeostomi mekanik ventilator bila terjadi spasme laring/apnea.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
