---
id: 161
title: "Diabetes Melitus Pada Anak"
slug: "diabetes-melitus-pada-anak"
icd_10: "E14"
category: "Penyakit Anak"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Diabetes Melitus Pada Anak (ICD-10: E14)

**Kategori Medis**: Penyakit Anak  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
mendefinisikan hipoglikemia dengan menggunakan suatu angka tertentu. Nilai ambang glikemik untuk timbulnya gejala, disfungsi susunan saraf pusat (SSP), dan hormonal counter regulation bervariasi untuk setiap individu dan di individu yang sama. Menurut ISPAD kadar glukosa darah < 70 mg/dL direkomendasikan untuk digunakan sebagai nilai batasan untuk mengidentifikasi dan memulai tata laksana hipoglikemia pada anak dengan diabetes. b) Gejala dan tanda Manifestasi klinis hipoglikemia terjadi akibat aktivasi otonom (gejala adrenergik) dan/atau disfungsi neurologis, karena turunnya kadar glukosa di otak (gejala neuroglikopenia) seperti terlihat di Tabel 10. Bila

---

## 2. Gejala & Manifestasi Klinis
- gula darah perifer perlu dilakukan lebih sering bila timbul gejala hiper atau hipoglikemia, atau anak sedang sakit. (GRADE C) Rekomendasi Komplikasi kronik pada anak DM tipe-2 meliputi komplikasi mikrovaskular dan makrovaskular. (GRADE A) Skrining komplikasi mikrovaskular (nefropati, retinopati, neuropati) dimulai

---

## 3. Kriteria & Alur Diagnosis
umur 11 tahun atau 5 tahun setelah diagnosis ditegakkan dengan pemeriksaan profil lipid setiap 2 tahun. (GRADE C) Skrining komplikasi yang lain (terkait penyakit autoimun lainnya) tergantung pada gejala yang muncul. (GRADE C) Pemantauan pertumbuhan, berat badan, dan perkembangan pubertas merupakan hal yang harus dilakukan. (GRADE C) Skrining komorbiditas dan komplikasi DM tipe-2 dilakukan pada awal diagnosis. (GRADE A) jdih.kemkes.go.id - 118 - Komorbiditas atau komplikasi yang sering terjadi pada DM tipe-2 dan harus diwaspadai adalah obesitas, hipertensi, nefropati, dislipidemia, aterosklerosis dan disfungsi vaskular, sindroma ovarium polikistik, non-alcoholic fatty liver disease, inflamasi sistemik, obstructive sleep apnea (OSA), neuropati, dan retinopati. (GRADE A). Manajemen komorbiditas dan komplikasi DM tipe-2 sebaiknya dilaksanakan bersama dengan bidang lain yang terkait. (GRADE C) jdih.kemkes.go.id - 119 - BAB V PENUTUP Diabetes melitus pada anak merupakan penyakit kronik yang memerlukan penanganan komprehensif dan multidisiplin. Upaya diagnosis, tata laksana, serta pemantauan komplikasi sangat penting untuk mencapai sasaran dan tujuan pengelolaan diabetes melitus pada anak yaitu mengurangi angka mortalitas dan meningkatkan kualitas hidup. Kontrol metabolik dapat dicapai melalui pengelolaan diabetes melitus pada anak meliputi pemberian insulin dan/atau obat oral, pengaturan makan, olahraga, dan edukasi yang didukung oleh pemantauan mandiri. Faktor pendidikan, sosio-ekonomi, dan kultur kepercayaan merupakan beberapa faktor yang berperan dalam keberhasilan pengelolaan diabetes melitus pada anak. Pedoman Nasional Pelayanan Klinis ini diharapkan dapat menjadi dasar rekomendasi bagi fasilitas pelayanan kesehatan. MENTERI KESEHATAN REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 4. Tatalaksana & Terapi
metformin merupakan indikasi terapi kombinasi dengan penambahan insulin basal. (GRADE A) jdih.kemkes.go.id - 117 - Kegagalan mencapai target HbA1c <7% setelah pemberian kombinasi metformin dan insulin basal (sampai dosis 1,5 IU/kgBB), merupakan pertimbangan untuk menambahkan insulin bolus kerja pendek sebelum makan. (GRADE B) Rekomendasi Target kadar HbA1c pada DM tipe-2 adalah <7% (< 53 mmol/mol). (GRADE C) Pemeriksaan kadar glukosa darah perifer (fingerstick) harian pada DM tipe-2 bersifat individual. (GRADE C) Monitor HbA1c pada DM tipe-2 setiap 3-6 bulan tergantung hasil kontrol metabolik yang dicapai. Bila HbA1C >7% atau menggunakan insulin, HbA1c harus diperiksa setiap 3 bulan. (GRADE C) Monitor gula darah perifer pada DM tipe-2 dilakukan dengan teratur sesuai rejimen manajemen yang digunakan. (GRADE C)

---

## 5. Kriteria Rujukan (FKRTL)
terstandar dan rujukan ke dokter dengan kompetensi di bidang respirologi. 8) Sindrom Ovarium Polikistik (SPOK) SPOK merupakan bagian dari sindrom resistensi insulin. Pada SPOK terjadi hyperandrogenism ovarium. Remaja dengan SPOK mempunyai tingkat resistensi insulin 40% lebih tinggi daripada mereka yang tidak mengalami hiperandrogen.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2024
