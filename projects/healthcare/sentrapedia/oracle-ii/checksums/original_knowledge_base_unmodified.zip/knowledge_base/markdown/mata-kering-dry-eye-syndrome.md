---
id: 325
title: "Mata Kering (Dry Eye Syndrome)"
slug: "mata-kering-dry-eye-syndrome"
icd_10: "H04.1"
category: "Penyakit Mata"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Mata Kering (Dry Eye Syndrome) (ICD-10: H04.1)

**Kategori Medis**: Penyakit Mata  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Dry eye syndrome (keratokonjungtivitis sika) adalah penyakit multifaktorial permukaan bola mata yang ditandai dengan hilangnya homeostasis lapisan air mata (tear film), disertai hiperosmolaritas, inflamasi, dan kerusakan epitel permukaan okular.

---

## 2. Gejala & Manifestasi Klinis
- Mata terasa kering, berpasir, dan perih terbakar
- Mata merah intermiten
- Sensasi ada benda asing di mata
- Penglihatan buram fluktuatif yang membaik setelah berkedip
- Paradoxical tearing (mata berair berlebihan akibat refleks iritasi)

---

## 3. Kriteria & Alur Diagnosis
Pemeriksaan klinis FKTP: Tear Break-Up Time (TBUT) dengan fluoresin < 10 detik menunjukkan instabilitas air mata, Tes Schirmer I tanpa anestesi < 5-10 mm dalam 5 menit menunjukkan defisiensi produksi air mata.

---

## 4. Tatalaksana & Terapi
1. Modifikasi lingkungan: Istirahatkan mata secara berkala (aturan 20-20-20 saat menatap layar komputer), hindari paparan langsung angin AC/kipas angin, gunakan kacamata pelindung.
2. Farmakologis:
   - Tetes mata air mata buatan (artificial tears) bebas pengawet (Carboxymethylcellulose 0.5% atau Sodium Hyaluronate 0.1%) 4-6 kali sehari atau lebih sering prn.
   - Gel mata pelumas sebelum tidur untuk retensi air mata malam hari.
   - Suplemen asam lemak omega-3 oral.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Mata bila gejala berat tidak membaik dengan air mata buatan, timbul defek epitel kornea/keratitis pungtata masif, atau dicurigai penyakit autoimun sistemik (Sjogren syndrome, Rheumatoid arthritis).

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
