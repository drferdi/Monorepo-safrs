---
id: 344
title: "Kandidiasis Kutis"
slug: "kandidiasis-kutis"
icd_10: "B37.2"
category: "Penyakit Kulit dan Kelamin"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Kandidiasis Kutis (ICD-10: B37.2)

**Kategori Medis**: Penyakit Kulit dan Kelamin  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Kandidiasis kutis adalah infeksi jamur pada kulit dan kuku yang disebabkan oleh spesies Candida (terutama Candida albicans), terutama menyerang area lipatan kulit yang hangat dan lembap (intertriginosa: lipat paha, ketiak, inframamaria, sela jari).

---

## 2. Gejala & Manifestasi Klinis
- Gatal hebat dan rasa terbakar pada lipatan kulit
- Plak eritematosa merah cerah berbatas tegas dengan maserasi basah
- Lesi satelit yang khas: papul dan pustul kecil merah di sekeliling tepi plak utama

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan dari gambaran lesi satelit khas pada area intertriginosa. Konfirmasi mikroskopis kerokan kulit dengan KOH 10-20% atau pewarnaan Gram memperlihatkan sel ragi bertunas (budding yeast), blastospora, dan pseudohifa jamur.

---

## 4. Tatalaksana & Terapi
1. Menjaga area lipatan tetap kering dan bersih (menggunakan bedak tabur penyerap pasca sembuh).
2. Antijamur Topikal:
   - Mikonazol krim 2%, Klotrimazol krim 1%, atau Ketokonazol krim 2% dioleskan 2 kali sehari selama 2-3 minggu.
   - Nistatin salep/krim dioleskan 2-3 kali sehari.
3. Antijamur Oral (pada lesi luas atau penderita diabetes/imunokompromais):
   - Flukonazol 1 x 150 mg oral per minggu selama 2-4 minggu, atau Itrakonazol 1 x 100-200 mg/hari selama 1-2 minggu.
4. Kontrol gula darah pada penderita diabetes melitus.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Kulit / Penyakit Dalam bila kandidiasis kutis resisten terapi luas berulang, dicurigai kandidiasis mukokutan kronik atau imunodefisiensi berat.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
