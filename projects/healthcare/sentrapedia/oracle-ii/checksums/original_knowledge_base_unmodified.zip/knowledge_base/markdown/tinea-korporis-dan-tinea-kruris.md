---
id: 342
title: "Tinea Korporis dan Tinea Kruris"
slug: "tinea-korporis-dan-tinea-kruris"
icd_10: "B35.4"
category: "Penyakit Kulit dan Kelamin"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Tinea Korporis dan Tinea Kruris (ICD-10: B35.4)

**Kategori Medis**: Penyakit Kulit dan Kelamin  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Tinea adalah infeksi jamur dermatofit superfisial (Trichophyton, Microsporum, Epidermophyton) pada jaringan berkeratin. Tinea korporis mengenai kulit tubuh berambut halus (badan, leher, ekstremitas); Tinea kruris mengenai lipat paha, perineum, dan gluteus.

---

## 2. Gejala & Manifestasi Klinis
- Gatal hebat terutama saat berkeringat
- Bercak merah bersisik berbentuk anular (cincin) bulat/lonjong dengan bagian tepi lebih aktif dan meninggi (central healing)
- Lesi polisiklik berbatas tegas dengan papul dan skuama di tepi

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan dari efloresensi khas tepi aktif central healing. Konfirmasi laboratorium FKTP: kerokan skuama tepi lesi dengan larutan KOH 10-20% memperlihatkan hifa panjang bersepta (true hyphae) bercabang dan artrospora.

---

## 4. Tatalaksana & Terapi
1. Antijamur Topikal (Lini Pertama untuk lesi terbatas):
   - Mikonazol krim 2%, Klotrimazol krim 1%, Ketokonazol krim 2%, atau Terbinafin krim 1% dioleskan 2 kali sehari pada lesi hingga 2 cm ke luar batas lesi selama minimal 2-4 minggu (lanjutkan 1 minggu setelah lesi sembuh klinis).
2. Antijamur Sistemik Oral (bila lesi luas, multipel, atau refrakter):
   - Griseofulvin: 500 mg/hari oral (dewasa) atau 10-20 mg/kgBB/hari selama 2-4 minggu bersama makanan berlemak, ATAU
   - Ketokonazol 200 mg/hari oral selama 2-4 minggu (monitor fungsi hati), ATAU Itrakonazol 1 x 100 mg/hari selama 2 minggu.
3. Edukasi menjaga area lipatan tetap kering, tidak memakai pakaian ketat basah, dan handuk terpisah.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Kulit dan Kelamin bila tinea insognito (lesi terdistorsi akibat salah penggunaan kortikosteroid topikal), keterlibatan folikel rambut dalam (Majocchi granuloma), atau resisten terhadap antijamur oral.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
