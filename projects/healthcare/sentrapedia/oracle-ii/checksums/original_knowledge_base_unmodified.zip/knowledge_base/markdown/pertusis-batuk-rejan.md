---
id: 308
title: "Pertusis (Batuk Rejan)"
slug: "pertusis-batuk-rejan"
icd_10: "A37.9"
category: "Penyakit Anak"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Pertusis (Batuk Rejan) (ICD-10: A37.9)

**Kategori Medis**: Penyakit Anak  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Pertusis (whooping cough / batuk seratus hari) adalah infeksi bakteri akut saluran napas yang sangat menular yang disebabkan oleh Bordetella pertussis, ditandai dengan serangan batuk paroksismal hebat diakhiri suara tarikan napas melengking (whoop).

---

## 2. Gejala & Manifestasi Klinis
- Stadium kataral (1-2 minggu): batuk ringan, pilek, bersin, demam subfebris
- Stadium paroksismal (2-6 minggu): batuk paroksismal beruntun (staccato cough) 5-15 kali tanpa henti, tarikan napas dalam bernada tinggi (whoop), muntah pasca-batuk (post-tussive emesis), sianosis perioral saat batuk
- Stadium konvalesen: batuk berkurang bertahap selama berminggu-minggu

---

## 3. Kriteria & Alur Diagnosis
Diagnosis klinis ditegakkan dari riwayat batuk paroksismal khas > 2 minggu dengan whoop inspiratorik atau post-tussive emesis, terutama pada anak tanpa imunisasi DTP lengkap. Penunjang laboratorium: leukositosis nyata (20.000-50.000/uL) dengan limfositosis absolut dominan.

---

## 4. Tatalaksana & Terapi
1. Antibiotik Makrolida Lini Pertama (efektif mengeliminasi kuman bila diberikan dini):
   - Azitromisin: 10 mg/kgBB/hari oral dosis tunggal pada hari ke-1 (maks 500 mg), dilanjutkan 5 mg/kgBB/hari pada hari 2-5 (maks 250 mg).
   - Alternatif: Eritromisin 40-50 mg/kgBB/hari oral dibagi 4 dosis selama 14 hari, atau Klaritromisin 15 mg/kgBB/hari dibagi 2 dosis selama 7 hari.
2. Suportif: oksigenasi, menjaga jalan napas, asupan nutrisi porsi kecil sering pasca-muntah.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk SEGERA ke RS / ruang rawat intensif anak bila terjadi pada bayi usia < 6 bulan, episode apnea, sianosis berat, kejang hipoksik, pneumonia sekunder, atau ensefalopati pertusis.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
