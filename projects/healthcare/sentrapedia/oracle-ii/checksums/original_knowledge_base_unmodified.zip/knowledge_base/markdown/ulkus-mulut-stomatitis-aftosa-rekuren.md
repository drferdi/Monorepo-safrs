---
id: 304
title: "Ulkus Mulut (Stomatitis Aftosa Rekuren)"
slug: "ulkus-mulut-stomatitis-aftosa-rekuren"
icd_10: "K12.0"
category: "Penyakit Pencernaan"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Ulkus Mulut (Stomatitis Aftosa Rekuren) (ICD-10: K12.0)

**Kategori Medis**: Penyakit Pencernaan  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Stomatitis Aftosa Rekuren (SAR / sariawan) adalah lesi ulseratif mukosa rongga mulut yang berulang, nyeri, berbatas tegas dengan dasar nekrotik putih-kekuningan dan halo eritematosa, sering dipicu trauma lokal, stres, defisiensi nutrisi, atau faktor genetik.

---

## 2. Gejala & Manifestasi Klinis
- Nyeri pada mukosa mulut (bibir dalam, pipi dalam, lidah)
- Nyeri saat makan, minum, atau berbicara
- Ulkus bulat dangkal berbatas merah dengan membran sentral putih-abu-abu

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan secara klinis dari riwayat rekurensi ulkus dan morfologi khas tipe minor (< 10 mm, sembuh 7-14 hari tanpa jaringan parut) atau tipe mayor (> 10 mm).

---

## 4. Tatalaksana & Terapi
1. Non-farmakologis: Menjaga higienitas mulut, hindari makanan pedas, asam, asin, dan bergerigi tajam.
2. Farmakologis Topikal:
   - Antiseptik kumur: Klorheksidin glukonat 0.1-0.2% kumur 2-3 kali sehari.
   - Anestesi topikal: Gel lidokain 2% dioleskan pada lesi sebelum makan untuk mengurangi rasa nyeri.
   - Kortikosteroid topikal: Triamsinolon asetonid pasta oral 0.1% dioleskan tipis pada lesi 2-3 kali sehari pasca makan.
3. Suplementasi vitamin B kompleks, vitamin C, asam folat, dan zat besi bila dicurigai defisiensi.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Penyakit Mulut / Bedah Mulut bila ulkus tidak sembuh setelah > 3 minggu (waspada karsinoma sel skuamosa rongga mulut), ulkus sangat besar multipel, atau dicurigai manifestasi penyakit sistemik (Behcet disease, Crohn disease).

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
