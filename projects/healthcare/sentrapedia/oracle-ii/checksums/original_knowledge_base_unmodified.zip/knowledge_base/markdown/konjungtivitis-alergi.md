---
id: 321
title: "Konjungtivitis Alergi"
slug: "konjungtivitis-alergi"
icd_10: "H10.1"
category: "Penyakit Mata"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Konjungtivitis Alergi (ICD-10: H10.1)

**Kategori Medis**: Penyakit Mata  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Konjungtivitis alergi adalah reaksi inflamasi konjungtiva bilateral yang diperantarai oleh reaksi imun hipersensitivitas tipe I terhadap alergen lingkungan (debu, serbuk sari, bulu hewan).

---

## 2. Gejala & Manifestasi Klinis
- Gatal hebat pada kedua mata (gejala kardinal)
- Mata merah berair
- Kelopak mata bengkak (kemosis)
- Sekret mukoid bening bertali (stringy discharge)
- Papil konjungtiva tarsal superior (cobblestone appearance pada konjungtivitis vernal)

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan dari gatal mata bilateral yang dominan dengan riwayat atopi. Pemeriksaan fisik: injeksi konjungtiva, kemosis, sekret mukoid serosa, dan hipertrofi papil konjungtiva tarsal.

---

## 4. Tatalaksana & Terapi
1. Menghindari paparan alergen pencetus dan kompres dingin kelopak mata.
2. Farmakologis Topikal:
   - Tetes mata antihistamin + mast cell stabilizer: Olopatadin 0.1% 2 kali sehari atau Ketotifen 0.025% 2 kali sehari.
   - Tetes mata mast cell stabilizer murni: Natrium Kromoglikat 2% 4 kali sehari.
   - Air mata buatan (artificial tears) untuk membilas alergen dari permukaan konjungtiva.
   - Antihistamin oral generasi ke-2 (Setirizin/Loratadin) bila disertai rinitis alergi.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Mata bila dicurigai Konjungtivitis Vernal berat dengan keterlibatan kornea (shield ulcer, Horner-Trantas dots) atau memerlukan terapi kortikosteroid topikal jangka panjang yang memerlukan pemantauan TIO.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
