---
id: 298
title: "Hepatitis A"
slug: "hepatitis-a"
icd_10: "B15.9"
category: "Penyakit Infeksi"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Hepatitis A (ICD-10: B15.9)

**Kategori Medis**: Penyakit Infeksi  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Hepatitis A adalah infeksi hati akut menular yang disebabkan oleh Hepatitis A Virus (HAV), ditularkan melalui rute fekal-oral melalui makanan atau air tercemar, bersifat swasirna (self-limiting) dan tidak berkembang menjadi hepatitis kronik.

---

## 2. Gejala & Manifestasi Klinis
- Fase prodromal: demam ringan, malaise hebat, mual, muntah, anoreksia, nyeri perut kanan atas
- Fase ikterik: sklera dan kulit kuning (ikterus), urin berwarna gelap pekat seperti air teh, feses pucat (dempul)
- Gatal-gatal pada kulit (pruritus)
- Hepatomegali lunak dan nyeri tekan

---

## 3. Kriteria & Alur Diagnosis
Diagnosis ditegakkan dari gejala klinis ikterus akut didahului gejala flu-like prodromal. Pemeriksaan laboratorium FKTP: peningkatan enzim transaminase hati (SGPT/ALT dan SGOT/AST meningkat signifikan > 5-10 kali lipat batas atas normal), hiperbilirubinemia direk dan total. Diagnosis serologis konfirmasi: IgM anti-HAV positif dalam darah.

---

## 4. Tatalaksana & Terapi
1. Terapi bersifat suportif dan simtomatik: Tirah baring selama fase akut ikterik, asupan nutrisi tinggi kalori dan cairan adekuat, hindari makanan tinggi lemak saat mual.
2. Medikamentosa: Antiemetik (domperidone/ondansetron) bila mual persisten, antipiretik parasetamol (dosis dikurangi maksimal 2 g/hari untuk mencegah hepatotoksisitas). Hindari obat-obatan hepatotoksik dan alkohol.
3. Edukasi kebersihan makanan, isolasi sanitasi alat makan, dan vaksinasi kontak erat.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk segera ke FKRTL bila terjadi komplikasi gagal hati akut (hepatitis fulminan: ensefalopati hepatikum, pemanjangan waktu protrombin INR > 1.5, penurunan kesadaran, asteriksis), muntah persisten dengan dehidrasi berat, atau hiperbilirubinemia persisten > 4 minggu.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
