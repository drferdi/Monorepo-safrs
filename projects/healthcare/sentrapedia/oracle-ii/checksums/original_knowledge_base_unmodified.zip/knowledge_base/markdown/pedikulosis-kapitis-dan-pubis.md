---
id: 346
title: "Pedikulosis Kapitis dan Pubis"
slug: "pedikulosis-kapitis-dan-pubis"
icd_10: "B85.0"
category: "Penyakit Kulit dan Kelamin"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Pedikulosis Kapitis dan Pubis (ICD-10: B85.0)

**Kategori Medis**: Penyakit Kulit dan Kelamin  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Pedikulosis adalah infeksi ektoparasit obligat yang mengisap darah manusia. Pedikulosis kapitis disebabkan oleh kutu kepala Pediculus humanus var. capitis; Pedikulosis pubis (phthiriasis) disebabkan oleh kutu Pthirus pubis pada rambut pubis.

---

## 2. Gejala & Manifestasi Klinis
- Gatal hebat pada kulit kepala dan area retroaurikular (kapitis) atau area genital (pubis)
- Ekskoriasi lecet kulit akibat garukan dengan risiko infeksi sekunder impetigo
- Telur kutu (nits) putih keabuan menempel erat pada batang rambut
- Kutu dewasa terlihat bergerak merayap di rambut
- Maculae caeruleae (bercak abu-abu kebiruan pada kulit paha/perut pada pedikulosis pubis)

---

## 3. Kriteria & Alur Diagnosis
Inspeksi visual teliti rambut kepala atau pubis: ditemukannya telur kutu (nits) yang melekat kuat pada batang rambut (tidak mudah rontok seperti ketombe) atau visualisasi kutu dewasa motil menggunakan sisir serit (fine-toothed comb).

---

## 4. Tatalaksana & Terapi
1. Pedikulosid Topikal Lini Pertama:
   - Permetrin losion 1%: dioleskan pada rambut dan kulit kepala yang telah dikeramasi, diamkan selama 10 menit, lalu dibilas bersih. Diulang setelah 7-10 hari untuk membunuh kutu baru menetas.
   - Alternatif: Malation losion 0.5% didiamkan selama 8-12 jam.
2. Sisir serit rambut basah untuk mengeluarkan telur dan kutu mati.
3. Pedikulosis pubis: cukur rambut pubis dan obati pasangan seksual serentak.
4. Cuci seprai dan topi dengan air panas.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Kulit bila infestasi kutu menyebar luas ke bulu mata (phthiriasis palpebrarum), infeksi sekunder impetigo meluas dengan limfadenitis servikal supuratif, atau resistensi permetrin.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
