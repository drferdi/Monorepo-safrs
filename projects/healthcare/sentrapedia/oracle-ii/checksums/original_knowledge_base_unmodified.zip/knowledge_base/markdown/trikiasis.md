---
id: 329
title: "Trikiasis"
slug: "trikiasis"
icd_10: "H02.0"
category: "Penyakit Mata"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Trikiasis (ICD-10: H02.0)

**Kategori Medis**: Penyakit Mata  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Trikiasis adalah posisi bulu mata (silia) yang tumbuh melengkung ke arah dalam bola mata sehingga menggesek kornea dan konjungtiva bulbi, sering disebabkan oleh sikatriks tepi kelopak pasca-trakoma, blefaritis kronik, trauma, atau luka bakar.

---

## 2. Gejala & Manifestasi Klinis
- Mata terasa mengganjal dan perih terus-menerus
- Mata merah dan berair
- Fotofobia (silau)
- Sensasi benda asing setiap kali berkedip

---

## 3. Kriteria & Alur Diagnosis
Pemeriksaan senter/loupe: terlihat satu atau lebih helai bulu mata yang mengarah ke dalam dan menyentuh permukaan kornea atau konjungtiva bulbi. Tes fluoresin kornea sering memperlihatkan erosi kornea pungtata.

---

## 4. Tatalaksana & Terapi
1. Epilasi mekanik: Mencabut bulu mata yang malposisi menggunakan pinset silia steril (solusi sementara, silia akan tumbuh kembali dalam 4-6 minggu).
2. Medikamentosa: Salep mata antibiotik (kloramfenikol 1%) dan air mata buatan untuk mencegah infeksi dan melumasi defek epitel kornea.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Mata untuk terapi permanen elektrolisis, krioterapi, ablasi radiofrekuensi folikel silia, atau koreksi bedah kelopak mata bila disertai entropion sikatriks.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
