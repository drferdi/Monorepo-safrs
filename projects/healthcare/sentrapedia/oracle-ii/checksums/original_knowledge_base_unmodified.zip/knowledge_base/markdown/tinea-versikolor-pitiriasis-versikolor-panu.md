---
id: 343
title: "Tinea Versikolor (Pitiriasis Versikolor / Panu)"
slug: "tinea-versikolor-pitiriasis-versikolor-panu"
icd_10: "B36.0"
category: "Penyakit Kulit dan Kelamin"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Tinea Versikolor (Pitiriasis Versikolor / Panu) (ICD-10: B36.0)

**Kategori Medis**: Penyakit Kulit dan Kelamin  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Tinea versikolor (panu) adalah infeksi jamur superfisial kronik ringan pada stratum korneum kulit yang disebabkan oleh jamur dimorfik lipofilik Malassezia furfur (Pityrosporum orbiculare), ditandai dengan makula diskolorasi berskuama halus.

---

## 2. Gejala & Manifestasi Klinis
- Bercak hipopigmentasi (putih) atau hiperpigmentasi (cokelat/kemerahan) beraneka warna
- Skuama halus (furfurasea) yang tampak saat lesi digores
- Gatal ringan terutama saat tubuh berkeringat
- Predileksi: dada, punggung, leher, bahu, lengan atas

---

## 3. Kriteria & Alur Diagnosis
Pemeriksaan klinis dengan Finger-nail sign positif (skuama halus tampak jelas saat digores dengan kuku). Konfirmasi KOH 10-20% dengan tinta Parker: gambaran khas spageti dan bakso (spaghetti and meatballs: hifa pendek gemuk bersegmen bersama kumpulan spora bulat berkelompok). Lampu Wood: fluoresensi kuning keemasan.

---

## 4. Tatalaksana & Terapi
1. Antijamur Topikal:
   - Sampo Selenium Sulfida 1.8-2.5%: dioleskan pada seluruh area lesi 15 menit sebelum mandi 2-3 kali seminggu selama 2-4 minggu, ATAU
   - Sampo Ketokonazol 2% digunakan saat mandi selama 5-10 menit sebelum dibilas, ATAU
   - Krim Ketokonazol 2% atau Mikonazol 2% dioleskan 2 kali sehari selama 2-3 minggu.
2. Antijamur Oral (untuk lesi luas/kambuhan):
   - Ketokonazol 1 x 200 mg/hari oral selama 7-10 hari, atau Itrakonazol 1 x 200 mg/hari selama 7 hari.
3. Edukasi bahwa bercak hipopigmentasi memerlukan waktu berbulan-bulan untuk pulih pigmennya meski jamur telah mati.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Kulit bila bercak tidak membaik dengan terapi oral lini pertama atau dicurigai diagnosis diferensial lepra (morbus Hansen) tipe bercak kusta hipopigmentasi anestesi.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
