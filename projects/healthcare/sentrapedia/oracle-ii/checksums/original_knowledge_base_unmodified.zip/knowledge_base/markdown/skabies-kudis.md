---
id: 345
title: "Skabies (Kudis)"
slug: "skabies-kudis"
icd_10: "B86"
category: "Penyakit Kulit dan Kelamin"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Skabies (Kudis) (ICD-10: B86)

**Kategori Medis**: Penyakit Kulit dan Kelamin  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Skabies adalah penyakit kulit menular yang disebabkan oleh infestasi dan sensitisasi terhadap tungau Sarcoptes scabiei var. hominis, yang membuat terowongan di stratum korneum kulit manusia.

---

## 2. Gejala & Manifestasi Klinis
- Pruritus nokturnal (gatal hebat memuncak pada malam hari)
- Menyerang sekelompok orang yang tinggal bersama (asrama, pesantren, satu keluarga)
- Kanikulus (terowongan halus putih keabu-abuan berkelok) dengan vesikel di ujungnya
- Predileksi khas: sela-sela jari tangan, pergelangan tangan ventral, siku, ketiak, areola mammae, umbilikus, genitalia eksterna pria

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan jika ditemukan minimal 2 dari 4 tanda kardinal skabies (pruritus nokturnal, menyerang sekelompok, terowongan/kanikulus di tempat predileksi, ditemukannya tungau). Baku emas: biopsi kerokan kulit superfisial dengan minyak mineral memperlihatkan tungau, telur, atau feses (skibala) tungau.

---

## 4. Tatalaksana & Terapi
1. Skabisid Topikal Lini Pertama:
   - Permetrin krim 5%: dioleskan merata ke seluruh tubuh dari leher hingga ujung jari kaki (pada bayi termasuk kepala) malam hari sebelum tidur, dibiarkan selama 8-12 jam, lalu dibilas bersih. Diulang 1 minggu kemudian.
   - Alternatif: Salep 2-4 (Sulfur presipitatum 4-10%) dioleskan 3 malam berturut-turut (pilihan aman untuk bayi < 2 bulan dan ibu hamil/menyusui).
2. Pengobatan serentak seluruh anggota keluarga/penghuni asrama serumah.
3. Dekontaminasi lingkungan: cuci semua seprai, pakaian, dan handuk dengan air panas (> 60°C) atau bungkus dalam kantong plastik rapat selama minimal 72 jam.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Kulit bila Skabies Krustosa (Norwegian scabies: hiperkeratosis krustosa masif pada pasien imunodefisiensi), infeksi sekunder selulitis berat, atau lesi refrakter setelah 2 siklus permetrin.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
