---
id: 312
title: "Asma Bronkiale"
slug: "asma-bronkiale"
icd_10: "J45.9"
category: "Penyakit Paru"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Asma Bronkiale (ICD-10: J45.9)

**Kategori Medis**: Penyakit Paru  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Asma bronkiale adalah penyakit heterogen saluran napas kronik yang ditandai oleh inflamasi kronik jalan napas, hipereaktivitas bronkus terhadap berbagai stimulus, dan limitasi aliran udara ekspirasi yang bervariasi dan reversibel.

---

## 2. Gejala & Manifestasi Klinis
- Sesak napas episodik berulang
- Mengi (wheezing) terutama saat ekspirasi
- Rasa dada tertekan / berat
- Batuk terutama pada malam hari atau dini hari
- Dipicu alergen, udara dingin, aktivitas fisik (exercise-induced), stres, atau infeksi virus

---

## 3. Kriteria & Alur Diagnosis
Riwayat gejala respiratorik variatif yang memburuk pada malam/dini hari dengan variasi intensitas. Auskultasi: wheezing ekspirasi difus bilateral. Penunjang: Arus Puncak Ekspirasi (APE / Peak Flow Meter) dengan variabilitas diurnal > 10% atau reversibilitas perbaikan APE > 20% pasca-bronkodilator inhalasi.

---

## 4. Tatalaksana & Terapi
1. Tatalaksana Serangan Asma Akut Ringan-Sedang di FKTP:
   - Inhalasi SABA: Salbutamol nebulisasi 2.5-5 mg atau via MDI + spacer 4-10 semprotan setiap 20 menit dalam 1 jam pertama.
   - Oksigenasi via kanul nasal target SpO2 93-95%.
   - Kortikosteroid sistemik oral: Metilprednisolon 32-40 mg atau Prednison 40-50 mg oral segera.
2. Tatalaksana Kontroler Jangka Panjang (GINA Track 1 & 2):
   - Pelega & Pengontrol Harian: ICS dosis rendah + Formoterol (Budesonide-Formoterol) PRN saat sesak atau pemeliharaan teratur.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk CITO ke IGD RS bila serangan asma berat (bicara terputus per kata, retraksi suprasternal hebat, sianosis, SpO2 < 90%, silent chest / suara napas hilang, APE < 50% prediksi yang tidak membaik dengan nebulisasi 3 kali).

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
