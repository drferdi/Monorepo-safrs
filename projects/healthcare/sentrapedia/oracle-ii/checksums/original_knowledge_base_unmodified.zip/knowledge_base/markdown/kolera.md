---
id: 297
title: "Kolera"
slug: "kolera"
icd_10: "A00.9"
category: "Penyakit Infeksi"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Kolera (ICD-10: A00.9)

**Kategori Medis**: Penyakit Infeksi  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Kolera adalah penyakit diare sekretorik akut dan berpotensi fatal yang disebabkan oleh infeksi bakteri Vibrio cholerae serogrup O1 atau O139 yang menghasilkan enterotoksin kolera, memicu sekresi masif air dan elektrolit ke lumen usus.

---

## 2. Gejala & Manifestasi Klinis
- Diare cair masif tanpa rasa mulas mendadak
- Tinja khas berwarna keruh keputihan seperti air cucian beras (rice water stool)
- Muntah menyusul diare tanpa didahului mual hebat
- Kram otot ekstremitas akibat hipokalemia/hipokalsemia
- Dehidrasi berat berlangsung sangat cepat (mata sangat cekung, turgor kulit hilang, suara parau/vox cholerica, anuria, syok hipovolemik)

---

## 3. Kriteria & Alur Diagnosis
Kecurigaan klinis pada diare cair profus seperti air cucian beras di daerah endemis atau KLB. Pemeriksaan mikroskopis lapang gelap tinja memperlihatkan kuman batang koma dengan motilitas melesat cepat (darting motility). Baku emas: kultur tinja pada media agar TCBS (Thiosulfate Citrate Bile Salts Sucrose).

---

## 4. Tatalaksana & Terapi
1. Resusitasi Cairan Darurat (Penyelamat Jiwa):
   - Dehidrasi berat: Cairan kristaloid IV Ringer Laktat 100 mL/kgBB segera (30 mL/kg dalam 30 menit pertama, dilanjutkan 70 mL/kg dalam 2.5 jam berikutnya).
   - Lanjutkan rehidrasi oralit segera setelah pasien mampu minum.
2. Antibiotik (Memperpendek durasi diare dan ekskresi kuman):
   - Doksisiklin dosis tunggal 300 mg oral (dewasa).
   - Siprofloksasin 1 gram oral dosis tunggal atau Azitromisin 1 gram oral dosis tunggal (alternatif lini pertama untuk anak dan wanita hamil).
3. Pelaporan surveilans epidemiologi KLB dalam waktu < 24 jam.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke RS rujukan KLB bila pasien mengalami syok hipovolemik refrakter cairan, komplikasi asidosis metabolik berat, gagal ginjal akut, atau hipoglikemia berat pada anak.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
