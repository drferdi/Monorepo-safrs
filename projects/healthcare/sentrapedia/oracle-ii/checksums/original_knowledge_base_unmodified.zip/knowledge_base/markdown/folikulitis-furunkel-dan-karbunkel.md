---
id: 352
title: "Folikulitis, Furunkel, dan Karbunkel"
slug: "folikulitis-furunkel-dan-karbunkel"
icd_10: "L02.9"
category: "Penyakit Kulit dan Kelamin"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Folikulitis, Furunkel, dan Karbunkel (ICD-10: L02.9)

**Kategori Medis**: Penyakit Kulit dan Kelamin  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Infeksi supuratif akut unit folikel rambut yang disebabkan oleh Staphylococcus aureus. Folikulitis: radang terbatas pada folikel rambut; Furunkel (bisul): infeksi nekrotikans meluas hingga ke dermis dan subkutan sekitar folikel; Karbunkel: gabungan beberapa furunkel yang berkonfluensi dengan muara multipel.

---

## 2. Gejala & Manifestasi Klinis
- Folikulitis: papul atau pustul kecil eritematosa yang ditembus oleh sehelai rambut di tengahnya
- Furunkel: nodul eritematosa kerucut yang sangat nyeri berdenyut dengan mata bisul nekrotik sentral (fluktuasi/core)
- Karbunkel: massa radang besar sangat nyeri dengan nanah keluar dari beberapa orifisium, disertai demam dan malaise
- Predileksi: area berambut dan sering mengalami gesekan (leher belakang, wajah, bokong, aksila, paha)

---

## 3. Kriteria & Alur Diagnosis
Penegakan diagnosis klinis dari inspeksi dan palpasi nodul inflamasi folikular yang nyeri. Pemeriksaan Gram pus memperlihatkan kokus Gram positif bergerombol.

---

## 4. Tatalaksana & Terapi
1. Lesi Awal / Tanpa Fluktuasi:
   - Kompres hangat 15-20 menit 3 kali sehari untuk melokalisasi nanah dan mempercepat maturasi.
   - Mupirosin 2% salep atau Asam Fusidat 2% salep dioleskan 2-3 kali sehari.
2. Furunkel Matang dengan Fluktuasi / Karbunkel:
   - Pembedahan Kecil: Insisi dan drainase pus (I&D) steril, evakuasi massa nekrotik, pasang drain kassa bila rongga dalam.
3. Antibiotik Sistemik (Wajib pada lesi wajah segitiga bahaya, karbunkel, komorbid diabetes, atau disertai demam):
   - Kloksasilin 4 x 500 mg oral, atau Amoksisilin-Klavulanat 3 x 625 mg oral, atau Sefadroksil 2 x 500 mg oral selama 7 hari.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Bedah / RS bila furunkel di area segitiga bahaya wajah (danger triangle: bibir atas dan hidung) karena risiko trombosis sinus kavernosus, karbunkel luas pada pasien diabetes melitus tidak terkontrol, atau syok septik.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
