---
id: 286
title: "Perdarahan Saluran Cerna"
slug: "perdarahan-saluran-cerna"
icd_10: "K92.2"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Perdarahan Saluran Cerna (ICD-10: K92.2)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Perdarahan saluran cerna bawah (PSCB) didefinisikan sebagai keluarnya darah dari saluran cerna mulai dari ligamentum Treitz ke arah distal hingga rektum. PSCB dapat bersifat akut (kurang dari 3 hari) yang secara klinis biasanya lebih berat dan kronik yang umumnya berupa perdarahan hilang timbul dan sedikit-sedikit dalam jangka waktu lebih panjang. PSCB dapat terjadi secara nyata maupun samar (occult), dan biasanya terjadi tanpa adanya faktor risiko berupa penyakit penyerta. Gejala klinis yang timbul serta golongan usia dapat membantu menjelaskan penyebab / sumber perdarahan. Anak dengan klinis fatigue, anemia defisisensi besi sering dijumpai pada PSCB samar yang kronis.

---

## 2. Gejala & Manifestasi Klinis
- gejala melena atau lebih jarang suatu hematokesia 10) Riwayat penggunaan NSAID atau obat-obatan lain merupakan faktor resiko suatu PSCA akibat ulkus peptikum atau dapat menimbulkan PSCB karena efek antiplatelet 11) Riwayat penyakit yang mendasari misalnya imunodefisiensi merupakan faktor resiko terjadinya kolitis infeksi, typhlitis, sedangkan adanya penyakit hati dapat menyebabkan suatu perdarahan variseal berupa PSCA atau PSCB atau karena koagulopati b. Pemeriksaan Fisik Sebagaimana pada PSCA, pada PSCB juga perlu dilakukan penilaian secara cepat dan tepat mengenai kondisi anak apakah dibutuhkan tatalaksana kegawatdaruratan, antara lain apakah kondisi anak stabil, apakah didapatkan tanda-tanda syok, apakah perdarahan signifikan, apakah terjadi perdarahan aktif, dan apakah ada kondisi yang diduga menjadi penyebab perdarahan. Sepsis perlu dicurigai pada anak dengan demam atau kondisi yang beresiko terjadinya infeksi. Adanya obstruksi usus perlu dicurigai pada distensi abdomen berat dengan jdih.kemkes.go.id - 73 - muntah bilios/nonbilious. Pemeriksaan fisik pada pasien yang telah stabil dilakukan lengkap dengan tujuan mencari sumber potensial perdarahan, mencakup: 1) Kulit: apakah didapatkan tanda pucat, ikterus, ekimosis, pembuluh darah abnormal, hemangioma, status hidrasi, ruam, petekie, purpura 2) Kepala, mata, telinga, hidung dan tenggorokan: apakah didapatkan injeksi nasofaring, pembesaran tonsil, perdarahan 3) Kardiovaskular: frekuensi jantung dan nadi tidur, duduk, berdiri, waktu pengisian kapiler, irama galop 4) Abdomen: adanya pembesaran organ hati dan atau limpa, tanda-tanda hipertensi porta (asites, vena superfisial prominen), massa, nyeri abdomen, nyeri tekan, bising usus abnormal, tanda-tanda peritonitis 5) Perineum dan anus: adanya fisura, fistula, indurasi, skin tag, hemoroid eksterna, dan lesi vaskular 6) Rektum: adanya darah, melena, adanya rasa nyeri, polip, adanya tinja dan gas yang menyemprot pada pemeriksaan colok dubur (mengarahkan ke penyakit Hirschsprung) c. Pemeriksaan Laboratorium 1) Pada anak dengan PSCB signifikan perlu dievaluasi adanya anemia, sedangkan pada sumber perdarahan minor teridentifikasi seperti fisura atau gastroenteritis mungkin tidak memerlukan pemeriksaan laboratorium 2) Pada penderita dengan kecurigaan kolitis karena infeksi atau IBD pemeriksaan LED, CRP, albumin, DL, dan tinja untuk mencari patogen, dan fecal calprotectin 3) Pada penderita dengan adanya perdarahan bersumber di luar saluran cerna perlu dievaluasi adanya kelainan perdarahan (PT, aPTT, faktor pembekuan darah) dan trombosit 4) Pada penderita dengan kecurigaan hemolytic uremic syndrome (HUS) perlu dilakukan pemeriksaan Darah lengkap serial dan fungsi ginjal 5) Tes darah samar pada tinja dan muntahan (guaiac test) perlu dilakukan pada kecurigaan PSCB samar jdih.kemkes.go.id - 74 - 6) Pada penderita dengan kecurigaan penyakit hati atau sistemik perlu dievaluasi parameter biokimia hati seperti PT, aPTT, AST, ALT, GGT, albumin, protein total 7) Tes Apt-Downey dapat membedakan antara HbF bayi yang lebih resisten terhadap proses denaturasi alkali dibandingkan HbA dewasa, dapat digunakan untuk membedakan perdarahan yang berasal dari bayi atau maternal d. Imaging 1) Foto polos abdomen 2 posisi diindikasikan pada bayi dan anak dengan pemeriksaan abdomen abnormal misalnya adanya distensi, nyeri, dan suara bising usus tidak normal, atau anak dengan tampilan klinis sakit. 2) USG dilakukan pada anak dengan kecurigaan intususepsi yang juga dapat digunakan sebagai pemeriksaan

---

## 3. Kriteria & Alur Diagnosis
diagnosis definitif Rujukan dilakukan bila tidak memiliki SDM atau sarana prasarana. jdih.kemkes.go.id - 81 - BAB V RANGKUMAN PERINGKAT BUKTI DAN DERAJAT REKOMENDASI A. Pemberian obat proton pump inhibitor (PPI) pada pasien dengan perdarahan saluran cerna atas (Peringkat bukti Ia, derajat rekomendasi A) B. Pada dewasa, pemberian eritromisin ataupun agen prokinetik pada pasien dengan perdarahan saluran cerna atas sebelum tindakan endoskopi untuk meningkatkan visualisasi (Peringkat bukti IIb, derajat rekomendasi B) C. Penggunaan system scoring Blatchford dan Rockall sebagai stratifikasi risiko pada pasien perdarahan saluran cerna (Peringkat bukti IIb, derajat rekomendasi B) D. Pemeriksaan endoskopi sebagai modalitas diagnostik untuk perdarahan saluran cerna atas (Peringkat bukti Ia, derajat rekomendasi A) E. Pemeriksaan kolonoskopi sebagai modalitas diagnostik untuk perdarahan saluran cerna bawah (Peringkat bukti II, derajat rekomendasi B) jdih.kemkes.go.id - 82 - BAB VI SIMPULAN A. Perdarahan saluran cerna merupakan salah satu masalah emergensi di bidang gastroenterologi. B. Perdarahan Saluran Cerna Atas (PSCA) adalah perdarahan saluran makanan proksimal dari ligamen Treitz yang dibedakan menjadi perdarahan varises dan non-varises. C. Perdarahan saluran cerna bawah (PSCB) adalah perdarahan yang asalnya terletak hilir duodeno-jejunal persimpangan di ligamen Treitz, sehingga termasuk usus halus, usus besar, rektum atau anus dan paling sering ditandai dengan adanya hematokezia. D. Modalitas diagnostik untuk memvisualisasikan lokasi perdarahan saluran cerna saat ini sudah berkembang, baik dari teknik endoskopi maupun radiologi. E. Penanganan perdarahan saluran cerna memerlukan perawatan multidisiplin yang melibatkan ahli penyakit dalam gastroenterologi, penyakit anak gastroenterologi, bedah digestif, bedah anak, anestesi, radiologi, dan profesi lain terkait dengan tujuan utamanya adalah diagnostik, tatalaksana serta terapeutik sumber perdarahan. F. Secara umum penanganan perdarahan saluran cerna meliputi stabilisasi hemodinamik, resusitasi cairan, pemasangan NGT, pemberian PPI, transfusi darah bila terdapat indikasi, prokinetik, endoskopi terapeutik, kolonoskopi terapeutik, dan pembedahan. MENTERI KESEHATAN REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 4. Tatalaksana & Terapi
Perdarahan oleh karena colitis ulseratif dapat diterapi dengan memotong segmen colon dan rektum yang terlibat, kolektomi dapat dipertimbangkan pada kondisi ini sebelum terjadi komplikasi mayor. Operasi dapat dilakukan dengan open surgery maupun laparoskopik, operasi lain dapat dilakukan mukosektomi, pembuatan pouch atau pembuatan stoma (stage surgery) untuk kemudian dilanjutkan dengan proktokolektomi. Pada colitis infektif yang disebabkan oleh amoebic colitis dan tuberculosis dan infestasi cacing tambang, dapat dilakukan biopsi melalui kolonoskopi. Laparatomi / laparaskopi eksplorasi dilakukan pada perdarahan yang tidak dapat ditentukan lokasinya, dapat disertai kolonoskopi dan/atau enteroskopi dan dilakukan reseksi pada segmen perdarahan. Blind subtotal colectomy dapat dilakukan bila sumber perdarahan tidak dapat diidentifikasi dengan ileostomi atau ileoproktostomi. 7. Prognosis Prognosis sangat tergantung pada penyebab dari PSCB dan derajat perdarahan yang terjadi. Secara umum mortalitas karena PSCB lebih rendah dibandingkan PSCA (0,6% vs. 4,8%). Pada pasien dengan penyakit komorbid, misalnya adanya malnutrisi, penyakit hati kronik, maka prognosis menjadi lebih buruk. 8. Kriteria Rujuk a. Adanya keluhan nyeri abdomen akut atau curiga suatu

---

## 5. Kriteria Rujukan (FKRTL)
memerlukan rujukan ke hematologic jdih.kemkes.go.id - 80 - e. Modalitas diagnostik tidak memadai untuk menegakkan

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2023
