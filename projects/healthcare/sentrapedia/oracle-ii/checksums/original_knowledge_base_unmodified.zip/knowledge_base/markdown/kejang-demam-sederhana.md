---
id: 331
title: "Kejang Demam Sederhana"
slug: "kejang-demam-sederhana"
icd_10: "R56.0"
category: "Penyakit Anak"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Kejang Demam Sederhana (ICD-10: R56.0)

**Kategori Medis**: Penyakit Anak  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Kejang demam sederhana adalah bangkitan kejang yang terjadi pada kenaikan suhu tubuh (suhu rektal > 38°C) yang disebabkan oleh proses ekstrakranial pada anak usia 6 bulan hingga 5 tahun, berlangsung singkat (< 15 menit), bersifat umum (tonik dan/atau klonik), dan tidak berulang dalam 24 jam.

---

## 2. Gejala & Manifestasi Klinis
- Kejang umum seluruh tubuh (kelojotan tonik-klonik)
- Mata mendelik ke atas
- Penurunan kesadaran sesaat selama kejang
- Durasi kejang singkat < 15 menit
- Anak sadar penuh kembali pasca-kejang tanpa defisit neurologis

---

## 3. Kriteria & Alur Diagnosis
Penegakan diagnosis klinis pada anak usia 6 bulan - 5 tahun dengan demam tanpa riwayat infeksi intrakranial (tidak ada kaku kuduk, fontanel tidak membonjol) dan tidak ada gangguan elektrolit/metabolik berat. Eksklusi meningitis/ensefalitis adalah wajib.

---

## 4. Tatalaksana & Terapi
1. Penanganan Saat Kejang Berlangsung:
   - Baringkan anak di tempat aman miringkan posisi tubuh, bebaskan jalan napas, jangan memasukkan benda ke mulut.
   - Diazepam rektal: 5 mg (BB < 12 kg) atau 10 mg (BB >= 12 kg). Jika kejang belum berhenti, dapat diulang 1 kali dengan interval 5 menit.
2. Tatalaksana Demam (Pencegahan):
   - Antipiretik: Parasetamol 10-15 mg/kgBB oral setiap 4-6 jam prn, atau Ibuprofen 10 mg/kgBB setiap 6-8 jam.
   - Terapi penyebab infeksi pencetus demam (ISPA, OMA, diare).
   - Antikonvulsan profilaksis intermiten: Diazepam oral 0.3 mg/kgBB/kali setiap 8 jam selama 48 jam pertama demam (pada kasus dengan risiko rekurensi tinggi).

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk CITO ke IGD RS bila kejang demam kompleks (kejang fokal/sepihak, durasi > 15 menit, atau berulang >= 2 kali dalam 24 jam), usia anak < 6 bulan, penurunan kesadaran persisten pasca-kejang, kaku kuduk positif, atau status epileptikus.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
