---
id: 287
title: "Osteoporosis"
slug: "osteoporosis"
icd_10: "M81"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Osteoporosis (ICD-10: M81)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
, dimana batas Z- Score BMD < -2 SD tidak lagi dibutuhkan untuk mendiagnosis Osteoporosis pada anak dengan fraktur vertebra dan tidak dibutuhkan data Z- Score BMD pada semua fraktur vertebra terkait trauma ringan. Pada tahun 2013, ISCD merekomendasikan menggunakan Z- Score BMD < -2,0 SD hanya untuk pasien dengan fraktur tulang panjang. Pasien dengan fraktur tulang panjang dianggap memiliki fraktur bermakna jika terdapat riwayat ≥ 2 fraktur tulang panjang pada usia 10 tahun dan ≥ 3 fraktur tulang panjang pada usia 18 tahun. ISCD 2013 dan 2019 juga menyatakan bahwa Z- Score aBMD (atau bone mineral content) > -2.0 tidak menghilangkan risiko terjadinya fraktur tulang panjang. Hal ini sesuai dengan penelitian Henderson dkk. yang mendapatkan hasil bahwa sekitar 15% anak dengan kelainan neuromuskuler dan fraktur ekstremitas memiliki Z- Score skor BMD femur distal lateral > -2.0 SD. Penelitian Ma dkk. menunjukkan bahwa terdapat hubungan yang cukup konsisten antara Z- Score BMD vertebra lumbal dengan fraktur vertebra pada anak dengan leukemia limfositik akut. Hal ini menunjukkan bahwa penggunaan Z- Score BMD sebagai salah satu variabel faktor risiko fraktur vertebra tetap valid. Pada anak yang yang memiliki faktor risiko Osteoporosis dengan riwayat fraktur terkait trauma ringan yang jelas maka tidak boleh ragu dalam menegakkan diagnosis pada kasus tersebut meskipun Z- Score BMD koreksinya > -2,0 SD. Sebaliknya, jika ditemukan fraktur berulang pada anak sehat yang tidak memiliki faktor risiko atau stigmata OI atau riwayat keluarga yang secara genetik terkonfirmasi mengalami Osteoporosis

---

## 2. Gejala & Manifestasi Klinis
- juvenil Terdapat gejala nyeri tulang pada idiopatik ekstremitas bawah, kesulitan berjalan, dan fraktur multipel, disertai fraktur vertebra kompresi. Sindrom Osteoporosis- Osteoporosis pada anak berat disertai pseudoglioma kebutaan Sekunder Penurunan mobilitas, Fungsi dan status nutrisi yang buruk misal: palsi serebral berkorelasi dengan BMD yang rendah (PS), cedera korda, DMD Z- ScoreBMD pada femur distal berkorelasi dengan risiko fraktur. Anak dengan PS yang immobile memiliki prevalens fraktur sebesar 6-12%, terutama pada ekstremitas bawah Penggunaan Risiko fraktur meningkat seiring dengan glukokortikoid peningkatan dosis dan durasi penggunaan glukokortikoid Malnutrisi Pada atlet wanita ditemukan anoreksia nervosa, asupan energi tidak cukup, gangguan menstruasi, dan penurunan densitas mineral tulang. Inflamasi kronis Proses inflamasi mengakibatkan malabsorpsi seperti pada penyakit inflamasi saluran cerna. Tata laksana pada penyakit ini tidak menghentikan proses inflamasi yang berlangsung Gangguan endokrin Penampakan cushingoid dan pertumbuhan yang buruk berhubungan dengan kelebihan glukokortikoid Pubertas terlambat Pubertas terlambat konstitusional pada laki-laki akan meningkatkan fraktur dan tulang lebih kecil pada pQCT. Pada remaja perempuan dengan pubertas terlambat dapat meningkatkan risiko fraktur. jdih.kemkes.go.id Pada sindrom Turner didapatkan BMD yang rendah pada prepubertas yang akan meningkat pada onset pubertas Onkologi Iradiasi kranial memiliki dampak negatif pada BMD. Pasien anak dengan keganasan yang tidak mendapat iradiasi kranial memiliki BMD yang normal. Thalasemia Deposisi besi dapat mengakibatkan hipogonadisme, hipotiroidisme, diabetes, dan atau hipopituitarisme. Fe memiliki efek toksisitas langsung pada osteoblast. Neurofibromatpsis tipe 1 Fraktur sulit untuk ditangani. Displasia tibia kongenital dengan pseudoarthrosis merupakan bagian dari kriteria Post transplantasi diagnosis. Immunosupresan (glukokortikoid dan inhibitor calcineurin) dan imobilitas Prematuritas menyebabkan kehilangan massa tulang Peningkatan alkali fosfatase, hipofosfatemia dan peningkatan hormone paratiroid sering ditemukan BMD: Bone Mineral Density; DMD: Duchenne Muscular Dystrophy Pada anamnesis perlu ditanyakan usia terjadinya fraktur, mekanisme fraktur, riwayat penyembuhan fraktur, riwayat keluarga, nyeri pada tungkai atau tulang punggung, masalah sosial, riwayat perkembangan, hipermobilitas, riwayat hematom, status nutrisi, komorbiditas, dan riwayat pengobatan. Pemeriksaan fisis yang teliti meliputi pemeriksaan gambaran dismorfik, gangguan pendengaran, warna sklera, kondisi gigi, dan kulit hiperelastis. Pemeriksaan pertumbuhan, status pubertas, scoliosis, nyeri pada tulang belakang, deformitas dan bukti adanya kekerasan seperti memar, bekas gigitan, dan luka bakar. 5. Pemeriksaan Penunjang Pemeriksaan penunjang Osteoporosis pada anak dan remaja umumnya menggunakan pemeriksaan pencitraan dan laboratorium. jdih.kemkes.go.id a. Pemeriksaan pencitraan untuk mendeteksi fraktur vertebra Sampai saat ini, metode pencitraan yang paling sering digunakan untuk mendeteksi fraktur vertebra pada anak adalah foto polos torakolumbar lateral. Pemeriksaan BMD tidak digunakan untuk mendeteksi adanya fraktur vertebra. Fraktur vertebra asimptomatik dapat terjadi pada Z- Score BMD > -2,0 SD sehingga diperlukan survailens pencitraan untuk deteksi fraktur vertebra. Pemeriksaan foto polos vertebra perlu dilakukan saat awal

---

## 3. Kriteria & Alur Diagnosis
untuk diagnosis Osteoporosis pada anak dan remaja. 3 Pemeriksaan foto polos tulang digunakan IB A untuk deteksi fraktur tulang. 4 Pemeriksaan bone age dilakukan untuk IB A menentukan maturasi skeletal yang berguna untuk menentukan apakah anak tumbuh sesuai potensi genetiknya. 5 Pemeriksaan laboratorium seperti IB A pemeriksaan kalsium, fosfat, 25(OH)- vitamin D, magnesium, alkali fosfatase, iPTH serum, dan hormon pubertass dapat dilakukan tergantung penyakit yang mendasarinya. 6 Pemeriksaan BMD DXA dilakukan untuk IA A menilai BMC dan areal BMD (aBMD). jdih.kemkes.go.id 7 Pemeriksaan Peripheral Quantitative IB A Computed Tomography (pQCT) dilakukan apabila pemeriksaan BMD DXA tidak dapat dikerjakan. 8 Anak dengan risiko Osteoporosis IA A direkomendasikan untuk menjamin kecukupan nutrisi harian, terutama vitamin D dan kalsium. 9 Tatalaksana terhadap penyakit primer juga IB A diberikan pada anak dengan Osteoporosis sekunder. jdih.kemkes.go.id BAB V. KESIMPULAN 1. Osteoporosis merupakan masalah kesehatan yang sangat penting karena dapat menyebabkan patah tulang. Patah tulang memerlukan biaya perawatan yang mahal, selain itu patah tulang akan memberikan problem yang serius pada penderitanya seperti kecacatan, masalah nyeri, gangguan produktivitas, gangguan kualitas hidup dan bahkan dapat meningkatkan kematian. Osteoporosis paling banyak menyerang wanita paska menopause dan usia lanjut, akan tetapi juga dapat menyerang anak-anak, usia lebih muda, laki-laki, dan pasien yang mengkonsumsi kortikosteroid. Jumlah penderita Osteoporosis di Indonesia akan semakin meningkat sejalan dengan usia harapan hidup yang meningkat, jumlah populasi usia lanjut bertambah banyak, dan perubahan pola makan dan gaya hidup.

---

## 4. Tatalaksana & Terapi
fisioterapi maupun tindakan operasi sesuai indikasi diberikan pada pasien Osteoporosis yang mengalami patah tulang. jdih.kemkes.go.id 4. PNPK Tata Laksana Osteoporosis ini dapat menjadi pedoman dan acuan untuk dokter umum dan dokter spesialis dalam menangani Osteoporosis sesuai dengan kompetensi, kondisi, sarana dan fasilitas masing-masing. PNPK ini juga dapat menjadi pedoman dan acuan bagi instansi pelayanan kesehatan dan pendidikan di Indonesia menetapkan kebijakan dalam tatalaksana Osteoporosis secara komprehensif. MENTERI KESEHATAN REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Penyakit Dalam (Sp.PD) atau Bedah Ortopedi apabila terjadi fraktur patologis/kompresi vertebra baru, skor T DXA <= -3.0 dengan fraktur fragilitas multipel, atau memerlukan terapi anabolik (teriparatide).

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2023
