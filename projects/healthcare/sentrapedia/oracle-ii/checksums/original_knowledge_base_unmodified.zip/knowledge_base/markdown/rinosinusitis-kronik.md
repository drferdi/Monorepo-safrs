---
id: 262
title: "Rinosinusitis Kronik"
slug: "rinosinusitis-kronik"
icd_10: "J32"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Rinosinusitis Kronik (ICD-10: J32)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Rinosinusitis kronik merupakan suatu keadaan klinis berupa peradangan persisten pada mukosa hidung dan sinus paranasal, yang berlangsung selama 12 minggu atau lebih. Penyakit ini ditandai dengan adanya dua atau lebih gejala, yang salah satu diantaranya harus meliputi gejala utama. Gejala utama RSK adalah hidung tersumbat dan lendir hidung yang mengalir ke anterior atau posterior.

---

## 2. Gejala & Manifestasi Klinis
- diagnosis pembanding berdasarkan gejala utama yang mirip dengan penyakit penyakit lain tersebut, seperti rinitis alergi dan non-alergi, penyakit penyakit dengan gangguan penghidu, dan penyakit penyakit dengan nyeri wajah (Tabel 9, 10, dan 11). Dokter Umum di layanan primer diharapkan dapat membedakan diagnosis rinosinusitis dengan rinitis berdasarkan anamnesis yang teliti. Dokter Spesialis T.H.T.K.L. di layanan sekunder diharapkan dapat membedakan rinosinusitis berdasarkan fenotipenya berdasarkan pemeriksaan nasoendoskopi dan CT scan sinus paranasal, sedangkan Dokter Spesialis T.H.T.K.L. Konsultan Rinologi di layanan tersier diharapkan dapat membedakan rinosinusitis berdasarkan endotipenya berdasarkan pemeriksaan penunjang yang lebih kompleks. Pasien yang terdiagnosis RSK oleh Dokter Umum di layanan primer (atau melalui layanan kesehatan telemedicine) diberikan tata laksana berupa pemberian terapi dan edukasi. Terapi yang direkomendasikan adalah cuci hidung dan kortikosteroid intranasal, terapi antibiotik harus dihindari pada layanan primer. Pemberian edukasi terutama pada cara pemakaian terapi topikal hidung serta kepatuhan penggunaannya. Terapi diberikan selama 6-12 minggu, dengan dilakukan evaluasi secara teratur untuk melihat jdih.kemkes.go.id - 103 - progresivitas penyakit. Apabila terdapat perbaikan maka terapi dilanjutkan, tetapi bila tidak ada perbaikan atau terjadi perburukan maka pasien harus dirujuk ke Dokter Spesialis T.H.T.K.L. di layanan sekunder atau tersier. Dokter Spesialis T.H.T.K.L. di layanan sekunder atau tersier kemudian melakukan evaluasi terhadap faktor risiko dan riwayat penyakit komorbid, pemeriksaan THT, nasoendoskopi, CT scan dan pemeriksaan lain yang diperlukan. Pada kasus RSK yang disertai dengan alarm symptom, pasien harus segera dirujuk ke Dokter Spesialis T.H.T.K.L. pada layanan sekunder atau tersier untuk mendapatkan penatalaksanaan lebih lanjut. Pada tata laksana RSK primer difus (gambar 4), direkomendasikan pemberian terapi medis tepat (TMT) yang meliputi steroid nasal dan irigasi hidung dengan cairan saline. Wajib dilakukan edukasi mengenai pemilihan teknik, cara pemakaian dan kepatuhan terapi steroid nasal dan irigasi hidung yang sangat penting untuk keberhasilan terapi. Evaluasi dilakukan dalam rentang waktu 6-12 minggu dengan penjadwalan kontrol sesuai kebutuhan. Bila tidak ada perbaikan dalam 6 -12 minggu perlu dilakukan pemeriksaan penunjang seperti CT scan, laboratorium ataupun tindakan lainnya. Pasien perlu dipertimbangkan dirujuk ke layanan tersier atau Dokter Spesialis Konsultan Rinologi apabila diperlukan tata laksana selanjutnya berdasarkan endotipe yaitu RSK tipe 2 atau non tipe 2. Pada RSK primer non tipe 2 keluhan sering disertai hidung beringus, nyeri wajah, tidak ada riwayat atopi dan asma, dengan hasil pemeriksaan nasoendoskopi didapatkan sekret purulen, tidak ada peningkatan IgE ataupun eosinofilia. Pilihan terapi medikamentosa berupa TMT dan dapat ditambahkan antibiotik jangka panjang atau dilakukan operasi BSEF. Rinosinusitis kronik primer tipe 2 mempunyai keluhan yang dominan berupa penurunan penciuman dan hidung tersumbat/kongesti, disertai adanya riwayat N-ERD dan atau asma serta atopi, yang didukung dengan hasil pemeriksaan nasoendoskopi berupa polip dan lendir eosinofilik serta peningkatan IgE dan eosinofilia. Pada RSK tipe 2 dapat diberikan TMT dan atau kortikosteroid oral, atau dilakukan tindakan BSEF. jdih.kemkes.go.id - 104 - Evaluasi dilakukan selama 6-12 minggu baik pada RSK tipe 2 atau non tipe 2. Bila tidak ada perbaikan bisa dipertimbangkan pemberian terapi tambahan atau operasi revisi. Pemeriksaan tambahan perlu dilakukan sebagai pertimbangan kemungkinan RSK sekunder difus.

---

## 3. Kriteria & Alur Diagnosis
penegakan diagnosis dengan pemeriksaan klinis analisis cairan liquor termasuk kultur dan pemeriksaan penunjang lain seperti CT Scan dengan kontras dan/atau MRI untuk menentukan jenis kelainan, letak dan ukuran kelainan, serta perencanaan tata laksana. Penatalaksanaan dapat berupa pemberian antibiotik empiris atau sesuai dengan pola antibiogram lokal selama 3-5 hari

---

## 4. Tatalaksana & Terapi
Penilaian kesembuhan dari RSK baik setelah terapi medikamentosa ataupun setelah operasi dinilai berdasarkan keluhan hidung tersumbat, rinore atau post nasal drip, ada/tidak nyeri tekan wajah, penghidu, dan adanya gangguan tidur serta penilaian secara endoskopik mukosa hidung jdih.kemkes.go.id - 106 - dan sinus paranasal. Kriteria penilaian klinis pascaterapi RSK terbagi menjadi: terkontrol, terkontrol sebagian, dan tidak terkontrol. Penilaiannya meliputi ada atau tidaknya keluhan dan jika pun ada keluhan sifatnya mengganggu atau tidak, dilakukan penilaian VAS dan dilakukan pemeriksaan nasoendoskopi (Tabel 19). Prognosis rinosinusitis dapat ditentukan dengan mengidentifikasi endotipe RSK dan bukan berdasarkan fenotipe. Semakin baik dapat mengidentifikasi endotipe akan semakin memudahkan penatalaksanaan yang efektif dengan target terapi lebih terarah dan hasil yang lebih baik. Prediksi rekurensi penyakit melingkupi banyak faktor termasuk usia, jenis kelamin, etnis, komorbid dan durasi penyakit. Pasien dengan skor SNOT-22 praoperatif di bawah dari 20 yang gagal mencapai rata-rata perbaikan lebih besar dari M CID, skor >30 memiliki kemungkinan 70-75% mencapai perbaikan lebih besar dari MCID. MENTERI KESEHATAN REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 5. Kriteria Rujukan (FKRTL)
komprehensif dengan sistem rujukan terstruktur dari pelayanan primer, sekunder dan tersier. 3) Fasilitas diagnostik dan tata laksana RSK dapat terpenuhi sesuai tinggkat pelayanan kesehatan. 4) Menjadi dasar bagi sistem-sistem lain yang berkaitan dengan pelayanan kesehatan terutama RSK. 5) Meningkatnya kualitas hidup pasien dengan RSK. 3. Sasaran a. Semua tenaga medis yang terlibat dalam penanganan RSK, meliputi Dokter Spesialis T.H.T.K.L., Penyakit Dalam, Radiologi, jdih.kemkes.go.id - 9 - Anestesi, Mata, Patologi Anatomi, Patologi Klinik, Farmakologi, Mikrobiologi, Neurologi, Bedah Saraf, Bedah Mulut dan Dokter Umum. b. Pembuat kebijakan di lingkungan rumah sakit, institusi pendidikan, dan profesi terkait. jdih.kemkes.go.id - 10 - BAB II METODOLOGI A. Gambaran Proses Penyusunan PNPK ini menggunakan metode adaptasi guideline yang terdiri dari 3 tahapan proses. Tahap pertama adalah tahap persiapan (set- up phase), kemudian tahap adaptasi (adaptation phase) dan terakhir adalah tahap finalisasi (finalization phase). Dalam tahap persiapan, proses identifikasi dilakukan mengenai kemampulaksanaan dari metode adaptasi guideline, dilanjutkan dengan pembentukan tim penyusun, penentuan topik dan identifikasi sumber daya dan keterampilan yang dibutuhkan. Keahlian dan keterampilan yang dibutuhkan dalam penyusunan PNPK ini meliputi tim ahli substansi, pemangku kepentingan terkait dan tim metodologi. Selanjutnya proses adaptasi dilakukan melalui tahapan sebagai berikut: 1. Perumusan Pertanyaan Klinis Pertanyaan klinis disusun oleh panelis yang mewakili Dokter Spesialis T.H.T.K.L. di bidang Rinologi dari Kelompok Studi Rinologi Perhati-KL. Pertanyaan klinis mengacu kepada cakupan pertanyaan yang disusun menggunakan PIPOH atau Population, Intervention, Professional/Patient, Outcome, dan Health Setting. Pertanyaan klinis mencakup pertanyaan yang masih terdapat kesenjangan dan perbedaan dalam setting klinis mencakup area diagnosis, tata laksana, dan prognosis dari penyakit. Tabel 1. PIPOH PIPOH Uraian

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2022
