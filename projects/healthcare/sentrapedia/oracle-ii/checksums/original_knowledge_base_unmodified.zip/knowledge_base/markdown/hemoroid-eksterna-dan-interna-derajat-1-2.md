---
id: 303
title: "Hemoroid Eksterna dan Interna Derajat 1-2"
slug: "hemoroid-eksterna-dan-interna-derajat-1-2"
icd_10: "I84.9"
category: "Penyakit Pencernaan"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Hemoroid Eksterna dan Interna Derajat 1-2 (ICD-10: I84.9)

**Kategori Medis**: Penyakit Pencernaan  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Hemoroid adalah pelebaran dan peradangan pleksus vaskular submukosa anorektal (bantalan vaskular anus). Derajat 1: perdarahan tanpa prolaps; Derajat 2: prolaps saat mengejan namun masuk kembali secara spontan.

---

## 2. Gejala & Manifestasi Klinis
- Perdarahan segar menetes pasca-defekasi (hematochezia segar tanpa nyeri pada interna)
- Rasa mengganjal di anus
- Gatal pada area perianal (pruritus ani)
- Nyeri tajam mendadak pada hemoroid eksterna bila terjadi trombosis

---

## 3. Kriteria & Alur Diagnosis
Diagnosis klinis berdasarkan inspeksi anal (massa trombosis eksterna atau prolaps interna) dan pemeriksaan colok dubur (digital rectal examination) serta anoskopi di FKTP.

---

## 4. Tatalaksana & Terapi
1. Konservatif & Gaya Hidup (Kunci Terapi Derajat 1-2):
   - Diet tinggi serat (sayur, buah, suplemen psyllium husk) dan cairan 2-2.5 liter/hari untuk melunakkan tinja tanpa mengejan.
   - Rendam duduk air hangat (sitz bath) 15-20 menit 2-3 kali sehari.
2. Farmakologis:
   - Supositoria atau salep antihemoroid topikal kombinasi anestesi lokal dan kortikosteroid ringan (2 kali sehari selama 5-7 hari).
   - Flebotropik oral: Micronized Purified Flavonoid Fraction (MPFF: Diosmin 450 mg + Hesperidin 50 mg) 3 x 2 tablet selama 4 hari pertama, lalu 2 x 2 tablet selama 3 hari berikutnya.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Bedah di FKRTL bila hemoroid derajat 3 (prolaps perlu didorong manual), derajat 4 (prolaps permanen/inkarserata), perdarahan masif berulang yang menyebabkan anemia kronik, atau hemoroid interna strangulata.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
