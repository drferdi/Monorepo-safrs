---
id: 326
title: "Pterigium"
slug: "pterigium"
icd_10: "H11.0"
category: "Penyakit Mata"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Pterigium (ICD-10: H11.0)

**Kategori Medis**: Penyakit Mata  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Pterigium adalah pertumbuhan jaringan fibrovaskular konjungtiva bulbi berbentuk segitiga (triangular) yang menginvasi kornea, sering dipicu oleh paparan kronik sinar radiasi ultraviolet (UV), angin, debu, dan udara kering.

---

## 2. Gejala & Manifestasi Klinis
- Selaput daging kemerahan berbentuk segitiga pada mata (sering sisi nasal)
- Mata merah, perih, dan mengganjal
- Astigmatisma dan penglihatan kabur bila apeks pterigium telah melewati pupil/aksis visual

---

## 3. Kriteria & Alur Diagnosis
Inspeksi senter/slit lamp: jaringan fibrovaskular berbentuk sayap segitiga dengan apeks mengarah ke kornea. Derajat: Derajat 1 (belum melewati limbus), Derajat 2 (melewati limbus < 2 mm), Derajat 3 (antara limbus dan tepi pupil), Derajat 4 (melewati pupil).

---

## 4. Tatalaksana & Terapi
1. Pencegahan Progresi: Edukasi memakai kacamata hitam pelindung sinar UV dan topi saat beraktivitas di luar ruangan.
2. Medikamentosa Simtomatik (Derajat 1-2):
   - Air mata buatan tetes mata 3-4 kali sehari untuk mengatasi iritasi kering.
   - Vasokonstriktor/dekongestan mata topikal singkat bila mata sangat merah meradang.
3. Pembedahan: Pterigium tidak dapat hilang dengan obat tetes mata; tatalaksana definitif adalah ekstirpasi pterigium.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Mata untuk pembedahan ekstirpasi pterigium dengan autograft konjungtiva bila pterigium derajat 3 atau 4 (mengancam/menutupi aksis visual), astigmatisma ireguler progresif, iritasi refrakter, atau indikasi kosmetik.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
