---
id: 314
title: "Rinitis Vasomotor"
slug: "rinitis-vasomotor"
icd_10: "J30.0"
category: "Penyakit THT"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Rinitis Vasomotor (ICD-10: J30.0)

**Kategori Medis**: Penyakit THT  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Rinitis vasomotor adalah gangguan fungsional neurovaskular mukosa hidung non-alergi dan non-infeksi yang ditandai oleh ketidakseimbangan sistem saraf otonom (hiperaktivitas parasimpatis), dipicu oleh rangsangan non-spesifik seperti perubahan suhu dingin, kelembapan, asap rokok, bau menyengat, atau stres.

---

## 2. Gejala & Manifestasi Klinis
- Hidung tersumbat bergantian kiri dan kanan
- Sekret hidung encer berlebihan (rinorea serosa profus)
- Keluhan dipicu udara dingin, makanan pedas/panas, atau bau tajam
- Jarang disertai bersin paroksismal atau mata gatal (membedakan dari rinitis alergi)

---

## 3. Kriteria & Alur Diagnosis
Diagnosis per eksklusi: gejala hidung tersumbat dan rinorea tanpa riwayat atopi, tes alergi (skin prick test) negatif, rinoskopi anterior memperlihatkan konka hipertrofi berwarna merah gelap atau keunguan dengan sekret serosa.

---

## 4. Tatalaksana & Terapi
1. Menghindari faktor pemicu spesifik (asap, bau menyengat, udara dingin mendadak).
2. Cuci hidung dengan larutan NaCl 0.9% secara teratur.
3. Farmakologis:
   - Antikolinergik topikal: Ipratropium bromida semprot hidung 0.03% (sangat efektif mengurangi rinorea serosa).
   - Kortikosteroid topikal intranasal: Flutikason atau Mometason 1-2 semprot/hari untuk mengurangi kongesti mukosa.
   - Dekongestan oral bila diperlukan dalam durasi singkat.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis THT-KL bila obstruksi hidung berat menetap refrakter terhadap medikamentosa, atau dipertimbangkan tindakan bedah reduksi konka (konkotomi / kauterisasi konka).

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
