---
id: 320
title: "Konjungtivitis Bakteri dan Viral"
slug: "konjungtivitis-bakteri-dan-viral"
icd_10: "H10.9"
category: "Penyakit Mata"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Konjungtivitis Bakteri dan Viral (ICD-10: H10.9)

**Kategori Medis**: Penyakit Mata  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Konjungtivitis adalah peradangan selaput lendir konjungtiva bulbi dan palpebra yang disebabkan oleh infeksi bakteri (Staphylococcus, Streptococcus) atau virus (Adenovirus), ditandai dengan hiperemia konjungtiva dan sekret mata.

---

## 2. Gejala & Manifestasi Klinis
- Mata merah (injeksi konjungtiva)
- Rasa mengganjal seperti berpasir
- Sekret mukopurulen/purulen lengket kelopak mata menempel saat bangun tidur (khas bakteri)
- Sekret serosa/berair dengan pembengkakan kelenjar getah bening preaurikular (khas virus)
- Tidak ada penurunan tajam penglihatan (visus normal)

---

## 3. Kriteria & Alur Diagnosis
Ditegakkan dari pemeriksaan mata luar: visus normal, injeksi konjungtival (pembuluh darah perifer konjungtiva melebar berkelok dan memucat ke arah limbus), sekret purulen atau serosa, kornea jernih, pupil reaktif.

---

## 4. Tatalaksana & Terapi
1. Konjungtivitis Bakteri:
   - Kloramfenikol tetes mata 0.5-1% 1 tetes setiap 2-4 jam atau salep mata kloramfenikol 1% sebelum tidur selama 5-7 hari.
   - Alternatif: Tobramisin 0.3% atau Asam Fusidat tetes mata.
2. Konjungtivitis Viral:
   - Terapi suportif (swasirna dalam 7-14 hari): kompres dingin, air mata buatan (artificial tears) tetes mata 4-6 kali sehari.
3. Menjaga higienitas: tidak menyentuh/mengucek mata, cuci tangan, menggunakan handuk terpisah.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Mata (Sp.M) bila visus menurun, ada fotofobia berat, kecurigaan ulkus kornea, sekret purulen hiperakut masif (curiga konjungtivitis gonore neonatal/dewasa yang membutuhkan terapi seftriakson sistemik), atau tidak membaik dalam 1 minggu.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
