---
id: 164
title: "Katarak Pada Anak"
slug: "katarak-pada-anak"
icd_10: "H25-H28"
category: "Penyakit Anak"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Katarak Pada Anak (ICD-10: H25-H28)

**Kategori Medis**: Penyakit Anak  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Katarak pada anak adalah kekeruhan pada lensa kristalina mata yang timbul sejak lahir (katarak kongenital) maupun didapat selama masa perkembangan anak, yang berpotensi mengganggu stimulus visual aksis optik dan menyebabkan ambliopia deprivasi visual berat bila tidak dioperasi secara dini.

---

## 2. Gejala & Manifestasi Klinis
_Manifestasi klinis tertera pada kriteria diagnostik._

---

## 3. Kriteria & Alur Diagnosis
? 1. Riwayat penyakit pasien harus didapat secara lengkap melalui anamnesis, termasuk penyakit mata yang diderita sebelumnya dan riwayat kehamilan, kelahiran, dan tumbuh kembang anak. Selain itu harus dilakukan pemeriksaan visus lengkap, termasuk fungsi binokular dan ambliopia (Peringkat bukti III, derajat rekomendasi D) 2. Anamnesis harus mencakup riwayat penyakit di keluarga (Peringkat bukti IV, derajat rekomendasi D) 3. Pemeriksaan laboratorium, termasuk serologi dilakukan sesuai dengan manifestasi klinis yang dijumpai. (Peringkat bukti III, derajat rekomendasi D) B. Bagaimana pendekatan operasi pada katarak pada anak? (teknik operasi dan indikasi, pemilihan lensa tanam) 1. Lensektomi sebaiknya dilakukan dengan mesin phacoemulsifikasi (Peringkat bukti IV, derajat rekomendasi D) 2. Aspirasi irigasi lensa (lensektomi) dengan IOL tanpa PPC/vitrektomi anterior dapat dilakukan pada anak-anak yang kooperatif untuk dilakukan kapsulotomi posterior dengan laser Neodymium-doped yttrium aluminum garnet (Nd:YAG) pascabedah (biasanya di atas usia 5 tahun). Tetapi bila operasi dilakukan pada anak lebih dari 5 tahun berkebutuhan khusus wajib dilakukan PPC dengan vitrektomi anterior. (Peringkat bukti IIb, derajat rekomendasi B) 3. Efek ambliogenik dari hipermetropia akan lebih besar pada anak yang lebih muda, sehingga penting segera diberikan kacamata atau lensa kontak pada waktu yang tepat. (Peringkat bukti IV, derajat rekomendasi D) 4. Ukuran luka bukanlah menjadi prioritas pada pasien anak dikarenakan semua luka yang dibuat saat tindakan operasi haruslah ditutup dengan jahitan. luka operasi dapat dijahit dengan benang nilon ataupun polyglycolic acid (PGA) berukuran 10/0. - 28 - 5. Penggunaan teknik bimanual dapat menurunkan fluktuasi pada bilik mata depan dan penggunaan teknik ini direkomendasikan (Peringkat bukti IIb, derajat rekomendasi B) 6. Tindakan kapsulotomi posterior primer direkomendasikan untuk dilakukan lewat luka yang telah dibuat, sebelum pemasangan lensa IOL, atau dilakukan setelah pemasangan lensa IOL dan penutupan luka, dengan pendekatan limbal atau pars plicata / pars plana pada anak dengan usia 6 tahun kebawah atau yang tidak kooperatif untuk dilakukan Nd: YAG laser. (Peringkat bukti IIb, derajat rekomendasi B) 7. Saat dilakukannya tindakan kapsulotomi posterior dan vitrektomi anterior dengan implantasi IOL pada anak berusia di bawah 2 tahun, orang tua anak harus diberitahu mengenai kemungkinan dilakukannya tindakan operasi kedua untuk menjernihkan aksis visual. (Peringkat bukti IV, derajat rekomendasi D) 8. Pada saat operasi, diameter horizontal kornea harus diukur. Glaukoma afakia / pseudofakia adalah komplikasi yang umum terjadi pasca operasi katarak kongenital.20-24,65,66 Setiap anak yang menjalani operasi katarak harus dilakukan evaluasi berkala untuk deteksi dini glaukoma. (Peringkat bukti IIb, derajat rekomendasi B) C. Bagaimana persiapan pre operasi katarak pada anak? Persiapan pre-operasi dalam tindakan pembedahan katarak pada anak harus dilakukan secara langsung (tidak melihat hasil pemeriksaan mata sebelumnya). (Rekomendasi IV, derajat rekomendasi D) D. Bagaimana pasca operasi katarak pada anak?

---

## 4. Tatalaksana & Terapi
subkonjungtiva pasca operasi (Rekomendasi IV, derajat rekomendasi D). Pemberian steroid topikal (prednisolone asetat 1% atau difluprednat 0,05%) 4 kali sehari selama 14 hari terbukti efektif dan aman untuk mengurangi inflamasi setelah operasi katarak pada anak umur 0-3 tahun. (Peringkat bukti Ib, derajat rekomendasi A)

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk SEGERA ke Dokter Spesialis Mata Konsultan Pediatrik Oftalmologi di RS rujukan tingkat lanjut untuk pencegahan ambliopia deprivasi berat dan perencanaan lensektomi dini.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2020
