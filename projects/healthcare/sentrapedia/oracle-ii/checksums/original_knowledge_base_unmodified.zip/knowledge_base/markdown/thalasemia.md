---
id: 173
title: "Thalasemia"
slug: "thalasemia"
icd_10: "D56"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Thalasemia (ICD-10: D56)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Thalasemia adalah kelompok kelainan hemoglobinopati genetik herediter resesif autosomal yang ditandai dengan penurunan atau tidak adanya sintesis rantai polipeptida globin (globin alfa atau beta), mengakibatkan eritropoiesis inefektif, anemia hemolitik kronik, dan overload besi sekunder.

---

## 2. Gejala & Manifestasi Klinis
- yang muncul dapat berupa tanda dan gejala hepatitis kronik dan akut, gejala obstruksi pada sistem bilier, kolangitis, hipertensi portal, dan keganasan. Kelasi besi deferipron memiliki efek toksik pada hati. Kenaikan ringan nilai transaminase umum terjadi -65- pada pasien yang menggunakannya, terutama pada pasien dengan antibodi hepatitis C positif, namun hal ini tidak bersifat progresif dan belum perlu untuk menghentikan terapi. Tata laksana ditujukan untuk menjaga fungsi hati dan mencegah terjadinya kerusakan hati yang disebabkan oleh virus hepatitis, toksisitas besi, dan efek samping kelasi besi. Fungsi hati perlu dipantau secara berkala, dan kadar besi di hati dijaga dalam batas aman sehingga tidak terjadi kerusakan hati progresif. Perlu dilakukan penyesuaian dosis obat kelasi besi apabila sudah terjadi penurunan fungsi hati. Transmisi virus hepatitis diminimalisasi dengan memberikan darah yang sudah diskrining. Tata laksana komplikasi disupervisi bersama dengan hepatolog anak. Penggunaan obat seperti monoterapi interferon, terapi kombinasi interferon-α dan ribavirin, atau PEG-interferon dengan ribavirin dapatmenurunkan jumlah virus (mengupayakan viral clearance) hingga 40%, dan pasien yang sudah mulai mengalami sirosis juga masih mendapatkan manfaat dari terapi ini. Terapi yang paling baik untuk saat ini adalah kombinasi antara PEG-interferon alfa dan ribavirin. Durasi pengobatan ditentukan berdasarkan genotip HCV dan hasil dari viral load. Kombinasi terapi ini dapat menyebabkan hemolisis dan kebutuhan transfusi meningkat, sehingga diperlukan pemberian kelasi besi secara intensif setelah selesai pengobatan. Tidak terdapat data yang mendukung bagaimana efek yang ditimbulkan akibat penggunaan deferipron atau deferasiroks bersama dengan penggunaan antivirus tersebut. Penelitian menunjukkan perburukan fibrosis hepatitis pada pasien dengan kadar besi hati tinggi dan hepatitis C post-transplantasi sumsum tulang, sedangkan fibrosis hepatitis biasanya terjadi pada pasien dengan kelebihan besi hati yang tinggi (>16 mg/g berat kering hati). Secara umum, pada pasien dengan atau tanpa hepatitis, kadar besi hati harus dapat dijaga dalam kadar aman yaitu 2-7 mg/g berat kering pada pemeriksaan MRI, sedangkan biopsi hati dilakukan untuk menentukan staging kerusakan hati. -66- REKOMENDASI Pemantauan komplikasi dilakukan dengan uji fungsi hati; ALT, AST dan feritin serum tiap 3 bulan, serta pemeriksaan virologi dan serologi hepatitis setiap tahun. (GRADE A) Vaksinasi hepatitis dilakukan sebelum pertama kali transfusi, dan selanjutnya dilengkapi dengan booster. (GRADE B) Pemantauan kadar besi hati paling baik dilakukan dengan pemeriksaan MRI (R2* atau T2*). (GRADE B) Monitoring hepatitis C dilakukan setiap 6 bulan. (GRADE C)

---

## 3. Kriteria & Alur Diagnosis
bahwa pengakhiran kehamilan pada janin yang terdiagnosis thalassemia mayor diizinkan sebelum usia 120 hari (usia gestasi 17 minggu).

---

## 4. Tatalaksana & Terapi
dibutuhkan untuk terapi pasien thalassemia mayor selama hidupnya (asumsi usia harapan hidup 30 tahun) adalah sebesar US$ 284.154 /orang. Biaya tersebut terdiri dari biaya transfusi (33,1%), biaya terapi kelasi besi (22,1%), dan sisanya (44,8%) adalah biaya untuk perawatan di rumah sakit, biaya rawat jalan, biaya operasi, biaya laboratorium, biaya jasa konsultasi dan biaya lainnya yang diperlukan, sesuai dengan standar prosedur dari rumah sakit setempat (Sharai Zedek Medical Center dan Hadassah-Ein Kerem Hospital University, Yerusalem). Sementara itu program skrining nasional diperkirakan sebesar US$ 900.197 dan diharapkan dapat mencegah kelahiran bayi thalassemia mayor sebanyak 13,4 orang, atau sekitar US$ 67.369/kelahiran. Rasio biaya yang dibutuhkan antara pengobatan dan pencegahan adalah 4.22:1, dimana pencegahan thalassemia lebih cost-effective dibanding pengobatan. 9. Implikasi Skrining terhadap psikososial, etikolegal, dan agama Implikasi psikososial Implikasi skrining thalassemia terhadap kondisi psikososial dapat berakibat negatif bila tidak disertai edukasi yang baik, sehingga edukasi masyarakat merupakan langkah awal dalam program -87- pencegahan thalassemia. Tanpa diawali edukasi masyarakat yang optimal, skrining thalassemia akan menimbulkan keresahan di masyarakat yang mengakibatkan stigmatisasi terhadap karier atau pasien dan berlanjut pada adanya diskriminasi dalam mendapat pekerjaan serta asuransi kesehatan, seperti yang pernah terjadi di Amerika Serikat dengan mewajibkan skrining terhadap penyakit sel sabit. Konseling pada individu dan pasangan yang mengidap thalassemia (karier, intermedia atau mayor) sangat penting karena adanya implikasi moral dan psikologis ketika pasangan karier dihadapkan pada beberapa opsi reproduksi. Pilihan yang tersedia tidak mudah dan mungkin tiap pasangan memiliki pilihan yang berbeda-beda. Tanggung jawab utama seorang konselor adalah memberikan informasi yang akurat dan komprehensif sehingga memungkinkan pasangan karier menentukan pilihan yang paling mungkin mereka jalani sesuai kondisi masing-masing seperti Tabel 4 berikut ini : Tabel 5. Kemungkinan pilihan yang diambil karier thalassemia Implikasi terhadap jasa asuransi Di Iran, pemerintah membiayai perencanaan program, edukasi, konseling dan surveilans, sementara biaya skrining (sekitar $5), ditanggung oleh pasangan yang akan menikah. Asuransi kesehatan

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Pusat Penanganan Thalasemia / Dokter Spesialis Anak (Sp.A) / Sp.PD Hematologi-Onkologi untuk penetapan protokol transfusi darah PRC teratur (target pre-transfusi Hb 9.5-10.5 g/dL) dan terapi kelasi besi (deferasirox/deferiprone/deferoxamine).

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2018
