---
id: 288
title: "Retinopati Diabetika"
slug: "retinopati-diabetika"
icd_10: "E10.3-E11.3"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Retinopati Diabetika (ICD-10: E10.3-E11.3)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
CSME didefinisikan sebagai salah satu atau lebih dari kriteria berikut: 1) Penebalan retina pada atau dalam 500μm dari fovea. 2) Eksudat kasar pada atau dalam 500μm dari fovea yang berdekatan dengan retia yan menebal. 3) Area pada retina yang menebal dalam jarak satu diskus, setidaknya dalam satu disc diameter dari fovea. Meskipun pasien dengan penglihatan sentral normal dan CSME diikutsertakan dalam studi, namun keuntungan yang

---

## 2. Gejala & Manifestasi Klinis
- : a. Asimtomatik (tidak ada gejala); bila kelainan pada retinopati diabetika belum menyebabkan gangguan pada makula atau media penglihatan. b. Penglihatan buram. c. Floaters. d. Penglihatan mendadak terhalang (pada perdarahan vitreus). e. Flashes. f. Tirai bayangan (bila terjadi lepasnya retina). g. Rasa sakit pada/sekitar mata (akibat tekanan bola mata meningkat pada glaukoma neovaskular).

---

## 3. Kriteria & Alur Diagnosis
pemeriksaan mata diharuskan melakukan skrining RD. 2. Follow up harus dilakukan setidaknya 1 kali dalam setahun pada penderita DM tanpa RD. Pada penderita RD dilakukan follow up sesuai panduan bergantung derajat tingkat keparahan RD. 3. Anti-VEGF merupakan pilihan terapi untuk pengobatan EMD

---

## 4. Tatalaksana & Terapi
memerlukan terapi serta sebagai adjuvant pada terapi PDR atas indikasi. 3. Tindakan injeksi intravitreal harus didukung oleh pemeriksaan penunjang yaitu OCT makula. 4. Tindakan injeksi intravitreal dilakukan atas indikasi sesuai dengan guidelines yang berlaku oleh dokter spesialis mata yang memiliki kompetensi. 5. Vitrektomi dilakukan atas indikasi sesuai guidelines yang berlaku dan dilakukan oleh dokter spesialis mata yang telah memiliki kompetensi. MENTERI KESEHATAN REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Dokter Spesialis Mata (Sp.M) Vitreoretina untuk pemeriksaan funduskopi berkala, Optical Coherence Tomography (OCT), fundus fluorescein angiography (FFA), panretinal photocoagulation (PRP), atau injeksi anti-VEGF intravitreal.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2023
