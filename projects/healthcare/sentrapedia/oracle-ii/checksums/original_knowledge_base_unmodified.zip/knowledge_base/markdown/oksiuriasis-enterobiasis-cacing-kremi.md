---
id: 301
title: "Oksiuriasis (Enterobiasis / Cacing Kremi)"
slug: "oksiuriasis-enterobiasis-cacing-kremi"
icd_10: "B80"
category: "Penyakit Infeksi"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Oksiuriasis (Enterobiasis / Cacing Kremi) (ICD-10: B80)

**Kategori Medis**: Penyakit Infeksi  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Oksiuriasis adalah infeksi usus yang disebabkan oleh cacing kremi Enterobius vermicularis, sangat menular antaranggota keluarga melalui autoinfeksi dan kontak feses-oral.

---

## 2. Gejala & Manifestasi Klinis
- Pruritus ani nokturnal (gatal hebat di area perianal terutama malam hari)
- Tidur gelisah dan rewel pada anak
- Ekskoriasi lecet kulit perianal akibat garukan
- Kadang terlihat cacing kecil putih seperti benang bergerak di perianal/tinja

---

## 3. Kriteria & Alur Diagnosis
Diagnosis ditegakkan dari keluhan gatal perianal malam hari. Penegakan pasti menggunakan metode Graham tape test (scotch adhesive tape swab pada kulit perianal pagi hari sebelum mandi): pemeriksaan mikroskopis menunjukkan telur cacing asimetris lonjong pipih di satu sisi.

---

## 4. Tatalaksana & Terapi
1. Farmakologis (Wajib diulang 2 minggu kemudian untuk memutus siklus cacing matang baru):
   - Pirantel Pamoat: 10-11 mg/kgBB oral dosis tunggal (maksimum 1 gram), diulang setelah 2 minggu.
   - Albendazol: 400 mg oral dosis tunggal, diulang setelah 2 minggu.
   - Mebendazol: 100-500 mg oral dosis tunggal, diulang setelah 2 minggu.
2. Pengobatan serentak seluruh anggota keluarga yang tinggal serumah.
3. Edukasi kebersihan: mencuci seprai pakaian dengan air panas, memotong kuku pendek, mencuci tangan.

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke FKRTL bila terjadi komplikasi salpingitis/vulvovaginitis cacing kremi ektopik pada anak perempuan atau infeksi sekunder selulitis perianal refrakter.

---

## 6. Referensi & Dasar Regulasi
- **Permenkes**: Permenkes No. 5 Tahun 2014 (2014)
- **KMK**: KMK No. HK.01.07/MENKES/1186/2022 (2022)
