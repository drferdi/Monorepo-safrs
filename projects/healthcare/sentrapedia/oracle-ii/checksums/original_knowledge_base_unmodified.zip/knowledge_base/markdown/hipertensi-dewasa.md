---
id: 221
title: "Hipertensi Dewasa"
slug: "hipertensi-dewasa"
icd_10: "I10"
category: "Penyakit Jantung dan Pembuluh Darah"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Hipertensi Dewasa (ICD-10: I10)

**Kategori Medis**: Penyakit Jantung dan Pembuluh Darah  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Penyulit memiliki definisi yang sama dengan komplikasi yaitu penyakit yang timbul sebagai tambahan penyakit lain yang sudah ada. Komplikasi pada DM dapat berupa akut maupun kronis.

---

## 2. Gejala & Manifestasi Klinis
- berhubungan dengan eksaserbasi gejala klaudikasio pada pasien iskemia tungkai akut ringan hingga sedang. Pada aterosklerosis karotis, perlu dipertimbangkan pemberian ACEi dan CCB, karena telah terbukti bahwa kedua obat ini dapat memperlambatkan proses aterosklerosis dibandingkan dengan beta-bloker dan diuretik. Pada pasien dengan pulse wave velocity >10 m/det, perlu dipertimbangkan pemberian semua jdih.kemkes.go.id - 75 - antihipertensi, sehingga tercapai target tekanan darah sistolik <140 mmHg yang menetap. Direkomendasikan untuk memberikan antihipertensi pada pasien penyakit arteri perifer, dengan target tekanan darah sistolik <140 mmHg, karena memiliki risiko tinggi terjadinya infark miokard, stroke, gagal jantung, maupun kematian kardiovaskular. Walaupun memerlukan pengawasan lebih lanjut, pemberian betabloker dapat dipertimbangkan pada pasien dengan penyakit arteri perifer, karena obat ini tidak terbukti berhubungan dengan eksaserbasi gejala penyakit ini. Tabel 33. Rekomendasi strategi terapi hipertensi dengan gangguan arteri perifer ekstremitas bawah Rekomendasi Peringkat Derajat Bukti Rekomendasi

---

## 3. Kriteria & Alur Diagnosis
1. Pemeriksaan tekanan darah lebih dari satu kali kunjungan, kecuali jika pada hipertensi yang berat (grade 3 and khususnya pada pasien risiko tinggi). Setiap kunjungan klinik, pengukuran TD dilakukan terpisah 1-2 menit, pengukuran tambahan dilakukan jika pada dua pengukuran awal memiliki perbedaan >10mmHg. TD pasien adalah nilai rata-rata dari dua pengukuran terakhir. Peringkat bukti I, derajat rekomendasi C; atau 2. Pengukuran TD diluar klinik dengan metode ABPM dan/atau HBPM, terbukti secara logistik dan ekonomis layak dilakukan. Peringkat bukti I, derajat rekomendasi C. Inisiasi pemberian obat antihipertensi direkomendasikan pada pasien dengan hipertensi derajat 2 atau 3, pada level berapapun dengan risiko CVD, terapi dilakukan bersamaan dengan perubahan gaya hidup. Peringkat bukti I, derajat rekomendasi A. Pada pasien dengan hipertensi derajat 1: 1. Intervensi gaya hidup direkomendasikan untuk menurunkan tekanan darah. Peringkat bukti I, derajat rekomendasi B. 2. Pada pasien dengan hipertensi derajat 1 dengan risiko rendah-moderat dan tanpa bukti HMOD, pemberian obat antihipertensi direkomendasikan jika pasien tetap hipertensi setelah intervensi gaya hidup. Peringkat bukti I, derajat rekomendasi A. 3. Pada pasien dengan hipertensi derajat satu dengan risiko tinggi atau dengan bukti kerusakan obat akibat hipertensi, pemberian obat antihipertensi direkomendasikan bersamaan dengan intervensi gaya hidup. Peringkat I, derajat rekomendasi A. jdih.kemkes.go.id - 83 - Pada pasien lanjut usia yang fit (>80 tahun), pemberian obat antihipertensi dan intervensi gaya hidup direkomendasikan ketika TDS ≥160 mmHg. Peringkat bukti I, derajat rekomendasi A. Pemberian obat antihipertensi dan intervensi gaya hidup direkomendasikan pada pasien lanjut usia yang fit (usia 60-80 tahun) dengan TDS pada hipertensi derajat I (140-159 mmHg). Bukti peringkat I, derajat rekomendasi A. Pada pasien dengan TD normal-tinggi (130-139/85-89 mmHg), perubahan gaya hidup direkomendasikan. Peringkat bukti I, derajat rekomendasi A. Target objektif terapi TD direkomendasikan <140/90 mmHg pada semua pasien, jika terapi dapat ditoleransi, target TD sebaiknya mencapai 130/80 mmHg atau lebih rendah. Peringkat bukti I, derajat rekomendasi A. Pada pasien usia <60 tahun yang menerima terapi obat antihipertensi, target TDS direkomendasikan pada rentang 120-129 mmHg. Peringkat bukti I, derajat rekomendasi A. Pada pasien dengan usia ≥60 tahun yang menerima terapi obat antihipertensi, target TDS direkomendasikan pada rentang 130-139 mmHg, Peringkat bukti I, derajat rekomendasi A. Retriksi garam <5g per hari direkomendasikan. Peringkat bukti I, derajat rekomendasi A. Peningkatan konsumsi sayuran, buah segar, ikan, kacang-kacangan, lemak tidak jenuh (minyak zaitun); pembatasan konsumsi daging merah, dan konsumsi produk susu rendah lemak direkomendasikan. Peringkat bukti I, derajat rekomendasi A. Kontrol berat badan diindikasikan untuk mencegah obesitas BMI >30 kg/m2, atau lingkar pinggang >102 cm pada laki-laki dan >88 cm pada perempuan, dan target BMI ideal (20-25 kg/m2), lingkar pinggang <94 cm pada laki-laki dan <80cm pada perempuan direkomendasikan untuk mengurangi risiko hipertensi dan risiko kardiovaskular. Peringkat bukti I, derajat rekomendasi A. Olahraga aerobik secara regular (≥30 menit olahraga moderat dinamis 5-7 kali perminggu) direkomendasikan. Peringkat bukti I, derajat rekomendasi A.

---

## 4. Tatalaksana & Terapi
, kombinasi RAS (penghambat ACE atau ARB) dengan CBB atau diuretik direkomendasikan. Kombinasi beta-bloker dengan golongan obat antihipertensi lain direkomendasikan pada kasus klinis spesifik. G. Jika TD tidak terkontrol dengan kombinasi dua obat antihipertensi, direkomendasikan memberikan kombinasi tiga obat antihipertensi dengan bloker RAS, dengan CCB dan thiazide/thiazide-like diuretik. H. Jika TD tidak terkontrol dengan kombinasi tiga obat antihipertensi, direkomendasikan penambahan terapi spironolakton atau, jika tidak ditoleransi dengan baik, dapat menggunakan diuretik seperti amilorid atau dosis diuretik yang lebih tinggi, penyekat beta atau alpha-bloker. I. Dalam mengelola pasien hipertensi, dokter bisa menilai kapan harus merujuk ke fasilitas pelayanan kesehatan yang lebih tinggi. MENTERI KESEHATAN REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 5. Kriteria Rujukan (FKRTL)
(FKRTL) Hipertensi terkontrol adalah kondisi normotensi pada pasien hipertensi yang telah melakukan modifikasi gaya hidup dan/atau memperoleh pengobatan. Tata laksana hipertensi umumnya dilakukan di fasilitas kesehatan tingkat pertama (FKTP). Pasien hipertensi agar tidak berlanjut terjadi komplikasi kardioserebrovaskular dan ginjal memerlukan evaluasi, tata laksana ataupun perawatan lebih lanjut di FKRTL. Pasien hipertensi harus dirujuk ke FKRTL apabila mengalami: hipertensi krisis, hipertensi sekunder, hipertensi dengan kerusakan organ target, hipertensi resisten dan hipertensi yang disertai dengan aritmia. jdih.kemkes.go.id - 81 - Selama pemantauan klinis, apabila ditemukan beberapa indikasi tertentu, yaitu: tekanan darah sistolik >140 mmHg, atau diastolik >90 mmHg dalam 3 bulan berturut-turut; pasien yang disertai dengan dislipidemia, hipertensi, anemia, infeksi, retinopati, lansia, TBC paru atau lainnya; tidak tercapainya target tekanan darah dalam 3 bulan dengan antihipertensi tunggal/kombinasi; kehamilan dan gagal jantung, maka pasien harus dirujuk ke FKRTL. jdih.kemkes.go.id - 82 - BAB IV RANGKUMAN PERINGKAT BUKTI DERAJAT REKOMENDASI Tekanan darah diklasifikasikan sebagai optimal, normal, normal-tinggi, hipertensi derajat 1-3, berdasarkan pengukuran TD di klinik. Peringkat bukti I, derajat rekomendasi C. Program screening untuk hipertensi direkomendasikan untuk semua usia dewasa (≥18tahun). Tekanan darah diukur pada kunjungan klinik dan ditulis pada rekam medis. Peringkat bukti I, derajat rekomendasi B.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2021
