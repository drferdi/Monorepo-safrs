---
id: 279
title: "Bibir Sumbing"
slug: "bibir-sumbing"
icd_10: "Q36.9"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Bibir Sumbing (ICD-10: Q36.9)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Sumbing adalah terdapatnya celah pada bibir atas akibat kegagalan organogenesis pada perkembangan embriologi. Kelainan ini dapat disertai dengan celah pada lelangit yaitu celah pada lelangit mulut sehingga antara hidung dan mulut terdapat hubungan langsung.

---

## 2. Gejala & Manifestasi Klinis
_Manifestasi klinis tertera pada kriteria diagnostik._

---

## 3. Kriteria & Alur Diagnosis
Diagnosis bibir sumbing dan lelangit dapat dilakukan sejak prenatal. Perlu dipikirkan kemungkinan kelainan bibir sumbing dan lelangit sebagai penyerta pada kelainan sindromik seperti sindrom Pierre Robin. B. Tata laksana Tata laksana bibir sumbing dan lelangit perlu penanganan multidisiplin untuk mengatasi berbagai masalah yang muncul selain tindakan pembedahan. Peran serta orang tua diperlukan karena tata laksana bibir sumbing dan lelangit memerlukan jangka waktu yang panjang. - 43 - Daftar Pustaka 1. Chang J, Neligan PC. Plastic surgery. Vol 6: Elsevier Health Sciences; 2012. 2. Thorne CH, Chung KC, Gosain AK, et al. Grabb and Smith's plastic surgery. 2013. 3. Fisher DM. Unilateral cleft lip repair: an anatomical subunit approximation technique. Plastic and reconstructive surgery. 2005;116(1):61-71. 4. Baek R-M, Choi J-h, Kim B-k. Practical repair method for unilateral cleft lips: straight-line advanced release technique. Annals of plastic surgery. 2016;76(4):399-405. 5. Leow A-M. MD; Lun-Jou Lo, MD. Palatoplasty: Evolution and Controversies. 2008;31:335-345. 6. Grayson BH, Maull D. Nasoalveolar molding for infants born with clefts of the lip, alveolus, and palate. Paper presented at: Seminars in plastic surgery2005. 7. Grayson BH, Cutting CB. Presurgical nasoalveolar orthopedic molding in primary correction of the nose, lip, and alveolus of infants born with unilateral and bilateral clefts. The Cleft palate-craniofacial journal. 2001;38(3):193-198. 8. Santiago PE, Grayson BH. Role of the craniofacial orthodontist on the craniofacial and cleft lip and palate team. Paper presented at: Seminars in Orthodontics2009. 9. Nagarajan R, Savitha V, Subramaniyan B. Communication disorders in individuals with cleft lip and palate: An overview. Indian Journal of Plastic Surgery: Official Publication of the Association of Plastic Surgeons of India. 2009;42(Suppl):S137. 10. Sell D, Harding A, Grunwell P. A screening assessment of cleft palate speech (Great Ormond Street Speech Assessment). International Journal of Language & Communication Disorders. 1994;29(1):1-15. 11. Smith B, Guyette TW. Evaluation of cleft palate speech. Clinics in plastic surgery. 2004;31(2):251-260. 12. Shprintzen RJ, Marrinan E. Velopharyngeal insufficiency: diagnosis and management. Current opinion in otolaryngology & head and neck surgery. 2009;17(4):302. - 44 - 13. Wirthlin JO. The orthodontist’s role in the management of patients with cleft lip and palate undergoing alveolar bone grafting. Paper presented at: Seminars in Orthodontics2017. 14. Peamkaroonrath C, Godfrey K, Chatrchaiwiwatana S. New clinical method for alveolar bone graft evaluation in cleft patients: a pilot study. The Cleft Palate-Craniofacial Journal. 2011;48(3):286-292. 15. Bratzler DW, Dellinger EP, Olsen KM, et al. Clinical practice guidelines for antimicrobial prophylaxis in surgery. Surgical infections. 2013;14(1):73- 156. 16. Laxmikanth S, Karagi T, Shetty A, Shetty S. Nasoalveolar molding: A review. J Adv Clin Res Insights. 2014;1(3):108-113. 17. Mishra B, Singh AK, Zaidi J, Singh G, Agrawal R, Kumar V. Presurgical nasoalveolar molding for correction of cleft lip nasal deformity: experience from northern India. Eplasty. 2010;10. 18. Mosmuller D, Bijnen C, Kramer G, et al. The Asher-McDade aesthetic index in comparison with two scoring systems in nonsyndromic complete unilateral cleft lip and palate patients. Journal of Craniofacial Surgery. 2015;26(4):1242-1245. 19. Trindade IK, Mazzottini R, da Silva Filho OG, Trindade IEK, Deboni MCZ. Long-term radiographic assessment of secondary alveolar bone grafting outcomes in patients with alveolar clefts. Oral Surgery, Oral Medicine, Oral Pathology, Oral Radiology, and Endodontology. 2005;100(3):271-277. MENTERI KESEHATAN REPUBLIK INDONESIA, ttd NILA FARID MOELOEK

---

## 4. Tatalaksana & Terapi
kombinasi terapi artikulasi dan perawatan gigi dapat membantu meminimalkan masalah. Adapun fungsi bicara dan Bahasa juga dipengaruhi oleh fungsi pendengaran, maka harus dipastikan bahwa fungsi pendengaran anak juga baik sehingga tata laksana bicara dan bahasa akan lebih optimal. L. Tata laksana masalah pendengaran pada sumbing (untuk THT-KL) Meskipun anak dengan sumbing lelangit dapat menderita penurunan pendengaran. Kebanyakan hilangnya fungsi pendengaran dikarenakan gangguan konduktif akibat adanya akumulasi cairan di telinga tengah. Otitis media pada anak dapat mengakibatkan berkurangnya sedikit pendengaran secara sementara (mild hearing loss). Pendengaran akan pulih sejalan dengan sembuhnya infeksi telinga. Oleh karena itu pentingnya kontrol rutin ke dokter THT-KL dapat memberikan tata laksana cepat dan evaluasi masalah pendengaran pada anak dengan sumbing. Untuk pre- dan post-operasi dilakukan timpanometri, OAE, nasometri, atau tes subjektif (minimal 2 orang) dan palatometri (bekerjasama dengan bagian prostodonti untuk membuat dasar lelangit). Habilitasi dan Rehabilitasi dapat dilakukan 3 bulan pasca-operasi. Tata laksana pendengaran pada otitis media efusi (OME) memantau selama 3 bulan sejak mendapatkan diagnosis, menggunakan intra-nasal steroids atau systematic steroids, antibitoik dan antihistamin atau decongestan. Dinilai perlu tidaknya pemasangan tympanostomy tube pada anak berusia ≤4 tahun. M. Skrining velopharingeal insuficiency Velopharyngeal insufficiency adalah masalah yang timbul akibat adanya hubungan langsung antara rongga hidung dan mulut. Adanya defek anatomis pada soft palate dan dinding faring bagian lateral atau posterior. Efek yang ditimbulkan dari VPI adalah suara hipernasal (sengau), aspirasi, dan gangguang asupan nutrisi. Pemeriksaan untuk

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk ke Spesialis Bedah Plastik Rekonstruksi atau Bedah Mulut di RS rujukan untuk program operasi labioplasti (rule of tens: usia > 10 minggu, BB > 10 pon, Hb > 10 g/dL) dan palatoplasti (usia 10-18 bulan).

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2019
