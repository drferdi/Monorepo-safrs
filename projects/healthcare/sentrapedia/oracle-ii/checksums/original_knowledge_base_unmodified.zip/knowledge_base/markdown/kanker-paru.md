---
id: 254
title: "Kanker Paru"
slug: "kanker-paru"
icd_10: "C33-C34"
category: "Penyakit Paru"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Kanker Paru (ICD-10: C33-C34)

**Kategori Medis**: Penyakit Paru  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
ICF mendefinisikan tiga domain fungsi manusia yakni struktur dan fungsi tubuh, aktivitas dan partisipasi. Domain struktur dan fungsi tubuh mengacu pada fungsi anatomi dan fisiologi sistem tubuh yang bila mengalami gangguan disebut impairment. Domain aktivitas menggambarkan kemampuan individu untuk menjalankan tugas spesifik dan bila terjadi gangguan akan terjadi limitasi aktivitas. Sedangkan domain partisipasi menggambarkan kemampuan individu untuk terlibat dalam sebuah situasi kehidupan, menjalankan perannya secara normal dan berinteraksi dengan lingkungan sosial. Dengan demikian, kondisi kesehatan, faktor individu dan lingkungan saling berinteraksi secara dinamis di antara tiga domain tersebut. jdih.kemkes.go.id - 73 - Gambar 6. Klasifikasi ICF (The International Classification of Functioning, Disability, and Health) Dalam ranah onkologi, ICF mempunyai berbagai tujuan di antaranya, mengevaluasi kemampuan fungsional penderita kanker, memandu asesmen rehabilitasi onkologi, melakukan asesmen terhadap keluaran komprehensif yang juga berguna pada penelitian onkologi, melakukan seleksi terhadap instrumen kualitas hidup yang akan digunakan dan menilai fokus utama profesional kesehatan dan penderita kanker yang sedang ditanganinya. 1. Rehabilitasi Kanker Paru Pendekatan kedokteran fisik dan rehabilitasi bertujuan untuk mengoptimalkan pengembalian kemampuan fungsi dan aktivitas kehidupan sehari-hari, serta meningkatkan kualitas hidup penderita dengan cara aman dan efektif, sesuai dengan kemampuan penderita. Intervensi rehabilitasi dapat diberikan sedini mungkin sebelum pengobatan definitif, pada berbagai tahapan pengobatan penyakit yang meliputi upaya rehabilitasi preventif, restoratif, suportif atau paliatif. Sebagaimana Dietz (1969) telah menyusun suatu sistem

---

## 2. Gejala & Manifestasi Klinis
- Berkurangnya kekuatan otot 2. Fatigue 3. Anoreksia jdih.kemkes.go.id - 65 - 4. Indeks massa bebas lemak rendah 5. Laboratorium abnormal: Peningkatan petanda inflamasi (IL-6>4pg/dL, CRP>5 mg/L) Anemia (Hb < 12g/dL) a. b. Hipoalbuminemia (<3,2g/dL) c.

---

## 3. Kriteria & Alur Diagnosis
penderita didiagnosis kanker dan sesuai dengan kondisi klinis penderita [rekomendasi A]. Pada penderita dengan hasil skrining abnormal, perlu dilakukan penilaian objektif dan kuantitatif dari asupan nutrisi, kapasitas fungsional, dan derajat inflamasi sistemik. Disarankan untuk melakukan skrining rutin pada semua penderita kanker lanjut, baik yang menerima maupun tidak menerima terapi antikanker, untuk menilai asupan nutrisi yang tidak adekuat, penurunan berat dan IMT yang rendah, yang dilanjutkan dengan asesmen gizi apabila berisiko. Untuk kebutuhan nutrisi penderita kanker, direkomendasikan agar kebutuhan energi total penderita kanker, jika tidak diukur secara individual, jdih.kemkes.go.id - 89 - diasumsikan agak mirip dengan subjek sehat, yaitu berkisar antara 25-30 kkal/kg BB/hari. Selama menjalani terapi kanker, perlu dipastikan bahwa penderita mendapat nutrisi adekuat [rekomendasi A]. Direkomendasikan pemberian vitamin dan mineral sebesar satu kali angka kecukupan gizi [rekomendasi A]. Penderita kanker lanjut yang tidak merespons terapi nutrisi standar, disarankan untuk mempertimbangkan suplementasi BCAA untuk meningkatkan massa otot [rekomendasi D].

---

## 4. Tatalaksana & Terapi
terapi serta akses yang adil dan merata untuk pelayanan kesehatan serta sistem penunjang sosial yang terjangkau, diperlukan untuk meningkatkan kualitas hidup penderita kanker paru [rekomendasi A]. MENTERI KESEHATAN REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 5. Kriteria Rujukan (FKRTL)
Rekomendasi rujukan penderita kanker paru tahap lanjut antara lain untuk tatalaksana rehabilitasi paliatif: 1) Penderita yang diduga akan meninggal dalam kurun waktu satu tahun 2) Status atau performa fungsional buruk (asesmen dengan Eastern Cooperative Oncology Group [ECOG] status III atau lebih) 3) Mengalami gejala fisik atau emosional berat Tata laksana Rehabilitasi Paliatif 1) Nyeri kanker dengan berbagai penyebab Tata laksana : lihat poin b(1) 2) Gangguan respirasi : sesak Tata laksana sesuai kondisi penderita : positioning, relaksasi, kontrol pernapasan, masase, distraksi, latihan pernafasan, koreksi postur, teknik konservasi energi 3) Gangguan mobilisasi pada kasus : tirah baring lama, kelemahan umum, fatigue Tata laksana : lihat poin c(1) 4) Gangguan fungsi pada metastasis dan hendaya otak Tata laksana : lihat poin c(7) 5) Gangguan mobilisasi pada kasus metastasis tulang dan cedera medula spinalis Tata laksana : lihat poin c(8) 6) Gangguan psiko-sosio-spiritual Tata laksana : kondisi sosial dan perilaku rawat 7) Penurunan kualitas hidup jdih.kemkes.go.id - 81 - Terdapat banyak studi yang menunjukkan besarnya manfaat perawatan paliatif, diantaranya studi Temel et al. (2010) pada penderita kanker paru karsinoma bukan sel kecil tahap lanjut yang memperoleh layanan paliatif lebih awal, didapatkan ada perbaikan yang signifikan pada kualitas hidup dan suasana hati penderita, serta meminimalkan perawatan agresif pada akhir kehidupan namun memiliki harapan hidup yang lebih besar. Advance Care Planning (ACP) perlu dilakukan untuk mendapatkan pelayanan yang optimal dan efisien. ACP mengacu pada proses di mana penderita, keluarga, dan profesional kesehatan mendiskusikan dan menyusun rencana tujuan perawatan yang disesuaikan dengan nilai-nilai dan pilihan penderita, yang akan dilakukan terutama pada saat menjelang akhir kehidupannya. J. Complementary Paliatif Pada kasus kanker paru stage 3B dan 4 (inoperable), maka terapi komplementer yang bertujuan paliatif dapat dipertimbangkan seperti modalitas laser surgery dan microwave ablasion. Tindakan tersebut di atas tidak bertujuan untuk menggantikan terapi utama kanker paru, tetapi sebagai bagian dari terapi paliatif. K. Evaluasi dan Tindak Lanjut (Follow-Up) Setelah terapi awal dan penilaian respons lengkap atau parsial atau tetap, penderita akan menjalani pemeriksaan setiap 3-4 bulan selama 2 tahun pertama. Penderita kemudian dapat menjalani pemeriksaan setiap 6 bulan untuk 3 tahun berikutnya. Pemeriksaan yang dilakukan termasuk anamnesis, pemeriksaan fisik, CT scan, pemeriksaan laboratorium, dan pemeriksaan lainnya sesuai kebutuhan. Jika ditemukan lesi baru, dilakukan pemeriksaan lebih lanjut. Pada penderita yang mengalami rekurensi dapat dilakukan radioterapi atau kemoterapi lini kedua. Penilaian hasil terapi meliputi gambaran klinis subjektif, semi subjektif dan objektif. Penilaian subjektif meliputi berkurang atau bertambahnya keluhan penderita melalui sistem skoring. Penilaian semi subjektif melalui naik/turunnya berat badan, frekuensi napas, sesak napas dan responss objektif berupa evaluasi respons pengobatan berdasarkan sistem RECIST 1.1. jdih.kemkes.go.id - 82 - Evaluasi lesi target berdasarkan CT Scan Toraks dengan kontras: 1. Complete response (CR): semua lesi target menghilang. Kelenjar getah bening (target maupun non-target) harus mengalami pengecilan pada sumbu pendek ke <10 mm. 2. Partial responsse (PR): setidaknya ada 30% pengurangan pada total diameter dari lesi-lesi target. 3. Progressive disease (PD): setidaknya ada 20% penambahan pada total diameter dari lesi-lesi target. Selain penambahan relatif sebanyak 20%, total tersebut juga harus menunjukkan penambahan absolut setidaknya 5 mm. Munculnya 1 lesi baru atau lebih juga dapat dipertimbangkan sebagai progresi. 4. Stable Disease (SD): pengurangan diameter lesi target tidak cukup untuk dapat dikatakan sebagai PR dan penambahan diameter lesi target tidak cukup untuk dapat dikatakan sebagai PD, dengan mengambil jumlah terkecil diameter sebagai referensi.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2023
