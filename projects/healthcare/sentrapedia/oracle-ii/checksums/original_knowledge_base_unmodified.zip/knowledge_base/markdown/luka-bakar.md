---
id: 234
title: "Luka Bakar"
slug: "luka-bakar"
icd_10: "T20-T32"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Luka Bakar (ICD-10: T20-T32)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Luka bakar (combustio) adalah kerusakan atau hilangnya integritas jaringan kulit dan struktur di bawahnya yang disebabkan oleh kontak dengan sumber energi termal (api, cairan panas, uap panas), radiasi, sengatan listrik, gesekan, atau paparan zat kimia berbahaya.

---

## 2. Gejala & Manifestasi Klinis
- dan gejala Terapi Contoh • Sangat nyeri. Irigasi dengan Asam • Tampilan air mengalir hydrofluoric

---

## 3. Kriteria & Alur Diagnosis
dasar untuk diagnosis Pasien dengan kecurigaan intoksikasi karbon monoksida harus diberikan suplementasi oksigen high flow paling 3 B tidak selama 6 jam Observasi dan monitoring harus dilakukan sebagai salah satu manajemen dari trauma inhalasi diatas laring. Pasien dengan trauma inhalasi diatas laring sebaiknya dirawat 4 dalam posisi setengah tegak (semi upright) dengan sedikit C elevasi pada kepala. Pemasangan intubasi endotrakeal atau trakeostomi diindikasikan bila patensi pernapasan pada pasien terancam - 108 - . Pasien trauma inhalasi yang membutuhkan ventilasi mekanik, harus diberikan dengan tekanan inflasi dan 5 C volum tidal yang paling rendah yang mencukupi kebutuhan respiratorik pasien Pemberian antibiotik dan kortikosteroid profilaksis tidak 6 C

---

## 4. Tatalaksana & Terapi
B trauma luka bakar karena kimia harus dilakukan kecuali pada trauma kimia elemen sodium, potassium dan lithium. - 115 - 11. Luka bakar pada anak a. Pendahuluan Konsep dasar penanganan luka bakar pada anak hampir sama dengan dewasa, yaitu menggunakan metode survei primer dan survei sekunder (4, 8). Perbedaan yang signifikan antara luka bakar pada anak dan dewasa adalah: 1) Proporsi dan ukuran tubuh anak 2) Dinamika cairan 3) Ketebalan kulit 4) Perbedaan sosial dan perkembangan emosi anak

---

## 5. Kriteria Rujukan (FKRTL)
- masing rumah sakit. Tabel 6. Kriteria rujuk diunduh dari EMSB course oleh ANZBA NO KRITERIA RUJUK 1 Luka bakar lebih dari 10% Total Body Surface Area (TBSA) 2 Luka bakar lebih dari 5% TBSA pada anak 3 Luka bakar full thickness lebih dari 5% TBSA Luka bakar pada area khusus (Wajah, tangan, kaki, genitalia, 4 perineum, sendi utama, dan luka bakar yang mengelilingi ekstremitas serta luka bakar pada dada) 5 Luka bakar dengan trauma inhalasi 6 Luka bakar listrik 7 Luka bakar karena zat kimiawi 8 Luka bakar dengan penyakit yang menyertai sebelumnya 9 Luka bakar yang disertai trauma mayor 10 Luka bakar pada usia ekstrem: anak sangat muda dan orang tua 11 Luka bakar pada wanita hamil 12 Luka bakar bukan karena kecelakaan - 23 - D. Multidisiplin Tata laksana luka bakar memerlukan suatu tim yang terdiri dari berbagai kelompok multidisiplin, yang mana kemampuan individu setiap anggota saling melengkapi satu sama lain. Berikut beberapa anggota tim multidisiplin yang terlibat dalam penanganan luka bakar antara lain Spesialis Bedah Plastik atau Bedah Umum, Spesialis Anestesi dan terapi intensif, Spesialis Anak, Spesialis Gizi Klinik, Spesialis Kedokteran Jiwa, Spesialis Kedokteran Fisik dan Rehabilitasi dan Perawat Mahir. E. Tata laksana luka bakar 24 jam pertama Prinsip-prinsip Primary Survey dan Secondary Survey pada trauma (ATLS) dan resusitasi secara simultan harus diterapkan. Tabel 7. Primary dan secondary survey pada trauma SECOND PRIMARY SURVEY First Aid ARY A B C D E F A.M.P.L.E History Head to Toe Examinati on Tetanus LOOK Fluid Airway Breathing Circulation Disability Exposure Analgesia Tests Tubes - 24 - DO Document Environm ation and C-Spine O2 Haemorrhage AVPU & ental Transfer control I.V. Pupils control Support Sebelum melakukan pertolongan pertama, petugas medik diharuskan menggunakan alat pelindung diri (sarung tangan, goggle glass, dan baju pelindung khusus) sebelum menangani pasien. Rekomendasi Tata laksana 24 Jam pertama Luka Bakar Derajat Pasien luka bakar harus dievaluasi dengan menggunakan B pendekatan yang sistematis, langkah pertama adalah berusaha mengidentifikasi ancaman hidup terbesar. 1. Primary survey Segera identifikasi kondisi-kondisi mengancam jiwa dan lakukan manajemen emergensi. a. (Airway) : Penalataksanaan jalan nafas dan manajemen trauma cervical b. (Breathing) : Pernapasan dan ventilasi c. (Circulation) : Sirkulasi dengan kontrol perdarahan d. (Disability) : Status neurogenik e. (Exposure) : Pajanan dan Pengendalian lingkungan Dibawah ini adalah check list dalam mengidentifikasi dan tata laksana pasien luka bakar berat pada survey primer berdasarkan Fundamental Critical Care Support (FCCS course) oleh Asosiasi Critical Care dunia, Early Management of Severe Burn course, dan ABC of Burn (4, 8-10). - 25 - Tabel 8. Check List Survey Primer Pada Luka Bakar Berat Manajemen Cek Tindakan Airway Patensi jalan nafas  Berbicara dengan pasien  Bersihkan jalan nafas dari benda asing  Lakukan Chin lift, Jaw thrust  Hindari melakukan hiperfleksi atau hiperekstensi kepala dan leher  Kontrol tulang cervical dengan rigid collar Breathing • Periksa tanda - tanda  Inspeksi dada, pastikan hipoksia dan pergerakan dinding dada hiperventilasi atau adekuat dan simetris hipoventilasi  Berikan oksigen 100% high • Hati-hati pasien dengan flow 10-15 liter per menit intoksikasi carbon melalui masker non- monoksida, tampak rebreathing cherry pink dan tidak  jika tetap sesak, lakukan bernafas bagging atau ventilasi • Hati-hati luka bakar yang mekanik melingkar pada dada (jika ada pertimbangkan eskarotomi) Circulation • Tanda – tanda syok  Lakukan penekanan luka • Cek nadi sentral jika terdapat perdarahan • Cek Tekanan darah aktif • Cek Capillary refill (normal  Pasang 2 jalur IV ukuran kembali <2 detik) besar, lebih disarankan • Cek luka bakar melingkar pada daerah yang tidak terkena luka bakar pada ekstremitas  Jika pasien syok, berikan (pertimbangkan bolus ringer lactat hingga eskarotomi) nadi radial teraba - 26 -  Ambil sampel darah untuk pemeriksaan darah lengkap, analisis gas darah arteri  Cari dan tangani tanda – tanda klinis syok lainnya yang disebabkan oleh penyebab lainnya. Disability Derajat kesadaran:  Periksa derajat kesadaran A (Alert) : Sadar penuh  Periksa respon pupil V (Verbal) : merespon terhadap cahaya terhadap rangsang verbal  Hati – hati pada pasien P (Pain) : merespon dengan hipoksemia dan terhadap rangsang nyeri syok karena dapat terjadi U (Unresponsive) : Tidak penurunan kesadaran dan ada respon gelisah. Exposure Exposure dan kontrol  Melepas semua pakaian dan lingkungan aksesoris yang melekat pada tubuh pasien  Lakukan log roll untuk melihat permukaan posterior pasien  Jaga pasien tetap dalam keadaan hangat  Menghitung luas luka bakar dengan metode Rules of Nine Fluid Resusitasi cairan yang  Parkland Formula: 3-4 ml x (Resusitasi adekuat dan monitoring Berat Badan (kg) x % TBSA Cairan) Luka Bakar (+ Rumatan untuk pasien anak)  Setengah dari jumlah cairan diberikan pada 8 jam pertama dan setengah cairan sisanya diberikan dalam 18 jam selanjutnya - 27 -  Gunakan cairan Kristaloid (Hartmann solution) seperti Ringer Lactat  Hitung Urine Output tiap jam  Lakukan pemeriksaan EKG, nadi, tekanan darah, respiratory rate, pulse oximetry, analisis gas darah arteri  Berikan cairan resusitasi sesuai indikasi  SIADH (IDAI) Analgesia Manajemen nyeri  Berikan morfin intravena 0,05 – 0,1 mg/kg sesuai indikasi  Untuk anak paracetamol cairan drip (setiap 6 jam) dengan dosis 10-15mg/kg BB/kali Test Menyingkirkan  X-Ray: kemungkinan adanya Lateral cervical o trauma lain Thorax o Pelvis o Lainnya sesuai indikasi o Tubes • Mencegah gastroparesis  Pasang Nasogastric Tube • Dekompresi lambung (NGT) - 28 - Rekomendasi Primary Survey pada pasien Luka Bakar Derajat

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK UNKNOWN
