---
id: 220
title: "Hipertensi Pada Anak"
slug: "hipertensi-pada-anak"
icd_10: "I10"
category: "Penyakit Anak"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Hipertensi Pada Anak (ICD-10: I10)

**Kategori Medis**: Penyakit Anak  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Hipertensi pada anak didefinisikan sebagai rerata tekanan darah sistolik dan/atau diastolik yang berada pada atau di atas persentil ke-95 menurut usia, jenis kelamin, dan persentil tinggi badan pada minimal tiga kali pemeriksaan terpisah dalam kondisi tenang.

---

## 2. Gejala & Manifestasi Klinis
_Manifestasi klinis tertera pada kriteria diagnostik._

---

## 3. Kriteria & Alur Diagnosis
oleh The Second Task Force Report Blood Pressure. (Level of evidence D) 3. Penggunaan tabel skrining tekanan darah yang telah disederhanakan (tabel 2) direkomendasikan untuk digunakan di fasilitas pelayanan kesehatan tingkat 1-3 untuk deteksi awal hipertensi pada anak. (Level of evidence D) 4. Tekanan darah diukur setidaknya setiap tahun pada anak-anak dan remaja berusia ≥ 3 tahun. (Level of evidence C, rekomendasi sedang) 5. Tekanan darah harus diperiksa pada semua anak dan remaja berusia ≥3 tahun pada setiap kunjungan ke fasilitas pelayanan kesehatan jika mereka memiliki obesitas, meminum obat yang dapat meningkatkan tekanan darah, memiliki penyakit ginjal, riwayat obstruksi, koarktasio aorta, atau diabetes. (Level of evidence C, rekomendasi sedang) 6. Pengukuran tekanan darah digital dapat dilakukan untuk deteksi awal hipertensi pada anak. (Level of evidence D, rekomendasi lemah) 7. Pengukuran tekanan darah auskultasi harus dilakukan untuk menegakkan diagnsosi hipertensi pada anak. (Level of evidence D, rekomendasi lemah) 8. Teknik dan alat pengukuran darah yang tepat direkomendasikan untuk diagnosis dan tata laksana hipertensi pada anak. (Level of evidence D) 9. Konfirmasi hipertensi pada anak dan remaja menggunakan ABPM dapat dilakukan sesuai indikasi di fasilitas pelayanan kesehatan spesialistik. (Level of evidence C, rekomendasi sedang) 10. Anak- dan remaja berusia ≥ 6 tahun tidak memerlukan evaluasi ekstensif untuk penyebab hipertensi sekunder jika mereka memiliki riwayat keluarga dengan hipertensi, kelebihan berat badan atau obesitas, dan/atau tidak memiliki riwayat atau temuan pemeriksaan fisik yang mengarah kepada penyebab hipertensi sekunder. (Level of evidence C, rekomendasi sedang) 11. Anak-anak dan remaja yang telah menjalani prosedur perbaikan koarktasio aorta memerlukan deteksi pemantauan hipertensi. (Level of evidence B, rekomendasi kuat) jdih.kemkes.go.id - 46 - 12. Pada anak-anak dan remaja yang dievaluasi untuk hipertensi, harus dianamnesis mengenai riwayat perinatal, gizi, aktivitas fisik, psikososial, dan riwayat keluarga serta melakukan pemeriksaan fisik untuk mengidentifikasi temuan yang menunjukkan kemungkinan penyebab hipertensi sekunder. (Level of evidence B, rekomendasi kuat) 13. Ekokardiografi disarankan dilakukan untuk menilai kerusakan organ target jantung (massa, geometri, dan fungsi ventrikel kiri). (Level of evidence C, rekomendasi sedang) 14. Pada anak-anak dan remaja yang dicurigai menderita RAS dilakukan CTA atau MRA. Renografi nuklir kurang bermanfaat pada anak-anak dan sebaiknya harus dihindari. (Level of evidence D, rekomendasi lemah) 15. Pada anak-anak dan remaja yang didiagnosis hipertensi, tujuan

---

## 4. Tatalaksana & Terapi
perawatan dengan terapi nonfarmakologis dan farmakologis harus berupa pengurangan tekanan sistolik dan diastolik menjadi < persentil 90 pada usia di bawah 13 tahun dan <130/80 mmHg pada anak usia ≥ 13 tahun. (Level of evidence C, rekomendasi sedang) 16. Pada anak dan remaja dengan hipertensi yang telah gagal menjalani modifikasi gaya hidup (khususnya pada anak dengan pembesaran ventrikel kiri, hipertensi simptomatik, atau hipertensi tingkat 2, sebaiknya dimulai terapi farmakologik. (Level of evidence B, rekomendasi sedang) 17. Penggunaan ABPM untuk menilai efektivitas pengobatan pada anak-anak dan remaja dengan hipertensi dilakukan sesuai indikasi. (Level of evidence B, rekomendasi sedang) 18. Anak-anak dan remaja dengan penyakit ginjal kronik harus dievaluasi tekanan darah pada setiap kunjungan ke fasilitas pelayanan kesehatan. (Level of evidence B, rekomendasi kuat) 19. Anak-anak dan remaja dengan penyakit ginjal kronik atau hipert ensi harus dievaluasi kemungkinan adanya proteinuria. (Level of evidence B, rekomendasi kuat) 20. Anak-anak dan remaja dengan penyakit ginjal kronik, hipertensi, dan proteinuria direkomendasikan untuk pemberian pengobatan ACEi atau ARB. (Level of evidence B, rekomendasi kuat) jdih.kemkes.go.id - 47 - Tabel 11. Tekanan darah laki-laki berdasarkan persentil umur dan tinggi Sumber : Pedoman AAP tahun 2017 jdih.kemkes.go.id - 48 - jdih.kemkes.go.id - 49 - jdih.kemkes.go.id - 50 - Sumber: Pedoman AAP tahun 2017 jdih.kemkes.go.id - 51 - Tabel 12.Tekanan darah perempuan berdasarkan persentil umur dan tinggi jdih.kemkes.go.id - 52 - jdih.kemkes.go.id - 53 - jdih.kemkes.go.id - 54 - Sumber: Pedoman AAP tahun 2017 jdih.kemkes.go.id - 55 - BAB V SIMPULAN 1. Tekanan darah harus diukur secara berkala, yaitu setiap tahun pada anak berusia di atas 3 tahun. 2. Tekanan darah harus diukur pada semua anak berusia di atas 3 tahun, pada setiap kunjungan ke fasilitas kesehatan apabila diketahui memiliki obesitas, konsumsi obat yang dapat menaikkan tekanan darah, memiliki penyakit ginjal, riwayat obstruksi arkus aorta atau koartaksio aorta, atau memiliki diabetes. 3. Pada anak dengan hipertensi, tujuan tatalaksana farmakologik dan non farmakologik adalah tekanan darah di bawah persentil 90 pada anak berusia di bawah 13 tahun dan di bawah 130/80 mmHg pada anak berusia di atas 13 tahun. 4. Pada anak dan remaja dengan hipertensi yang telah gagal menjalani modifikasi gaya hidup (khususnya pada anak dengan pembesaran ventrikel kiri, hipertensi simptomatik, atau hipertensi tingkat 2, maka sebaiknya dimulai terapi farmakologik berupa ACEi, ARB, CCB atau diuretik thiazid. MENTERI KESEHATAN REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 5. Kriteria Rujukan (FKRTL)
Rujuk seluruh kasus hipertensi pada anak (tekanan darah >= persentil 95) ke Dokter Spesialis Anak (Sp.A / Nefrologi Anak) untuk evaluasi etiologi hipertensi sekunder dan penapisan kerusakan organ target.

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK 2021
