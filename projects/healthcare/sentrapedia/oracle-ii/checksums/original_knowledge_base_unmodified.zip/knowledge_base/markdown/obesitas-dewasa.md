---
id: 270
title: "Obesitas Dewasa"
slug: "obesitas-dewasa"
icd_10: "E66"
category: "Penyakit Dalam"
standard: "SKDI 4A / PNPK Kemenkes RI"
is_complete: true
---

# Obesitas Dewasa (ICD-10: E66)

**Kategori Medis**: Penyakit Dalam  
**Standar Pelayanan**: Standar Kompetensi Dokter Indonesia (SKDI 4A) / Pedoman Nasional Pelayanan Kedokteran (PNPK)

---

## 1. Definisi Klinis
Obesitas adalah penyakit kronik yang ditandai dengan meningkatnya massa lemak secara berlebihan serta dapat meningkatkan risiko banyak penyakit tidak menular dan dapat menurunkan usia harapan hidup. Diagnosis obesitas ditentukan N berdasarkan indeks massa tubuh (IMT) lebih dari 25 kg/m2 dan lingkar A pinggang (Waist Circumference) >90 cm untuk laki laki dan >80 cm T untuk perempuan. Berdasarkan hasil pemeriksaan komposisi tubuh, A secara umum, obesitas memiliki batas massa lemak pada laki-laki dan H perempuan adalah lebih dari 25% dan 35%. E Sarkopenia obesitas adalah kehilangan atau menurunnya massa S otot dan digunakan oleh massa lemak (adiposit) pada orang dengan obesitas. Salah satu cara skriningnEya adalah dengan menggunakan kuesioner SARC-F dan antropoKmetri, apabila skor yang dihasilkan empat atau lebih, menandakan adanya kemungkinan sarkopenia. N A B. Evaluasi Klinis dan Pemeriksaan Penunjang I 1. Anamnesis (rekRomendasi B) Anamnesis yang perlu dilakukan adalah: E a. Riwayat keluarga obesitas dan kardiometabolik. T b. Riwayat obesitas pada masa kanak-kanak dan riwayat N peningkatan berat badan sebelumnya dan alasannya. E c. Analisis asupan per hari M Porsi karbohidrat, protein, lemak, dan serat. Ed. Kebiasaan tidur K 1) Insomnia. 2) Hipersomnia. 3) Kualitas tidur yang buruk. e. Riwayat kebiasaan 1) Pola makan (contoh: binge eating, night eating syndrome). 2) Aktivitas. 3) Olahraga. 4) Tidur. 5) Merokok. jdih.kemkes.go.id -11- 6) Konsumsi alkohol. f. Riwayat sosial ekonomi dan pendidikan. g. Konsumsi obat-obatan yang dapat meningkatkan berat badan: 1) Obat anti hiperglikemia: insulin, sulfonilurea, meglitinides, thiazolidinedione; 2) Beta-bloker: metoprolol, atenolol, propranolol; 3) Alfa-bloker: Terazosin; 4) Glukokortikoid: Prednison, metilprednisolon, hidrokorNtison; 5) Terapi hormonal: Progestin (medroksiprogesteron, megestrol A asetat); dan T 6) Antihistamin: cetirizin, siproheptadin. A h. Riwayat penurunan berat badan: >5% dari berat badan awal H dalam 1 bulan terakhir atau >10% berat badan dalam 6 bulan E terakhir. S i. Riwayat usaha penurunan berat badan E Terapi penurunan berat badan sebelumnya: slimming diet, weight K cycling, tingkat kesuksesan dalam program penurunan berat badan. N j. Motivasi menurunkan berat badan: A 1) Self-esteem. I 2) Target bRerat badan. 3) PenuErunan berat badan yang diinginkan, misalnya 5–10 kg dTalam 2 minggu. k. TNantangan untuk menurunkan berat badan l. Riwayat penyakit dahulu: E 1) Diabetes. M 2) Hipertensi. E 3) Dislipidemia. K 4) Penyakit jantung coroner. 5) Non-Alcoholic Steatohepatitis. 6) Non-Alcoholic Fatty Liver Disease. 7) Polycystic Ovarian syndrome (PCOS). 8) Hipogonadism pada laki-laki. 9) Osteoartritis. 10) Asma. 11) Obstructive sleep apnea (OSA). 12) Urinary stress incontinence. jdih.kemkes.go.id -12- 13) Gastroesophageal reflux disease (GERD). 14) Depresi, ansietas. 15) Disabilitas. m. Riwayat gangguan psikiatrik serta pengobatan yang diperoleh Gangguan psikiatrik: 1) Gangguan mood (depresi maupun bipolar). 2) Ansietas. 3) Gangguan makan. N 4) Gangguan pemusatan perhatian dan hiperaktivitas. A 5) Hendaya kognitif ringan. T 6) Skizofrenia. A n. Pengobatan yang diperoleh: H 1) Antipsikotik: clozapine, olanzapine, risperidone (antipsikotik E generasi II dengan akhiran -pine dan -done). S 2) Antidepresan: Selective serotonin reuptake inhibitor E (paroxetine, sertraline, citalopram, escitalopram, fluoxetine), K MAOI (phenelzine), antidepresan trisiklik (amitriptilin, clomipramine, doxepin, imipramine, nortriptyline, N protriptyline), antidepresan mirtazapine, antiepilepsi/mood A stabilizing agent (valproate, lithium, carbamazepine). I R 2. PemeriksaaEn Fisik (Rekomendasi B) PemerikTsaan fisik yang diperlukan adalah a. KNeadaan umum, tanda vital, dan status generalis. b. Achantosis nigricans, moon facies, goiter. E c. Pemeriksaan antropometri M 1) Berat badan E a) Ditimbang dengan menggunakan pakaian seminimal K mungkin, tanpa barang di kantong baju atau celana. b) Berat badan harus ditimbang dengan menggunakan instrumen yang sudah di kalibrasi dan mampu hingga berat badan 200 kg atau lebih. 2) Tinggi badan a) Diukur tanpa menggunakan alas kaki pada permukaan yang rata. b) Apabila subjek tidak dapat berdiri, maka dilakukan pengukuran panjang badan (PB). jdih.kemkes.go.id -13- 3) Indeks Massa Tubuh a) IMT yang optimal pada usia >65 tahun normalnya sedikit lebih tinggi daripada usia lebih muda. b) IMT dapat menyebabkan misdiagnosis pada individu yang memiliki otot besar. Sehingga diperlukan juga pengukuran lemak tubuh sebagai alternatif untuk skrining obesitas. c) Rumus Perhitungan IMT: dihitung dengan menggunakan rumus: Berat badan (kg) dibagi tinggi badan N(meter) kuadrat. A T Tabel 3.1. Klasifikasi berat badan berdasarkan IMT untuk A Asia Pasifik Klasifikasi IMT (kg/m2) HRisiko komorbid Berat badan kurang <18,5 Rendah E (Underweight) (meningkatkan risiko Ssakit yang lain) Normal 18,5–22,9 Rata-rata E Berat badan lebih (BB 23–24,9 Meningkat lebih) K Obesitas I 25–29,9 Sedang Obesitas II N30 Berat ≥ A 4) Lingkar pinggang I a) SalahR satu indikator yang cukup bermanfaat untuk mengukur lemak perut dan sebagai penanda untuk E penyakit kardiometabolik. T b) Lingkar pinggang harus diukur pada saat pasien N menggunakan pakaian yang tipis. Pengukuran dilakukan E saat ekspirasi, pada titik tengah antara iga paling bawah M dan penonjolan iliaka superior dengan menggunakan pita E ukur secara horizontal. K Tabel 3.2. Lingkar pinggang obesitas menurut jenis kelamin Lingkar pinggang

---

## 2. Gejala & Manifestasi Klinis
_Manifestasi klinis tertera pada kriteria diagnostik._

---

## 3. Kriteria & Alur Diagnosis
, antropometri dan pemeriksaan klinis (Rekomendasi B). N

---

## 4. Tatalaksana & Terapi
Terapi obesitas perlu memperhatikan derajat obesitas dan E komplikasi obesitas yang ada. Selain itu, perlu memperhatikan preferensi S dan harapan dari pasien serta sumber daya yang tersedia. Prinsip terapi E obesitas adalah keamanan pengobatan jangka panjang karena obesitas K merupakan penyakit kronis. Terapi dasar pada pasien obesitas adalah modifikasi gaya hidup termasuk Ndiet, peningkatan aktivitas fisik, dan perubahan perilaku. Terapi Amedikamentosa direkomendasikan untuk pasien dengan ≥25 kg/m2 dengan komorbid atau IMT ≥30 kg/m2. Terapi I R bariatrik berupa tindakan operatif maupun endoskopik, dapat disarankan E pada pasien dengan IMT ≥30 kg/m2 dengan komorbid yang tidak terkontrol T dengan obat obatan, dan gagal turun berat badan setelah menjalani terapi N medikamentosa serta modifikasi gaya hidup. Pasca tindakan terapi bariatrik,E modifikasi gaya hidup tetap harus dilakukan. M E MENTERI KESEHATAN K REPUBLIK INDONESIA, ttd. BUDI G. SADIKIN jdih.kemkes.go.id

---

## 5. Kriteria Rujukan (FKRTL)
Jika pada penemuan diniN ditemukan obesitas dengan komorbid ≥1 atau jika tidak ada rAespon penurunan berat badan >5% setelah melakukan upaya modifikasi gaya hidup selama tiga bulan, atau I R obesitas relaps, maka dilakukan rujukan kasus untuk pemeriksaan E

---

## 6. Referensi & Dasar Regulasi
- **PNPK**: PNPK UNKNOWN
