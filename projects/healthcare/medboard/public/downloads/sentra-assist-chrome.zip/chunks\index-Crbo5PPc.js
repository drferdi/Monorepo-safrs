var o,r;const s=(r=(o=globalThis.browser)==null?void 0:o.runtime)!=null&&r.id?globalThis.browser:globalThis.chrome;export{s as b};
